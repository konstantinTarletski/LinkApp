create trigger PP_CTIME
    before update
    on PCD_PP_CARDS
    for each row
DECLARE
BEGIN
    :new.ctime := sysdate;
END;

/

