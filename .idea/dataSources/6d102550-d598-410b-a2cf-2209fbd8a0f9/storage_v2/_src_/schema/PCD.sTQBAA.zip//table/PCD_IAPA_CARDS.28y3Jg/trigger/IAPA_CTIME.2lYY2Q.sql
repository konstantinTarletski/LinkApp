create trigger IAPA_CTIME
    before update
    on PCD_IAPA_CARDS
    for each row
DECLARE
BEGIN
    :new.ctime := sysdate;
END;

/

