create trigger PP_REG_DATE
    before insert
    on PCD_PP_CARDS
    for each row
DECLARE
BEGIN
    :new.reg_date := sysdate;
END;

/

