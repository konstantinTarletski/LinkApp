create trigger PCD_DESIGN_ID_TRG
    before insert
    on PCD_DESIGN
    for each row
BEGIN
  SELECT PCD_DESIGN_ID_SEQ.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;

/

