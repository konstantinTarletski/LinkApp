create trigger PCD_IAPA_PK
    before insert
    on PCD_IAPA_CARDS
    for each row
begin  
   if inserting then 
      if :NEW."CARD_NUMBER" is null then 
         select PCD_IAPA.nextval into :NEW."CARD_NUMBER" from dual; 
      end if; 
   end if; 
end;

/

