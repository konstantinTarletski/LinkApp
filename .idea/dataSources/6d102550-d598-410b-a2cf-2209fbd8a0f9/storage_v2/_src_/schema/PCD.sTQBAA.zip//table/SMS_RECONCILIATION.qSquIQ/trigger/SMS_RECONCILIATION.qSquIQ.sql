create trigger SMS_RECONCILIATION
    before insert
    on SMS_RECONCILIATION
    for each row
DECLARE
BEGIN
    :new.last_date := sysdate;
END;

/

