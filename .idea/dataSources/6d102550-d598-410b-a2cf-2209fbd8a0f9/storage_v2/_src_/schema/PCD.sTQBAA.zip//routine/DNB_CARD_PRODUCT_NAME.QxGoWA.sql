create FUNCTION dnb_card_product_name (card IN VARCHAR2)
    RETURN VARCHAR2 IS
BEGIN
       IF substr(card,1,7) = '4775735' THEN RETURN 'Galactico Visa Debit';
    ELSIF substr(card,1,7) = '4921755' THEN RETURN 'Galactico Visa Classic';
    ELSIF substr(card,1,7) = '4999620' THEN RETURN 'Visa Gold Revolving';
    ELSIF substr(card,1,7) = '4999629' THEN RETURN 'Visa Gold';
    ELSIF substr(card,1,7) = '4999628' THEN RETURN 'Visa Platinum';
    ELSIF substr(card,1,7) = '4921750' THEN RETURN 'Visa Classic Revolving';
    ELSIF substr(card,1,6) = '492175'  THEN RETURN 'Visa Classic';
    ELSIF substr(card,1,6) = '465228'  THEN RETURN 'Visa Debit';
    ELSIF substr(card,1,6) = '477573'  THEN RETURN 'Visa Debit';
    ELSIF substr(card,1,6) = '492176'  THEN RETURN 'Visa Business';
    ELSIF substr(card,1,6) = '489994'  THEN RETURN 'Luminor Visa Infinite';
    ELSIF substr(card,1,6) = '478585'  THEN RETURN 'Luminor Black';
    ELSIF substr(card,1,6) = '442752'  THEN RETURN 'Visa Business Debit';
    ELSIF substr(card,1,6) = '676192'  THEN RETURN 'Maestro';
    ELSIF substr(card,1,6) = '542090'  THEN RETURN 'MasterCard Gold';
    ELSIF substr(card,1,6) = '547626'  THEN RETURN 'MasterCard Business';
    ELSIF substr(card,1,6) = '542085'  THEN RETURN 'MasterCard Standard';
    ELSIF substr(card,1,6) = '942817'  THEN RETURN 'DNB Local';
    ELSIF substr(card,1,6) = '942818'  THEN RETURN 'DNB Local';
      -- Estonian BINs
    ELSIF substr(card,1,6) = '408882'  THEN RETURN 'Visa Business';
    ELSIF substr(card,1,6) = '408883'  THEN RETURN 'Luminor Visa Infinite';
    ELSIF substr(card,1,6) = '408884'  THEN RETURN 'Luminor Black';
    ELSIF substr(card,1,6) = '408885'  THEN RETURN 'Visa Debit';
    ELSIF substr(card,1,6) = '456946'  THEN RETURN 'Visa Business Debit';
    ELSIF substr(card,1,6) = '478590'  THEN RETURN 'Visa Classic';
    ELSIF substr(card,1,6) = '478591'  THEN RETURN 'Visa Gold';
      -- unknown/new BIN
    ELSIF substr(card,1,1) = '4'       THEN RETURN 'Visa';
    ELSIF substr(card,1,1) = '5'       THEN RETURN 'MasterCard';
      -- failover
    ELSE RETURN  'payment card';
    END IF;

EXCEPTION WHEN OTHERS THEN RETURN 'payment card';
END dnb_card_product_name;
/

