create function my_md5(p_string in varchar2)
      return varchar2
    is
    begin
      return (dbms_obfuscation_toolkit.md5(input_string => p_string));
    end;
/

