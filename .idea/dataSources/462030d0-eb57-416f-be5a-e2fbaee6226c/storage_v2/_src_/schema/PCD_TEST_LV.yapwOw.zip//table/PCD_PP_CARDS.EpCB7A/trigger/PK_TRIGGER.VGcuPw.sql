create trigger PK_TRIGGER
    before insert
    on PCD_PP_CARDS
    for each row
begin     if inserting then       if :NEW."CARD_NUMBER" is null then          select PCD_PRIORITY_PASS.nextval into :NEW."CARD_NUMBER" from dual;       end if;    end if; end;


/

