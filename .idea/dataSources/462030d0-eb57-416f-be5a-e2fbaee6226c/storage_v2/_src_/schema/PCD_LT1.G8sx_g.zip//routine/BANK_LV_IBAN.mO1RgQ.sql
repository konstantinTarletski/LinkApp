create FUNCTION BANK_LV_IBAN
( acc IN VARCHAR2
) RETURN VARCHAR2 AS
BEGIN


if (length(acc) = 10) then
        return substr('LV'||lpad(to_char(98-mod(to_char(mod(ascii('R'),65)+10)||to_char(mod(ascii('I'),65)+10)||to_char(mod(ascii('K'),65)+10)||to_char(mod(ascii('O'),65)+10)||'000'||acc||'213100',97)),2,'0'),1,4)||'RIKO'||substr('000'||acc,1,4)||substr('000'||acc,5,4)||substr('000'||acc,9,4)||substr('000'||acc,13,1);
end if;

return '';

EXCEPTION
   WHEN others THEN
       return '';

  RETURN NULL;
END BANK_LV_IBAN;
/

