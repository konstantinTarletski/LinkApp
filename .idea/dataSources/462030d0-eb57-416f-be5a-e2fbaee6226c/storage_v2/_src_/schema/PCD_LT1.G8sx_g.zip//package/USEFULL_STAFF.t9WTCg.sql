create PACKAGE usefull_staff IS
--
-- To modify this template, edit file PKGSPEC.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
   -- Enter package declarations as shown below

  /*FUNCTION main_card (my_main_row IN number, my_bank_c IN varchar2 DEFAULT '23') RETURN  varchar2;*/
  FUNCTION card_expd (in_card IN varchar2) RETURN date;
  FUNCTION card_cvc1 (in_card IN varchar2) RETURN varchar2;
  FUNCTION card_cvc2 (in_card IN varchar2) RETURN varchar2;
END;
/

