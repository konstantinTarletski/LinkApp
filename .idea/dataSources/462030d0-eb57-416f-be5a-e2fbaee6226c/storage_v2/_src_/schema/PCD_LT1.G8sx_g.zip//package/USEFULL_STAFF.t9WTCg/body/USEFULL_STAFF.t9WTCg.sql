create PACKAGE BODY USEFULL_STAFF AS

--
-- To modify this template, edit file PKGBODY.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package body
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
   -- Enter procedure, function bodies as shown below

   /*FUNCTION main_card ( my_main_row IN number, my_bank_c IN varchar2 DEFAULT '23') RETURN varchar2
    IS
   my_card_number varchar2 (19);
      -- Enter the procedure variables here. As shown below
   BEGIN
                    select c2.card
                    into my_card_number
					from pcd_cards c2
					where c2.cl_acct_key = my_main_row
					 and rownum=1
					 and c2.bank_c = my_bank_c
                     and   decode(c2.status1
									, 0
									, decode(c2.base_supp
											,'1'
											, decode((substr(c2.card,1,6))
																	, '465228', 31
																	, '492175', 32
																	, '542085', 32
																	, '492176', 33
																	, '547626', 33
																	, '499962', 34
																	, '542090', 34
																	, 31
											  		)
											, '2'
											, decode((substr(c2.card,1,6))
																	, '465228', 21
																	, '492175', 22
																	, '542085', 22
																	, '492176', 23
																	, '547626', 23
																	, '499962', 24
																	, '542090', 24
																	, 21
											  		)
											, 21
											)
									, decode(c2.base_supp
											, '1'
											, decode((substr(c2.card,1,6))
																	, '465228', 11
																	, '492175', 12
																	, '542085', 12
																	, '492176', 13
																	, '547626', 13
																	, '499962', 14
																	, '542090', 14
																	, 11
											  		)
											, '2'
											, decode((substr(c2.card,1,6))
																	, '465228', 1
																	, '492175', 2
																	, '542085', 2
																	, '492176', 3
																	, '547626', 3
																	, '499962', 4
																	, '542090', 4
																	, 1
											  		)
											, 1
											)
								)
		   				=
			   		   (select max(
								   decode(c3.status1
									, 0
									, decode(c3.base_supp
											,'1'
											, decode((substr(c3.card,1,6))
																	, '465228', 31
																	, '492175', 32
																	, '542085', 32
																	, '492176', 33
																	, '547626', 33
																	, '499962', 34
																	, '542090', 34
																	, 31
											  		)
											, '2'
											, decode((substr(c3.card,1,6))
																	, '465228', 21
																	, '492175', 22
																	, '542085', 22
																	, '492176', 23
																	, '547626', 23
																	, '499962', 24
																	, '542090', 24
																	, 21
											  		)
											, 21
											)
									, decode(c3.base_supp
											, '1'
											, decode((substr(c3.card,1,6))
																	, '465228', 11
																	, '492175', 12
																	, '542085', 12
																	, '492176', 13
																	, '547626', 13
																	, '499962', 14
																	, '542090', 14
																	, 11
											  		)
											, '2'
											, decode((substr(c3.card,1,6))
																	, '465228', 1
																	, '492175', 2
																	, '542085', 2
																	, '492176', 3
																	, '547626', 3
																	, '499962', 4
																	, '542090', 4
																	, 1
											  		)
											, 1
											)
								)
				               )
       from pcd_cards c3
       where c3.cl_acct_key = my_main_row
         and c3.bank_c = my_bank_c
      );
   return my_card_number;
   END;
*/
    FUNCTION card_expd (in_card IN varchar2) RETURN date IS
       expd date;
    
    BEGIN 
        select
            decode(cvc1_2, null, expiry1,
            decode(sign(abs(expiry1-expiry2))+sign(abs(decode(nvl(length(rtrim(cvc1_2)), 0), 0, 0, 1)-decode(nvl(cvc1_1, 0), 0, 0, 1))), 2,
            decode(sign(last_day(expiry1)-last_day(sysdate)), 1, expiry1, expiry2), expiry1))
        into expd 
        from pcd_cards
        where card = in_card;

        RETURN expd;
        
    END;

    FUNCTION card_cvc1 (in_card IN varchar2) RETURN varchar2 IS
       cvc1 varchar2(3);
    
    BEGIN 
        select
            decode(cvc1_2, null, cvc1_1,
            decode(sign(abs(expiry1-expiry2))+sign(abs(decode(nvl(length(rtrim(cvc1_2)), 0), 0, 0, 1)-decode(nvl(cvc1_1, 0), 0, 0, 1))), 2,
            decode(sign(last_day(expiry1)-last_day(sysdate)), 1, cvc1_1, cvc1_2), cvc1_1))
        into cvc1 
        from pcd_cards
        where card = in_card;

        RETURN cvc1;

    END;

    FUNCTION card_cvc2 (in_card IN varchar2) RETURN varchar2 IS
       cvc2 varchar2(3);
    
    BEGIN 
        select
            decode(cvc1_2, null, cvc2_1,
            decode(sign(abs(expiry1-expiry2))+sign(abs(decode(nvl(length(rtrim(cvc1_2)), 0), 0, 0, 1)-decode(nvl(cvc1_1, 0), 0, 0, 1))), 2,
            decode(sign(last_day(expiry1)-last_day(sysdate)), 1, cvc2_1, cvc2_2), cvc2_1))
        into cvc2 
        from pcd_cards
        where card = in_card;

        RETURN cvc2;
    END;


END USEFULL_STAFF;
/

