create trigger UPDATE_CARD_CTIME_ISSUE_DATE
    before update of MEDIATOR,MAXIMA,DELIVERY_BLOCK,OPERATOR,CREATION_BRANCH,RENEW_OLD
    on PCD_CARDS
    for each row
BEGIN
    IF (   NVL(:OLD.DELIVERY_BLOCK,  '#') <> NVL(:NEW.DELIVERY_BLOCK,  '#')
        OR NVL(:OLD.OPERATOR,        '#') <> NVL(:NEW.OPERATOR,        '#')
        OR NVL(:OLD.CREATION_BRANCH, '#') <> NVL(:NEW.CREATION_BRANCH, '#')
        OR NVL(:OLD.MAXIMA,          '#') <> NVL(:NEW.MAXIMA,          '#')
        OR NVL(:OLD.MEDIATOR,        '#') <> NVL(:NEW.MEDIATOR,        '#')
        OR NVL(:OLD.RENEW_OLD,       '#') <> NVL(:NEW.RENEW_OLD,       '#')
       ) 
    THEN
        :NEW.CTIME := SYSDATE; 

        IF (:OLD.DELIVERY_BLOCK IN ('5','8') AND :NEW.DELIVERY_BLOCK = '6')
        THEN
            :NEW.ISSUE_DATE := SYSDATE;
        END IF;
    END IF;
END;
/

