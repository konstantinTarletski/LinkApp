create trigger PCD_PENDING_TOKENIZATION_TRG1
    before insert or update
    on PCD_CARDS_PENDING_TOKENIZATION
    for each row
declare
    new_ctime pcd_cards_pending_tokenization.ctime%type ;
begin
    select sysdate into new_ctime from dual;
    :new.ctime := new_ctime;
end;
/

