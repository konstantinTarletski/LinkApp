create PACKAGE
/* @ITEM_ID_VERSION@ */
progress IS
/*=======================================================================
 * @ITEM_ID_VERSION@
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
    the_hist_numb     autotasks_log.hist_numb%TYPE;
    tasks_total       integer;
    task_current      integer;
    subtasks_total    integer;
    subtask_current   integer;
    subtask_maximum   integer;
    in_progres        boolean;
    the_program_name  program_names.program_name%type;

    procedure new_task(program_name program_names.program_name%type, hist_numb autotasks_log.hist_numb%TYPE, stages integer:=1);
    procedure new_task_stage(message_number integer, message_arguments varchar2);
    procedure task_stage_message(message_number integer, message_arguments varchar2);
    procedure new_subtask(weight integer:=100, total integer:=100);
    procedure subtask_message(message_number integer, message_arguments varchar2);
    procedure subtask_progress(message_number integer, message_arguments varchar2, allready integer, total integer:=100);
    function start_task(task_number integer, manual_start char:='T') return integer;
    procedure end_task(hist_numb integer);
END;
/

