create view STIP_CONTRA_ACCOUNTS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.acnt_grp,
		x.account_id,
		x.account_ccy,
		x.rule_expr,
		x.abbreviature,
		x.description
	from STIP_CONTRA_ACCOUNTS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

