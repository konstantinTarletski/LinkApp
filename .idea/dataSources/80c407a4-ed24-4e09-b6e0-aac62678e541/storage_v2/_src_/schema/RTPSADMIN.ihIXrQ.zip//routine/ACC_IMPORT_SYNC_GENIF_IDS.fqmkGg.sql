create PROCEDURE
/* $HeadURL$ $Id$ */
ACC_IMPORT_SYNC_GENIF_IDS
IS
/* $HeadURL$ $Id$ */


  step              VARCHAR2(96) := 'StartUp';
  msg               VARCHAR2(4000);
  FATAL_ERROR       EXCEPTION;

  g_genif_if_types  VARCHAR2(2000);
  v_pos1            NUMBER;
  v_pos2            NUMBER;
  v_len             NUMBER;
  v_if_type         VARCHAR2(2000);

  ---
  v_card_type       MPCS_CARDS.card_type%TYPE;
  v_card_type2      MPCS_CARDS.card_type%TYPE;
  v_count           NUMBER;

  ---
  time1             NUMBER;
  time2             NUMBER;

  ---
  CURSOR gl_cursor(cp_if_type IN VARCHAR2)
      IS
  SELECT link_id
    FROM genif_links
   WHERE if_type = cp_if_type
  ;
  gl gl_cursor%ROWTYPE;
  gl_chk        NUMBER;

  v_base_link_id    GENIF_LINKS.link_id%TYPE := NULL;


  FUNCTION t_string(p_dbms_time NUMBER)
  RETURN VARCHAR2
  IS
    days    NUMBER := 0;
    hours   NUMBER := 0;
    mins    NUMBER := 0;
    secs    NUMBER := 0;
    hdrsec  NUMBER := 0;
    Total   NUMBER := p_dbms_time;
  BEGIN
      hdrsec := MOD(Total,100);
      Total  := FLOOR(Total/100);
      secs   := MOD(Total,60);
      Total  := FLOOR(Total/60);
      mins   := MOD(Total,60);
      Total  := FLOOR(Total/60);
      hours  := MOD(Total,24);
      days   := FLOOR(Total/24);
      RETURN TO_CHAR(days)||'d'||TO_CHAR(hours)||'h'||TO_CHAR(mins)||'m'||TO_CHAR(secs)||'.'||LPAD(TO_CHAR(hdrsec),2,'0')||'s';
  EXCEPTION WHEN OTHERS THEN
      RETURN '{Invalid time}';
  END t_string;




-------------------------------------------
-------- Acc_Import_Sync_GENIF_IDS --------
BEGIN


step:='00:MPCS parameters';
--- Getting AMEX card_type in MPCS
    BEGIN
        SELECT card_type
          INTO v_card_type
          FROM MPCS_CARDS
         WHERE card_id = 'AM';
    EXCEPTION WHEN OTHERS THEN
		msg:=''; --dont like commments without code
    END;

    BEGIN
        SELECT card_type
          INTO v_card_type2
          FROM MPCS_CARDS
         WHERE card_id = 'AS';
    EXCEPTION WHEN OTHERS THEN
		msg:=''; --dont like commments without code
    END;
	IF v_card_type is NULL and v_card_type2 is NULL THEN
        msg:='Acc_Import_Sync_GENIF_IDS skipped, no suitable card type: '||SQLERRM;
        RAISE FATAL_ERROR;
	END IF;

step:='01';
	IF v_card_type is not NULL THEN
    	msg:='Acc_Import_Sync_GENIF_IDS card_type: '||v_card_type;
    	err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
	END IF;
	IF v_card_type2 is not NULL THEN
    	msg:='Acc_Import_Sync_GENIF_IDS card_type: '||v_card_type2;
    	err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
	END IF;


step:='10:RTPS.ACQ.ACCIMP parameter';
    IF not reg.getc('/RTPS.ACQ.ACCIMP/GENIF/if_types',g_genif_if_types) THEN
        g_genif_if_types:='IBRO';
        ---
        msg:='Acc_Import_Sync_GENIF_IDS parameter /RTPS.ACQ.ACCIMP/GENIF/if_types not found, using default';
        err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
    END IF;
step:='11';
    msg:='Acc_Import_Sync_GENIF_IDS /RTPS.ACQ.ACCIMP/GENIF/if_types = '||g_genif_if_types;
    err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);


step:='20:Parsing parameter';
    v_pos1:=1;
    v_len:=NVL(LENGTH(g_genif_if_types),0);
    LOOP
step:='21:Parsing parameter';
        v_pos2:=NVL(INSTR(g_genif_if_types,';',v_pos1),0);
        IF v_pos2 = 0 THEN
            v_pos2:=v_len+1;
        END IF;
        v_if_type:=TRIM(SUBSTR(g_genif_if_types,v_pos1,v_pos2-v_pos1));
        ---
        IF v_if_type IS NOT NULL THEN
            msg:='Acc_Import_Sync_GENIF_IDS processing if_type = '||v_if_type;
            err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);


step:='30:Loop for each GENIF_LINKS.link_id';
--- Loop for each GENIF_LINKS.link_id
            gl_chk:=0;
            FOR gl IN gl_cursor(v_if_type) LOOP
step:='31';
                gl_chk:=gl_chk+1;
                msg:='Acc_Import_Sync_GENIF_IDS processing link_id = '||gl.link_id;
                err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);

step:='32';
                time1:=DBMS_UTILITY.get_time;

step:='33';
                IF v_base_link_id IS NULL THEN
                --- Full processing

step:='40:Retrieving source';
                    v_base_link_id:=gl.link_id;
-- Part 1 - Deleting
step:='41:DELETE FROM GENIF_IDS';
                    DELETE FROM GENIF_IDS g
                     WHERE g.link_id   = v_base_link_id
                       AND g.layer_id IN ('R','F')
                       AND g.id_id     = 'MRC'
                    ;
-- Part 3 - Inserting
step:='42:INSERT INTO GENIF_IDS (source)';
                    --- R(tps) - d.department to d.amex_code
                    INSERT INTO GENIF_IDS
                    (link_id, layer_id, id_id, from_id, to_id)
                    SELECT DISTINCT v_base_link_id,'R','MRC',d.department,d.amex_code
                      FROM departments d
                     WHERE d.card_type         in (v_card_type,v_card_type2)
                       AND RTRIM(d.amex_code) IS NOT NULL
                    ;
step:='43:INSERT INTO GENIF_IDS (data)';
                    --- F(oreign) - d.amex_code to d.department
                    INSERT INTO GENIF_IDS
                    (link_id, layer_id, id_id, from_id, to_id)
                    SELECT g.link_id, 'F', g.id_id, g.to_id, g.from_id
                      FROM GENIF_IDS g
                     WHERE g.link_id   = v_base_link_id
                       AND g.layer_id  = 'R'
                       AND g.id_id     = 'MRC'
                    ;
-- Part 3 - Commiting
step:='44:COMMIT';
                    COMMIT
                    ;


                ELSIF gl.link_id <> v_base_link_id THEN /* Avoiding CFG duplicates, which cause data loss */
                --- Simple processing, using already synchronized data

-- Part 1 - Deleting
step:='51:DELETE FROM GENIF_IDS';
                    DELETE FROM GENIF_IDS g
                     WHERE g.link_id   = gl.link_id
                       AND g.layer_id IN ('R','F')
                       AND g.id_id     = 'MRC'
                    ;
-- Part 3 - Inserting
step:='53:INSERT INTO GENIF_IDS';
                    INSERT INTO GENIF_IDS
                    (link_id, layer_id, id_id, from_id, to_id)
                    SELECT gl.link_id, g.layer_id, g.id_id, g.from_id, g.to_id
                      FROM GENIF_IDS g
                     WHERE g.link_id   = v_base_link_id
                       AND g.layer_id IN ('R','F')
                       AND g.id_id     = 'MRC'
                    ;

step:='54:COMMIT';
                    COMMIT
                    ;


                END IF; /* IF v_base_link_id IS NULL THEN */


step:='34';
                time2:=DBMS_UTILITY.get_time;
                msg:='Acc_Import_Sync_GENIF_IDS Synchronization complete in '||t_string(time2-time1);
                err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);


step:='35';
            END LOOP; /* FOR gl IN gl_cursor(v_if_type) LOOP */


step:='80:CHECK';
            IF gl_chk=0 THEN
                msg:='Acc_Import_Sync_GENIF_IDS skipped, no suitable LINK_ID found for if_type = '||v_if_type;
                err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
            END IF;

        END IF; /* IF v_if_type IS NOT NULL THEN */

step:='22:Parsing parameter';
        ---
        v_pos1:=v_pos2+1;
        IF v_pos1 > v_len THEN
            EXIT;
        END IF;

    END LOOP;


EXCEPTION WHEN FATAL_ERROR THEN
        err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
        --RAISE; finish without exception

    WHEN OTHERS THEN
        msg:='Acc_Import_Sync_GENIF_IDS unexpected error ['||step||']: '||SQLERRM;
        err.errorlog(235,SUBSTR(msg,1,255),NULL,NULL);
        RAISE;

END Acc_Import_Sync_GENIF_IDS;
/

