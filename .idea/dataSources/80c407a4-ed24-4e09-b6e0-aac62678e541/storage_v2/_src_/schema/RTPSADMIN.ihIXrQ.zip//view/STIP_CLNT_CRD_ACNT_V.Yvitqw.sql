create view STIP_CLNT_CRD_ACNT_V as
SELECT
		h.centre_id AS h_centre_id,
		h.effective_date AS h_effective_date,
		h.update_date AS h_update_date,
		h.purge_date AS h_purge_date,
		h.crd_holdr_id AS h_crd_holdr_id,
		h.parent_centre_id AS h_parent_centre_id,
		h.parent_crd_holdr_id AS h_parent_crd_holdr_id,
		h.crd_holdr_pwd AS h_crd_holdr_pwd,
		h.crd_holdr_msg AS h_crd_holdr_msg,
		h.param_grp_1 AS h_param_grp_1,
		h.param_grp_2 AS h_param_grp_2,
		h.acnt_change AS h_acnt_change,
		h.crd_holdr_name AS h_crd_holdr_name,
		h.comm_grp AS h_comm_grp,
		h.add_info AS h_add_info,
		h.person_code AS h_person_code,
		v."A_CENTRE_ID",v."A_EFFECTIVE_DATE",v."A_UPDATE_DATE",v."A_CRD_HOLDR_ID",v."A_ACCOUNT_TYPE",v."A_ACCOUNT_ID",v."A_ACCOUNT_CCY",v."A_INITIAL_AMOUNT",v."A_BONUS_AMOUNT",v."A_ACCOUNT_ID_BANK",v."A_ADD_INFO",v."A_CREDIT_LIMIT",v."A_LOCK_TIME",v."A_LOCK_AMOUNT_CMS",v."A_AMOUNT_SET_TIME",v."A_COMM_GRP",v."A_SHADOW_AMOUNT",v."A_TIME_STAMP",v."A_PRIORITY",v."A_STATUS",v."A_CREDIT_LIMIT_EXPIRY",v."A_BONUS_AMOUNT_EXPIRY",v."A_LOCK_AMOUNT_CMS_OFL",v."A_OFFLINE_LOCKED",v."A_OFFLINE_CLEARED",v."C_CENTRE_ID",v."C_EFFECTIVE_DATE",v."C_UPDATE_DATE",v."C_PREF_REC_NUM",v."C_CARD_NUMBER",v."C_CRD_HOLDR_ID",v."C_CRD_HOLDR_NAME",v."C_CRD_HOLDR_PWD",v."C_CRD_HOLDR_MSG",v."C_PARAM_GRP_1",v."C_PARAM_GRP_2",v."C_ACNT_RESTR",v."C_AVLAMNT_FLAG",v."C_STAT_CODE_1",v."C_STAT_CODE_2",v."C_EXPIRY_DATE_1",v."C_EXPIRY_DATE_2",v."C_CVC_STRIPE_1",v."C_CVC_STRIPE_2",v."C_CVC_PRINT_1",v."C_CVC_PRINT_2",v."C_PVV_CODE_1",v."C_PVV_CODE_2",v."C_PVV_COUNT_1",v."C_PVV_COUNT_2",v."C_TRACK_1_1",v."C_TRACK_1_2",v."C_TRACK_2_1",v."C_TRACK_2_2",v."C_COMM_GRP",v."C_PVV_CODE_1_CHG",v."C_PVV_CODE_2_CHG",v."C_PVV_CODE_1_DATE",v."C_PVV_CODE_2_DATE",v."C_PVV_CODE_1_PRV",v."C_PVV_CODE_2_PRV",v."C_ADD_INFO",v."C_CARD_SEQ_1",v."C_CARD_SEQ_2",v."C_PKI_1",v."C_PKI_2",v."C_DKI_1",v."C_DKI_2",v."C_APP_ID",v."C_OFFL_LIMIT_1",v."C_OFFL_LIMIT_2",v."C_OFFL_LIMIT_CTRL",v."C_CLIENT_ID",v."C_PVV_COUNT_1_CHG",v."C_PVV_COUNT_2_CHG",v."C_PVV_CODE_1_ALG",v."C_PVV_CODE_2_ALG"
	FROM
		stip_clients h INNER JOIN stip_card_accounts_v2 v
		ON h.centre_id = v.a_centre_id AND h.crd_holdr_id = v.a_crd_holdr_id
	with check option
/

