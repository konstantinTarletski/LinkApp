create view STIP_ISSUERS as
select
     proc_ent.centre_id
    ,proc_ent.prevalid_flag
    ,proc_ent.advice_flag
    ,proc_ent.authdat_alg_nr
    ,proc_ent.authdat_path
    ,proc_ent.abbreviature
    ,proc_ent.description
from
    processing_entities  proc_ent
	where proc_ent.enable_flag = 'T' AND
	proc_ent.stip_flag = 'T'
	with check option
/

comment on column STIP_ISSUERS.CENTRE_ID is 'STIP principal processing entity identifier'
/

comment on column STIP_ISSUERS.PREVALID_FLAG is 'Request prevalidation enable flag'
/

comment on column STIP_ISSUERS.ADVICE_FLAG is 'Advice message generation necessity flag'
/

comment on column STIP_ISSUERS.FILE_ALG_NR is 'ASCII data files import/export algorithm number'
/

comment on column STIP_ISSUERS.AUTHDAT_PATH is 'Stand-In processing data files path and name'
/

comment on column STIP_ISSUERS.ABBREVIATURE is 'Stand-In principal processing entity abbreviature'
/

comment on column STIP_ISSUERS.DESCRIPTION is 'Stand-In principal processing entity description'
/

