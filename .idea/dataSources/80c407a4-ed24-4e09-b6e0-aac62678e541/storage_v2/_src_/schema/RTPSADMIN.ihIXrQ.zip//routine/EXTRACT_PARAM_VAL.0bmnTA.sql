create FUNCTION EXTRACT_PARAM_VAL (params IN varchar2, paramname IN varchar2, delim IN varchar2 DEFAULT '|', eqchar IN varchar2 DEFAULT '=')
/*
 * DESCRIPTION
 *
 * Extracts the value of a parameter 'paramname' from string of parameter-value
 * pairs 'params'.
 * Parameter-value pairs are delimited with string 'delim'.
 * Parameter and it's value are separated with string 'eqchar'.
 * There must be no whitespaces between parameter name and 'eqchar'.
 * The returned param value is stripped of leading and trailing spaces.
 *
 *
 * EXAMPLE USAGE
 *
 *   extract_param_val('fruit=  orange |vegetable=cabbage', 'fruit', '|', '=')
 * will return string 'orange'.
 */
RETURN varchar2 IS
    istart int;
    iend int;
    idelimlen int;
    inamelen int;
    sval varchar2 (512);
    sname varchar2 (512);
BEGIN
    -- Find start of param-val pair
    sname := paramname || eqchar; -- prevent instr(params, 'ccy') from matching 'ccy_alpha' etc.
    istart := instr(params, sname);
    if istart = 0 then
        return NULL;
    end if;

    -- Find end of param-val pair
    iend := instr(params, delim, istart);
    if iend = 0 then -- this param is the last in the string
        iend := length(params);
        idelimlen := 0;
    else
        idelimlen := length(delim);
    end if;

    -- Extract parameter value
    inamelen := length(sname);
    sval := substr(
                params,
                istart + inamelen,
                iend - istart - inamelen + length(eqchar) - idelimlen
            );
    return trim(sval);
END;
/

