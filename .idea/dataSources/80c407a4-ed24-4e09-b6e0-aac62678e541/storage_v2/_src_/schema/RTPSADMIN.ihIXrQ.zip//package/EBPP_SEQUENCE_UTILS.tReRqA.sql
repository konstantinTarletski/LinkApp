create PACKAGE ebpp_sequence_utils AS
  PROCEDURE fix_configuration_sequences;
END;
/

