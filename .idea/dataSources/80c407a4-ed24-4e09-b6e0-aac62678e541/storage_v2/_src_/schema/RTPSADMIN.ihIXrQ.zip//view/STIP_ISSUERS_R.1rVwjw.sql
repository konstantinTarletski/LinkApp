create view STIP_ISSUERS_R as
SELECT
	pe.centre_id,
	pe.abbreviature,
	pe.description,
	pe.iss_bank,
	pe.params_type,
	pe.prevalid_flag,
	pe.unlock_type
FROM
	processing_entities  pe
WHERE pe.enable_flag = 'T'
	AND pe.stip_flag = 'T'
	AND EXISTS (
		SELECT NULL
		FROM centre_users
		WHERE centre_id = pe.centre_id AND username = USER )
WITH CHECK OPTION
/

comment on column STIP_ISSUERS_R.CENTRE_ID is 'STIP principal processing entity identifier'
/

comment on column STIP_ISSUERS_R.ABBREVIATURE is 'Stand-In principal processing entity abbreviature'
/

comment on column STIP_ISSUERS_R.DESCRIPTION is 'Stand-In principal processing entity description'
/

comment on column STIP_ISSUERS_R.ISS_BANK is 'Issuer bank code'
/

comment on column STIP_ISSUERS_R.PARAMS_TYPE is 'Parametric restrictions algorithm'
/

comment on column STIP_ISSUERS_R.PREVALID_FLAG is 'Request prevalidation enable flag'
/

comment on column STIP_ISSUERS_R.UNLOCK_TYPE is 'Unlock type'
/

