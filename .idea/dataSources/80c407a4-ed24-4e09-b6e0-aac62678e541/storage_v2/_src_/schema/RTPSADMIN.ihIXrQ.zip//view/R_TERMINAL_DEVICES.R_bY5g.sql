create view R_TERMINAL_DEVICES as
SELECT "TERMINAL_DEVICE_ID",
          "TERMINAL_DEVICE_NAME",
          "TERMINAL_DEVICE_MERCHANT",
          "DEVICE_NAME",
          "DEVICE_ID",
          "DEVICE_MERCHANT",
          "DEVICE_AUDIT"
     FROM (SELECT t.device_id AS terminal_device_id,
                  t.device_name AS terminal_device_name,
                  t.device_merchant AS terminal_device_merchant,
                  d.device_name AS device_name,
                  d.device_id AS device_id,
                  d.device_merchant AS device_merchant,
                  d.device_audit AS device_audit
             FROM r_terminals t, atm_devices d
            WHERE t.device_name = D.TERMINAL_ID)
/

