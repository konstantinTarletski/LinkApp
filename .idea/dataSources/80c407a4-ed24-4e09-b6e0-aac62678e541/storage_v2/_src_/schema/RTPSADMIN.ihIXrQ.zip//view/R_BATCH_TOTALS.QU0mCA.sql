create view R_BATCH_TOTALS
            (TRN_AMT, TRN_CCY, TRN_CCY_EXP, BATCH_ID, BATCH_OWNER, TERMINAL_ID, RECONCILE_DATE, RECONCILE_CNTR, DC_IND,
             IS_REVERSAL, DEVICE_AUDIT)
as
select sum(r.trn_amt) as trn_amt, r.trn_ccy, r.trn_ccy_exp, r.batch_id, r.batch_owner, r.terminal_id,
        trunc(r.reconcile_date), r.reconcile_cntr, r.dc_ind, r.is_reversal, r.acq_ref_data as device_audit
from r_batch_trn r
group by  batch_id, batch_owner, reconcile_date, acq_ref_data, trn_ccy, trn_ccy_exp,   terminal_id,
        reconcile_cntr, dc_ind, is_reversal
order by trn_ccy,dc_ind,batch_id,reconcile_cntr,reconcile_date
/

