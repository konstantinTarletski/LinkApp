create PACKAGE
/* $HeadURL$ $Id$ */
STIP_SCOUR IS
/******************************************************************************\
 RTPS.IIA.RECALC
 Autorizaacijas informaacijas kontrole, atblokeeshana peec noilguma
 ------------------------------------------------------------------------------
 Copyright (C) 2002 TietoEnator Financial Solutions
 ==============================================================================
 $HeadURL$ $Id$
\******************************************************************************/
	------------------------------------------------------------------------------
	-- Atblokkeessana peec noilguma (old way)
	PROCEDURE scour(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT '%');
	------------------------------------------------------------------------------
	-- Delete Old Pin Counters by delay
	PROCEDURE scour_del_pin_cntrs(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT '%', is_independent_call BOOLEAN DEFAULT TRUE);
	------------------------------------------------------------------------------
	-- Unlock waste authorizations by delay
	PROCEDURE unlock_waste_auth(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT '%', is_independent_call BOOLEAN DEFAULT TRUE);
	------------------------------------------------------------------------------
	-- Exchange authorizations currency by delay
	PROCEDURE curr_xch(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT '%', is_independent_call BOOLEAN DEFAULT TRUE);
	------------------------------------------------------------------------------
	-- Unlock by delay
	PROCEDURE scour_unlock(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT '%', is_independent_call BOOLEAN DEFAULT TRUE);
	------------------------------------------------------------------------------
	-- 24H akumulaatoru paarreekkins
	PROCEDURE day_limits_recalc(p_hist_numb NUMBER,p_centre_id VARCHAR2 DEFAULT NULL);
	------------------------------------------------------------------------------
	-- Gara posma akumulaatoru paarreekkins. Akumulaatoru kontrole un dzeessana
	PROCEDURE Long_Limits_Recalc(hist_numb INTEGER, p_centre_id VARCHAR2 DEFAULT NULL);
	------------------------------------------------------------------------------
	-- Autorizaaciju veestures paardaliishana
	PROCEDURE split(hist_numb INTEGER);
	------------------------------------------------------------------------------
	PROCEDURE az_set_cfg(p_cfg VARCHAR2);
	FUNCTION az_cfg RETURN BOOLEAN;
	--
	-- Dzeesh PIN skaitiitaajus noteiktam vai visiem centriem
	--
	procedure reset_pin_counters(p_hist_numb NUMBER,p_centre_id VARCHAR2 DEFAULT NULL);
END;
/******************************************************************************\
 * $Log: stip_scour-package.sql,v $
 * Revision 1.33  2006/03/28 09:52:06  karlisl
 * bug 12467 - problem when recalc can not find correct lock to change account. rowid fixed
 *
 * Revision 1.32  2004/01/08 11:28:21  kovacs
 * - Pielikta funkcija kas dzeesh PIN skaitiitaajus vienam vai visiem centriem
 *
 * Revision 1.31  2003/02/14 11:48:31  vilis
 * scour now can be called with parameter centre_id
 * that can be mask as in like expressions;
 * when selecting records for unlocking by delay
 * dont check for correspondend record existence in stip_locks
 *
 * Revision 1.30  2003/02/07 13:14:42  vilis
 * stip_scour: curr_xch and unlock_waste_auth can be called
 * with centre_id as parameter
 *
 * Revision 1.29  2003/01/23 12:45:05  vilis
 * Revision added
 *
 * Revision 1.28  2003/01/23 11:47:45  vilis
 * Zem unlock_waste_auth 3 vienaadie selecti iznesti atsevishkjaa
 * funkcijaa find_account_id ...
 *
 * Revision 1.27  2003/01/13 15:52:49  kovacs
 * - Atjaunoti header komentaari
 *
 * Revision 1.26  2003/01/02 11:16:36  vilis
 * Added hist_numb parameter to unlock_waste_auth because it now can be called
 * from external source ...
 *
 * Revision 1.25  2002/12/23 14:56:22  vilis
 * New unlocking fixes
 *
 * Revision 1.24  2002/12/17 10:47:02  vilis
 * Fixed duplicated errorcodes
 *
 * Revision 1.20  2002/10/31 15:26:09  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.19  2001/12/22 16:15:31  kovacs
 * Some updates.
 *
 * Revision 1.18  2001/12/21 15:49:00  kovacs
 * No SCOUR aaraa iznests split.
 *
 * Revision 1.17  2001/11/09 14:22:06  kovacs
 * Pielikts MIN_INTERVAL_MINUTES iespeeja long periodam.
 *
 * Revision 1.15  2001/10/12 14:36:48  karlis
 * Turpinaas optimizaacija 24H un garajam periodam.
 *
 * Revision 1.13  2001/08/24 09:27:18  uldis
 * Izdz'estas tuk's'as rindi'nas programmas tekst'a.
 *
 * Revision 1.12  2001/05/11 17:18:40  isais
 * (modifications)
 * - Modifikaacijas sakaraa ar jauno parametrisko paarbauzhu veida pievieshanu.
 *
 * Revision 1.11  2001/02/06 10:41:52  karlis
 * Pielikts ANALYZE pirms vissu batch uzdevumu palaissanas.
 *
 * Revision 1.10  2000/10/09 14:13:14  karlis
 * Tekossaa versija paarvietota no zara WORKING_RECALC uz tekosso zaru. BANKMASTER
 * zars, kurss agraak bija tekossais - ietaagots ar tag-u BANKMASTER_RECALC.
 *
 * Revision 1.6.2.2  2000/03/30 09:46:06  karlis
 * Izmainnas sakara ar UPC pieprasiijumu 2203K150. Bija neapmierinossa aatrdarbiiba
 * un akumulaacijas limitu paarreekkina laikaa blokkeejaas akumulaatoru
 * raksti, kaa rezultaataa nevareeja notikt autorizaacija atbilstossajaam
 * karteem. Risinaajums => Uzdevums sadaliits triis atsevisskkos (24H limitu
 * paarreekkina, garaa posma limitu paarreekkina, atblokkeessana peec noilguma).
 * Paarreekkinot akumulaatorus tiek taisiits COMMIT peec katra raksta.
 *
 * Revision 1.6  1999/11/10 20:35:20  karlis
 * Atpakall vecaa straadaajossaa versija, kurai bija uzblieztas
 * pa virsu BS on-line izmainnas, bet nebija izveidots zars.
 *
 * Revision 1.4  1999/07/15 20:50:01  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/03/25 15:13:29  uldis
 * Tiek nodroshinaata Kontu piemekleeshana autorizaacijaam, kuraam vairs
 * neeksistee atbilstoshais konts.
 *
 * Revision 1.2  1999/01/22 17:39:34  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:00  uldis
 * Created by Uldis Anshmits
\******************************************************************************/
/

