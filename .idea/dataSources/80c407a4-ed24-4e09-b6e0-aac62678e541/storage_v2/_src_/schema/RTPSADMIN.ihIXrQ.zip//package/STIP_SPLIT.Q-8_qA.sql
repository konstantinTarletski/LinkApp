create package
/* $HeadURL$ $Id$ */
stip_split is
------------------------------------------
-- Autorizaaciju veestures paardaliishana
-------------------------------------------
procedure split(hist_numb integer, p_logLevel number, p_analyze number);
end;
/

