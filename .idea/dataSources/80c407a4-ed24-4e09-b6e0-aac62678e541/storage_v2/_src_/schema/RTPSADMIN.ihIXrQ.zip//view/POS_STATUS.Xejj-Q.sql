create view POS_STATUS as
SELECT
    T.TERMINAL_ID
FROM
    merchant_terminals  t,card_merchants c
WHERE t.merchant_id=c.merchant_id and c.mcc_code<>'6011'
 WITH CHECK OPTION
/

