create view R_CASH_STATUS_CURRENT_GROUPS as
SELECT
    b.terminal_group_id,
    a.terminal_device_id,
    a.terminal_device_name,
    a.device_id,
    a.device_name,
    a.device_audit,
    a.cash_type,
    a.accum_name,
    a.accum_count,
    a.curr_num,
    a.curr_alpha,
    a.curr_exp_dot,
    a.accum_denom,
    a.accum_amount
FROM
    r_cash_status_current a,
    atm_terminal_group_members b
WHERE
    a.terminal_device_name=b.terminal_id
ORDER BY a.cash_type,a.terminal_device_id, a.terminal_device_name, a.curr_num, a.device_id, a.device_name, a.accum_denom
/

