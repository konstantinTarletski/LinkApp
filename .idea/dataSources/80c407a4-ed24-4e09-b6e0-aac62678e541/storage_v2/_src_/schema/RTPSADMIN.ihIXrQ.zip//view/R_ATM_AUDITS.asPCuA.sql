create view R_ATM_AUDITS as
SELECT distinct d.device_merchant,d.device_name, a.device_id, a.device_audit,
        d.device_name||a.device_audit as trx_trx_file
  FROM atm_events a, atm_devices d
  where a.device_id=d.device_id
union
SELECT distinct d.device_merchant,d.device_name, d.device_id, d.device_audit,
        d.device_name||d.device_audit as trx_trx_file
  FROM atm_events a, atm_devices d
  where a.device_audit != d.device_audit
/

