create PACKAGE
/*@ITEM_ID_VERSION@*/
STIP_AIS_UPDATE_UTIL
IS
/*@ITEM_ID_VERSION@*/
/******************************************************************************\
--# RTPS.IIA.AIS
--#	IZMAINNU PIELIETOSSANA AUTORIZAACIJAS DATU TABULAAM.
--# (C) TietoEnator Financial Systems Ltd. 1998-2004
\******************************************************************************/

	type t_Status_Record is record(
		table_name   varchar2(32),
		hist_numb    number,
		rows_dat_del number,
		rows_rej_del number,
		rows_ign_del number,
		rows_dat_upd number,
		rows_rej_upd number,
		rows_ign_upd number,
		rows_dat_ins number,
		rows_rej_ins number,
		rows_ign_ins number,

		orig_rows_dat_del number,
		orig_rows_dat_upd number,

		orig_rows_dat_ins  number,
		total_rows_dat_ins number,

		total_rows_dat_upd number,
		total_rows_dat_del number
	);

	function updateStipMessExp(p_centre_id varchar2, p_tran_id varchar2, p_row_numb number) return boolean;
	function synchroniseUpdateWithCMS(bankId varchar2, cardGroup varchar2, dbScheme varchar2, dbLinkName varchar2, p_synchronise boolean default false) return boolean;
	procedure desynchroniseUpdateWithCMS(bankId varchar2, cardGroup varchar2, dbScheme varchar2, dbLinkName varchar2, p_synchronise boolean default false);
	function getDBLinkName(importUrl varchar2, schemeName out varchar2, dbLinkName out varchar2) return boolean;
	PROCEDURE setInitialValues(p_centre_id varchar2, p_bank_c varchar2, p_groupc varchar2, p_imp_url varchar2, p_effective date, p_hist_numb number, p_authdat_alg_nr number, p_new_del_select number);
	procedure UpdateStats(p_full boolean, p_TableName varchar2,p_Stats in out t_Status_Record);
	function t_string(totals number) return varchar2;
	procedure GetTime(totals out number);
	procedure resetStatsRecord(p_stats in out t_Status_Record);
	procedure LoadStatsRecord(p_centre_id varchar2, p_hist_numb number, p_effective date, p_table_name varchar2, p_Stats in out t_Status_Record);
	function get_table_name(table_type varchar2,center_id varchar2,bank_c varchar2,groupc varchar2) return varchar2;
	--------------------------------------------------------------------------------------
	function DeleteRestrictedAccounts(l_full boolean,
								l_restracnt_table varchar2,
								l_rst in out t_Status_Record,
								p_from date,
								p_to date,
								l_commit_count number,
								p_relinkWindow number,
								l_detectAndPerformRelink number,
								p_account_id varchar2 default null,
								p_crd_holdr_id varchar2 default null,
								p_card_number varchar2 default null,
								p_commit_off integer default 0,
								p_single_card_update boolean default false) return boolean;

	function deleteChipApp(l_full boolean,l_chipAppTable varchar2,p_from date, chipgroupc number) return boolean;
	function deleteChipCmd(l_full boolean,l_chipCmdTable varchar2,p_from date) return boolean;
	function deleteChipCmdSet(l_full boolean,l_chipCmdSetTable varchar2,p_from date, chipgroupc number) return boolean;
	function DeleteLimitsCrd(p_full boolean,p_limitsCrdTable varchar2,p_from date) return boolean;
	/* function deletePseudo(p_pseudo_table varchar2,p_from date) return boolean;*/

	function deleteLimitsCrdGrp(p_full boolean,
								p_limitsCrdGrpTable varchar2,
								p_from date) return boolean;

	procedure match_waste_auth(p_hist_numb number,
								p_centre_id varchar2 default null);

	procedure updateCardOfflineParams(p_centre_id varchar2,
								p_card_number varchar2,
								p_card_seq varchar2,
								p_old_limit number,
								p_new_limit number);
	--------------------------------------------------------------------------------------
	function delete_fee(p_full boolean,
								p_fee_stat in out t_Status_Record,
								p_fee_table varchar2,
								p_from date) return boolean;

	function delete_combi(p_full boolean, p_table varchar2, p_card_number varchar2 default null, p_commit_off integer default 0) return boolean;

	function update_fee(p_full boolean,
							p_fee_stat in out t_Status_Record,
							p_fee_table varchar2,
							p_from date,
							p_to date,
							p_rng number,
							p_cms_fee_type number) return boolean;


	function loadAccountsIntoLocalTable(p_account_table varchar2, p_from date, p_to date, p_cms_2_acnt_structure number default 0) return boolean;
	function truncate_table(p_hist_numb number, p_center_id varchar2, p_effective date, p_table_name varchar2) return boolean;

	function IsCardRenewal(p_cms_expiry in varchar2, p_iia_expiry_1 in varchar2, p_iia_expiry_2 in varchar2,
		p_cms_card_seq in varchar2, p_iia_card_seq_1 in varchar2, p_iia_card_seq_2 in varchar2) return boolean;
	function EnqueuePinChangeChipCmd(p_centre_id in varchar2, p_card_number in varchar2,
		p_expiry_date in varchar2, p_card_seq in varchar2, p_cur_cnt in number, p_msg in varchar2) return boolean;

	function with_index_check(p_authdata_alg_nr in number, p_name_for_table in varchar2,
								p_alias in varchar2, p_rec_filter_fld1 in varchar2, p_rec_filter_fld2 in varchar2 default null) return varchar2;

	procedure print_action_statistic(p_stats in t_Status_Record);
	procedure print_action_simple_statistic(p_stats in t_Status_Record);
	procedure print_del_action_stats(p_stats in t_Status_Record);

	function table_field_exists(p_table_name in varchar2, p_column_name in varchar2) return boolean;

end;
/

