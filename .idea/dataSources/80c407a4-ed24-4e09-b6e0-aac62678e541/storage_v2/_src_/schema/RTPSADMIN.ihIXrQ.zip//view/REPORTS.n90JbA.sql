create view REPORTS as
select report_id,id,parent_id,data_type,data from rtps_reports
where sessionid=userenv('SESSIONID')
/

