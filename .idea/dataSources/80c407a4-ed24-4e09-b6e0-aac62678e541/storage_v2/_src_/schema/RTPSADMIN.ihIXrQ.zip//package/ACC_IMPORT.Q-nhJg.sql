create Package
/* $HeadURL$ $Id$ */
acc_import IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
   PROCEDURE acc_import(hist_numb INTEGER);
END;
/*= History =============================================================
 * $Log: acc_import-package.sql,v $
 * Revision 1.6  2002/10/31 15:25:02  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.5  2000/10/02 08:38:08  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.4  1999/09/22 13:55:27  uldis
 * Atbilsto'si piepras'ijumam K99/409 (BSC 99/066) no MPCS netiek import'eti
 * tirdzniec'ibas punkti ar satusu=3, turkl'at import'e'sanas nosac'ijumi
 * l'igumiem ir nomain'iti t'a lai sakr'it ar nosac'ijumiem import'a uz TVS:
 * tiek import'eti l'igumi ar statusu 0 vai 1. L'idz 'sim tika import'eti
 * ar statusu <>3.
 *
 * Revision 1.3  1999/07/15 20:50:27  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.2  1999/01/22 17:40:09  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:05  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

