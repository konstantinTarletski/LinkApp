create view STIP_COMMISSIONS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.comm_grp,
		x.comm_id,
		x.priority,
		x.rule_expr,
		x.comm_proc,
		x.comm_min,
		x.comm_max,
		x.comm_const,
		x.fee_type,
		x.rev_fee_type,
		x.comm_ccy,
		x.description
	from STIP_COMMISSIONS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

