create PACKAGE
/* $HeadURL$ $Id$ */
STIP_CALENDAR_LIMITS is
--==============================================================================
--	RTPS.IIA
--	API priekss Daily limits, izsaukts tiek no Call center pakotnes
--
--	$HeadURL$ $Id$
--==============================================================================
--========================================================================
-- Peedeejaas klluudas kods un texts
--========================================================================
	procedure GetLastError(
		p_errortext_maxlen in number,
		p_errorcode out number,
		p_oraerrcode out number,
		p_errortext out varchar2
	);
--========================================================================
-- Seting card limits for calendar limits
--========================================================================
    function SetCrdLimit(
    	p_bank_c in	varchar2,
    	p_groupc in varchar2,
    	p_ctime in date,
    	p_data_action in char,
    	p_card_number in varchar2,
    	p_limit_id in varchar2,
    	p_limit_type in char,
    	p_limit_ccy in char,
    	p_period_type in char,
    	p_amount in number,
    	p_count in number,
    	p_amount_extra in number,
    	p_count_extra in number,
    	p_expiry_extra in date,
    	p_answ_code_amount in char,
    	p_answ_code_count in char
    ) return boolean;
--========================================================================
-- Seting card group limits for calendar limits
--========================================================================
    function SetCrdGrpLimit(
   		p_bank_c in	varchar2,
	   	p_groupc in varchar2,
	   	p_ctime in date,
	   	p_data_action in char,
	   	p_param_grp in varchar2,
	   	p_limit_id in varchar2,
	  	p_limit_type in char,
	   	p_limit_ccy in char,
	   	p_period_type in char,
	  	p_amount in number,
	   	p_count in number,
	   	p_amount_extra in number,
   		p_count_extra in number,
		p_expiry_extra in date,
	   	p_answ_code_amount in char,
	   	p_answ_code_count in char
    ) return boolean;
--========================================================================
-- Seting card limits for calendar limits
--========================================================================
	function ResetCardAccum(
			p_centre_id in varchar2,
			p_card_numb in varchar2) return boolean;
--================================================================================
-- $Log: stip_calendar_limits-package.sql,v $
-- Revision 1.5  2005/03/17 12:54:03  kovacs
-- - Pielikta akumulatoru nomeshana prieksh kalendarajiem limitiem
--
-- Revision 1.4  2005/03/17 10:48:35  kovacs
-- - Saakta likt klaat akumulatoru resetoshana
--
-- Revision 1.3  2004/01/23 13:12:30  karlis
-- Klluudu reggistreessanai netiek izsauktas funkcijas no STIP_CALL_API
--
-- Revision 1.2  2003/10/31 15:56:44  kovacs
-- Pielikta log faila rakstiishana kalendaaro limitu funkcijaam
--
-- Revision 1.1  2003/09/23 10:05:52  kovacs
-- Pieliktas kalendaaro limitu funkcijas
--
--================================================================================
end;
/

