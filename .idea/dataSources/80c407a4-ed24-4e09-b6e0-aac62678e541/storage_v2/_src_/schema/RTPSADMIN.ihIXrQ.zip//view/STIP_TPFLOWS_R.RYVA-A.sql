create view STIP_TPFLOWS_R as
select
		x.grp,
		x.flow_id,
		x.description
	from STIP_TPFLOWS x
/

