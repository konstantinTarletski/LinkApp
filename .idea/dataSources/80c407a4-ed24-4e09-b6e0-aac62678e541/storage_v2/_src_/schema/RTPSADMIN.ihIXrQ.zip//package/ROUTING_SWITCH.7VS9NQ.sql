create Package
/* $HeadURL$ $Id$ */
ROUTING_SWITCH  IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	TYPE rsw_record IS RECORD
		(
		msg_error_code	number
		,msg_arguments	varchar2(1000)
		,rsw_stip_flag	char(1)
		,rsw_prevalid_flag	char(1)
		,rsw_advice_flag	char(1)
		,rsw_online_flag	char(1)
		,rsw_offline_flag	char(1)
		,rsw_iss_bank	varchar(2)
		,rsw_centre_service	varchar(15)
		,rsw_centre_address	varchar(30)
		,rsw_capture_flag	char(1)
		,msg_type	char(4)
		,rsw_stip_substit_svc	varchar(15)
		);
	TYPE messages_log_record is record
 (
  row_numb                   NUMBER(11),
  locality_flag              CHAR(1),
  stan_internal              CHAR(6),
  card_type                  CHAR(2),
  dev_type                   CHAR(1),
  msg_type_in                CHAR(4),
  epi_48_42                  VARCHAR2(3),
  fld_002                    VARCHAR2(19),
  fld_003                    CHAR(6),
  fld_004                    NUMBER(12),
  fld_006                    NUMBER(12),
  fld_010                    NUMBER(16,9),
  fld_022                    CHAR(12),
  fld_033                    VARCHAR2(11),
  fld_039                    CHAR(3),
  fld_049                    CHAR(3),
  fld_051                    CHAR(3),
  fld_091                    CHAR(3),
  fld_093                    VARCHAR2(11),
  fld_100                    VARCHAR2(11)
 );
	PROCEDURE call_plsql(f IN OUT messages_log_record,proc_name varchar2,rsw in out rsw_record);
	PROCEDURE repeated_message(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE check_stoplist(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE card_prefix_quest(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE acq_auth(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE acq_agreements(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE iss_auth(f  IN OUT messages_log_record,rsw in out rsw_record);
END;
/*= History =============================================================
 * $Log: routing_switch-package.sql,v $
 * Revision 1.1  2009/06/18 09:11:27  uldisa
 * Initial revision
 *
 * Revision 1.2  2003/02/03 11:20:18  raivist
 * acq_auth() CENTRE_SERVICE ieliks RSW_ACQ_SERVICE.
 *
 * Revision 1.1.1.1  2003/01/29 17:09:09  haris
 * Imported
 *
 * Revision 1.10  2002/12/18 13:32:36  uldis
 * Pielikts lauks RSW_STIP_SUBSTIT_SVC, kura v:rtoba tiek nolasota no
 * PROCESSING_ENTITIES.STIP_SUBSTIT_SVC.
 * Izv`kta iespeja izsaukt servisu STIP_PRVALID.
 *
 * Revision 1.9  2002/10/31 15:24:13  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.8  2002/05/09 11:40:33  uldis
 * Lok'al'as pi'e'nem'sanas p'arbaudes p'arnestas uz serveri MESSAGES.
 *
 * Revision 1.7  2001/12/22 13:31:19  uldis
 * gen_batch_id p'arnests uz MESSAGES.
 *
 * Revision 1.6  2001/11/26 14:28:36  tuxedo
 * Pievienota proced'ura acq_agreements.
 *
 * Revision 1.4  2001/08/29 17:09:18  gusts
 * Improved performance by using simple datatype insted of %rowtype.
 *
 * Revision 1.3  2000/12/22 13:44:52  uldis
 * Pievienots lauks msg_type.
 *
 * Revision 1.2  2000/12/13 06:44:13  uldis
 * Pielikti header/footer
 *
 ========================================================================*/
/

