create view POS_PARAMS as
SELECT
     T.TERMINAL_ID
    ,T.FIELD_ID
    ,T.FIELD_DATA
    ,T.TRANSMIT_FLAG
FROM
    terminal_params  t
 WHERE	EXISTS (
 	SELECT NULL FROM merchant_terminals  mt,card_merchants c
	WHERE mt.merchant_id=c.merchant_id and c.mcc_code<>'6011'
	 	and mt.terminal_id=t.terminal_id )
 WITH CHECK OPTION
/

