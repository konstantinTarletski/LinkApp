create view MENU_USER_OPERATIONS as
select /*+ rule */
  MENU_NAME,
  SEL,
  UPD,
  INS,
  DEL,
  EXE
from MENU_ALL_OPERATIONS
where username = user
/

