create view EXPANDED_OBJECT_PRIVS as
SELECT /*+ ALL_ROWS */
        upper(U.USERNAME) GRANTEE,
        P.OWNER,
        O.OBJECT_NAME,
        O.OBJECT_TYPE,
        PRIVILEGE
FROM
        RTPS_USERS U,
        DBA_TAB_PRIVS P,
        DBA_OBJECTS O,
        DBA_ROLE_PRIVS DRP
WHERE
        P.grantee = DRP.granted_role and
        DRP.grantee = upper(U.username) and
        P.table_name = o.object_name and
        p.owner = o.owner
union all
SELECT
        P.GRANTEE,
        P.OWNER,
        O.OBJECT_NAME,
        O.OBJECT_TYPE,
        PRIVILEGE
FROM
        DBA_TAB_PRIVS P,
        DBA_OBJECTS O
WHERE
        P.table_name = o.object_name
        and p.owner = o.owner
/

