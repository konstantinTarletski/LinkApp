create view IRMS_BANKS as
(SELECT "BANK","BANK_NAME" FROM rtps_banks_r)
/

