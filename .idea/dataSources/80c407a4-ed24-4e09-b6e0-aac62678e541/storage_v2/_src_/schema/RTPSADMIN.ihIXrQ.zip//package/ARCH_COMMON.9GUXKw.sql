create Package
/* $HeadURL$ $Id$ */
ARCH_COMMON IS
   PROCEDURE clean_all ( hist_numb INTEGER);
END; -- Package Specification CLEAN

/*= End =============================================================*/
/

