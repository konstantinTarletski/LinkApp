create PACKAGE
/*$HeadURL$ $Id$*/
STIP_WP_API IS
--==============================================================================
--  RTPS.IIA.UI
--
--	Issuer Workplace autorizaaciju summu atblokkeessanas API
--		Kodeja:	Karlis Ogsts
--
--	$HeadURL$ $Id$
--	(C) Tieto Konts Financial Systems Ltd. 1998,1999
--==============================================================================
	--------------------------------------------------------------------------------
	-- Pin skaitiitaaja nomeshana
	--------------------------------------------------------------------------------
	FUNCTION reset_pin_counter(
		p_centre_id IN VARCHAR2,
		p_card_number IN VARCHAR2,
		p_reason IN OUT VARCHAR2
	) RETURN CHAR;
	--=====================================================
	-- Autorizaacijas summas atblokkeessana ar kliiringa
	-- tranzakciju, kad autorizaacija tranzakcijai
	-- piemekleeta ar roku
	--=====================================================
	function manual_match_unlock(p_centre_id varchar2,
					p_auth_row_numb stip_events_n_r.row_numb%type,
					p_tran_rowid rowid,
					p_advc_row_numb out stip_events_n_r.row_numb%type,
					p_message out varchar2) return char;
	--===========================================================
	-- Autorizaacijas atblokkeessana bez kliiringa tranzakcijas
	--===========================================================
	function manual_unlock(p_centre_id varchar2,
					p_auth_row_numb stip_events_n_r.row_numb%type,
                    p_process_child char,
					p_advc_row_numb out stip_events_n_r.row_numb%type,
					p_message out varchar2) return char;
	--=====================================================
	-- Kliiringa tranzakcijai uzdattada paziimi, ka taa ir
	-- apstraadaata, kaut arii nav atblokkeejusi nevienu no
	-- kandidaatautorizaacijaam
	--=====================================================
	function manual_match_delete(p_centre_id varchar2,
					p_tran_rowid rowid,
					p_message out varchar2) return char;
	--=====================================================
	-- Kartes akumulatoru dzeeshana (gan vecai, gan jaunai metodei)
	--=====================================================
	function reset_card_accums(p_centre_id in varchar2, p_card_numb in varchar2) return char;
	--=====================================================
	-- Akumulatora valuuta mainiijusies
	--=====================================================
	function accum_ccy_change(p_centre_id in varchar2, p_risc_group in char) return char;

/*============================================================================*\
Interfeisu konfiguraacijas tabulas(REGDIR) API (wrapper around REG package)
Kodeja: Vilis Sviklis
\*============================================================================*/
function open(name in varchar2,key_out in out number) return char;
function openk(key_in in number,sub_name varchar2,key_out in out number) return char;
function create_key(name in varchar2,key_out in out number) return char;
function create_keyk(key_in in number,sub_name varchar2,key_out in out number) return char;
function getc(name in varchar2,key_value in out varchar2) return char;
function getck(key_in in number,sub_name in varchar2,key_value in out varchar2) return char;
function getn(name in varchar2,key_value in out number) return char;
function getnk(key_in in number,sub_name in varchar2,key_value in out number) return char;
function setn(name in varchar2,key_value in number) return char;
function setnk(key_in in number,sub_name in varchar2,key_value in number) return char;
function setc(name in varchar2,key_value in varchar2) return char;
function setck(key_in in number,sub_name in varchar2,key_value in varchar2) return char;
function enum(name in varchar2,types in char,sub_name in out varchar2,prev_key in out number) return char;
function enumk(key_in in number,types in char,sub_name in out varchar2,prev_key in out number) return char;
function delkey(name in varchar2) return char;
function create_symlink(name in varchar2,link_path in varchar2) return char;
/******************************************************************************\
* $Log: stip_wp_api-package.sql,v $
* Revision 1.34  2003/12/09 21:57:57  vilis
* API function reset_pin_counter added
*
* Revision 1.33  2003/01/16 17:05:29  vilis
* If record in stip_references with same row_numb exist
* then update that record
*
* Revision 1.32  2003/01/13 15:49:31  kovacs
* - Atjaunoti header komentaari
*
* Revision 1.31  2002/12/18 16:54:11  vilis
* cheating package loader
*
* Revision 1.30  2002/12/18 16:50:21  vilis
* cheating package loader
*
*	Revision 1.29  2002/12/18 16:39:57  vilis
*	Some logs added
*
*	Revision 1.28  2002/12/16 15:54:49  vilis
*	WP package calls to unlock fixed;
*	errorcodes fixed;
*
*	Revision 1.26  2002/12/13 11:41:47  vilis
*	New unlocking ... WIP
*
*	Revision 1.22  2002/10/31 15:26:10  uldis
*	Netiek lietots REVISIO N buferis
*
*	Revision 1.21  2002/08/22 12:12:18  karlis
*	Labojuma datums: 22-AUG-2002
*	Labojumi: Kosmeetiski labojumi, izmestas funkcijas, kas kaadreiz bija taisiitas
*		prieks BSIF, bet tagad ir moraali novecojussas.
*
*	Revision 1.20  2002/08/02 09:57:41  vilis
*	Added function accum_ccy_change
*
*	Revision 1.19  2002/03/11 12:23:55  kovacs
*	Safixeets insert.sql
*
*	Revision 1.18  2002/03/08 15:15:07  kovacs
*	Safixeets make fails lai laadee kljuudu pazinjojumus prieksh unlock_n atseviski no unlock
*	Register.sql pielikts, lai registree unlock_n program_names tabulaa.
*	Pielikts lai instalee unlock_n packaagi ieksh install_sh
*
*	Revision 1.17  2002/02/27 11:08:20  kovacs
*	Saakts likt klaat, ka atblokeeshanas f-jas atrodas tikai vienaa packaagee- stip_unlock_n
*
*	Revision 1.16  2001/05/17 13:35:35  isais
*	- reset_card_accums atgriezh char, ne boolean, jo BDE nesaprot boolean
*
*	Revision 1.15  2001/05/17 09:43:51  isais
*	- Pievienots izsaukums uz stip_scour_n.reset_card_accums, lai to var izsaukt no WP.
*
*	Revision 1.14  2000/12/14 10:38:20  karlis
*	Nevareeja atblokkeet ar roku paarskaitiijuma tranzakcijas.
*
*	Revision 1.13  2000/10/02 08:38:02  uldis
*	K'l'udas gad'ijum'a skripts beidzas ar 1
*
*	Revision 1.12  2000/09/21 15:50:26  karlis
*	Precizeejums pieprasiijuma K500 sakaraa.
*
*	Revision 1.11  2000/09/21 15:35:17  karlis
*	Atbilde uz MKS pieprasiijumu K500. Pielikta paarbaude vai reversaalis jau nav
*	atblokkeets briidi, kad atblokkee autorizaacijai piesaistiito rakstu.
*
*	Revision 1.10  2000/09/08 08:38:53  karlis
*	Pielikta DMS parskaitijumu apstrade.
*
*	Revision 1.9  2000/09/01 11:11:29  karlis
*	Atpakall nevrapotaa versija
*
*	Revision 1.7  2000/07/04 13:43:31  karlis
*	Pievienota instalaacijas iespeeja Makefile.
\******************************************************************************/
end;
/

