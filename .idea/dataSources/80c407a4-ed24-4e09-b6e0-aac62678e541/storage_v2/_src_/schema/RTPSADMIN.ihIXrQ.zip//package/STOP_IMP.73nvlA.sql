create Package
/* $HeadURL$ $Id$ */
STOP_IMP IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	hist_numb	integer;
	centre_id	varchar2(11);
	effective_date	date;
/*	purge_date	date;
	action_code char(3);
	reason varchar2(255);*/
	function prepare_batch_storage return char;
	function normalize_KCS_data return char;
	function update_cards_ranges return char;
	procedure MSG(error_num integer,msg varchar2);
END;
/*= History =============================================================
 * $Log: stop_imp-package.sql,v $
 * Revision 1.9  2002/10/31 15:24:13  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.8  2000/10/02 08:38:10  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.7  1999/07/15 20:50:36  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.6  1999/04/12 11:05:06  uldis
 * Izveidots atskaited 'gener'ators
 *
 * Revision 1.2  1999/01/22 17:40:16  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:10  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

