create view RA_ACQ_RECONCILATIONS as
SELECT batch_owner,
    reconcile_date,
    reconcile_cntr,
    exported_flag,
    row_numb,
    request_date,
    msg_type_in,
    fld_011,
    fld_012,
    fld_024,
    fld_031,
    fld_032,
    fld_033,
    fld_037,
    fld_038,
    fld_039,
    fld_041,
    fld_042,
    fld_050,
    fld_074,
    fld_075,
    fld_076,
    fld_077,
    fld_078,
    fld_079,
    fld_080,
    fld_081,
    fld_082,
    fld_083,
    fld_084,
    fld_086,
    fld_087,
    fld_088,
    fld_089,
    fld_090,
    fld_093,
    fld_094,
    fld_097,
    fld_100,
    fld_101,
    fld_105,
    fld_106,
    fld_107,
    fld_108,
    fld_109,
    fld_110
FROM ACQ_reconcilation_LOG
order by request_date desc
/

comment on column RA_ACQ_RECONCILATIONS.BATCH_OWNER is 'Batch owner entity (centre, merchant or terminal) identifier'
/

comment on column RA_ACQ_RECONCILATIONS.RECONCILE_DATE is 'Reconciliation date'
/

comment on column RA_ACQ_RECONCILATIONS.RECONCILE_CNTR is 'Reconciliation indicator'
/

comment on column RA_ACQ_RECONCILATIONS.EXPORTED_FLAG is 'Exported to file flag'
/

comment on column RA_ACQ_RECONCILATIONS.ROW_NUMB is 'Oracle uniq ROW NUMB'
/

comment on column RA_ACQ_RECONCILATIONS.REQUEST_DATE is 'Authorisations request date'
/

comment on column RA_ACQ_RECONCILATIONS.MSG_TYPE_IN is 'Request message type'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_011 is 'Systems trace audit number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_012 is 'Transaction date and time'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_024 is 'Message function code'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_031 is 'Acquirer reference data'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_032 is 'Acquirer institution identifier'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_033 is 'Forwarding institution identifier'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_037 is 'Retrieval reference number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_038 is 'Approval Code'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_039 is 'Response action code'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_041 is 'Card acceptor terminal identification'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_042 is 'Card acceptor identification code'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_050 is 'Reconciliation currency'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_074 is 'Credits, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_075 is 'Credits, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_076 is 'Debits, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_077 is 'Debits, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_078 is 'Transfer, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_079 is 'Transfer, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_080 is 'Inquiries, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_081 is 'Authorizations, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_082 is 'Inquiries, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_083 is 'Payments, Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_084 is 'Payments, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_086 is 'Credits, Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_087 is 'Credits, Reversal Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_088 is 'Debits, Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_089 is 'Debits, Reversal Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_090 is 'Authorisations, Reversal Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_093 is 'Destination institution identifier'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_094 is 'Originator institution identifier'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_097 is 'Amount, Net Reconciliation'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_100 is 'Receiving institution identifier'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_101 is 'File Name'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_105 is 'Credits, Chargeback Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_106 is 'Debits, Chargeback Amount'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_107 is 'Credits, Chargeback Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_108 is 'Debits, Chargeback Number'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_109 is 'Credits, Fee Amounts'
/

comment on column RA_ACQ_RECONCILATIONS.FLD_110 is 'Debits, Fee Amounts'
/

