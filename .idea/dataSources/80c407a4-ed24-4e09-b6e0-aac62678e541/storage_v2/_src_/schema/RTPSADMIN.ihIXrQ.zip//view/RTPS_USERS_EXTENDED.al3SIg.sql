create view RTPS_USERS_EXTENDED as
select
      t1.username,
      t1.full_name,
      t2.profile
from
      rtps_users t1,
      dba_users t2
where
      t2.username = UPPER(t1.username)
/

