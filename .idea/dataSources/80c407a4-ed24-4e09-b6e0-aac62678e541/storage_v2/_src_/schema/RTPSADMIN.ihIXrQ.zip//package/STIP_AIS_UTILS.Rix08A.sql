create PACKAGE
/*$HeadURL$ $Id$*/
STIP_AIS_UTILS IS
/******************************************************************************\
  RTPS.IIA.AIS
  -------------
  $HeadURL$ $Id$
  -----------------------------------------------------------------------------
  Package radiits speciaali f-jai GetRtpsSysTime kura tiek izsaukta no CMS
  -----------------------------------------------------------------------------
  Copyright (C) 2003 TietoEnator Financial Solutions
\******************************************************************************/

--------------------------------------------------------------------------------
-- Atgriezh RTPS sisteemas laiku
--------------------------------------------------------------------------------
FUNCTION getrtpssystime RETURN DATE;

function GetRtpsTimestampWithTimezone return timestamp with time zone;

function GetRtpsTSWithLocalTimezone return timestamp with local time zone;

function GetRtpsTimestampAtUTC return timestamp with time zone;

procedure loadCentreInfo;
function  getCentreInfo(
				p_bank_c in varchar2,
				p_groupc in varchar2,
				p_centre_id out varchar2
			) return boolean;
function  getCentreInfosql(
				p_bank_c in varchar2,
				p_groupc in varchar2
			) return varchar2;
function  GetAccountIdForCardExpCcy(
				p_centre_id in varchar2,
				p_card_num in varchar2,
				p_expiry in varchar2,
				p_ccy in varchar2,
				p_account_id out varchar2
			) return boolean;

function getTransactionSign(p_fld_003 in varchar2, p_msgtype in varchar2) return number;

END;
/******************************************************************************\
 * $Log: stip_ais_utils-package.sql,v $
 * Revision 1.8  2005/03/29 13:33:07  karlisl
 * merged in full_table_download functionality
 *
 * Revision 1.7.4.1  2005/03/29 10:27:22  karlisl
 * getcentreinfosql function added
 *
 * Revision 1.7  2004/06/10 12:56:16  kovacs
 * - Kartes rakstiem pielikta offline limita ielasiishana
 * - Chip komandaam pielikta add_info lauka nolasiishana
 *
 * Revision 1.6  2003/12/17 15:40:10  kovacs
 * - Pielikts ka client rakstiem importee arii parent centra identifikatoru
 *
 * Revision 1.5  2003/02/06 14:02:11  vilis
 * Dont call MoveTransactions for centres with unlock_type = 1
 *
 * Revision 1.4  2003/01/29 15:22:51  kovacs
 * Atgriezts chip komandu klasifikators no 4.02 versijas, bet paarveidots taa ka tam ir tikai informatiiva noziime
 *
 * Revision 1.2  2003/01/23 11:26:06  vilis
 * Forgotten package end
 *
 * Revision 1.1  2003/01/23 11:19:04  vilis
 * New package stip_ais_utils with only one function GetRtpsSysTime
 * specially for use from CMS
 *
\******************************************************************************/
/

