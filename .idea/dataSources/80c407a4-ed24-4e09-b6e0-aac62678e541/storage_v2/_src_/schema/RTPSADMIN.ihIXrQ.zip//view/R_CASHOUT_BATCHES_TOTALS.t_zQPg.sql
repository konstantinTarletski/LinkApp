create view R_CASHOUT_BATCHES_TOTALS as
SELECT a.terminal_group_id AS term_group,
       a.terminal_id AS term_id,
       (SELECT c.param_value FROM atm_parameters c WHERE c.terminal_id = a.terminal_id AND c.param_name='TERMINAL_CITY') AS term_city,
       (SELECT c.param_value FROM atm_parameters c WHERE c.terminal_id = a.terminal_id AND c.param_name='TERMINAL_STREET') AS term_str,
       d.curr_alpha AS curr_alpha,
       d.curr_exp_dot AS curr_exp,
       b.device_audit AS device_audit,
       sum(CASE WHEN b.is_reversal = '0' THEN b.trn_amt ELSE - b.trn_amt END) AS batch_total
    FROM atm_terminal_group_members a,
         r_batch_totals b,
         ccy_codes d
    WHERE a.terminal_id = b.terminal_id
          AND d.curr_alpha = b.trn_ccy
    GROUP BY
       a.terminal_group_id,
       a.terminal_id,
       d.curr_alpha,
       d.curr_exp_dot,
       b.device_audit
    ORDER BY
       a.terminal_group_id,
       a.terminal_id,
       d.curr_alpha,
       b.device_audit
/

