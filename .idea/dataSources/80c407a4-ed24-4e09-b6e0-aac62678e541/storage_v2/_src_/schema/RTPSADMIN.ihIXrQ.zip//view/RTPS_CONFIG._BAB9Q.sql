create view RTPS_CONFIG as
(select substr(reg_name,1,16),substr(reg_value,1,128)
from regdir
start with reg_name='RTPS_CONFIG' and reg_parent_id is null
connect by reg_parent_id=prior reg_id
)
/

