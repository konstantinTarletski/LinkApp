create view R_RETAINED_CARDS
            (DEVICE_NAME, DEVICE_ID, DEVICE_AUDIT, EVENT_ID, EVENT_TIME, EVENT_TYPE, EVENT_TYPE_NAME, PAN, REASON,
             REFERENCE, ROW_NUMB, EVENT_PARAMS)
as
SELECT
    b.device_name,
    a.device_id,
    a.device_audit,
    a.event_id,
    a.event_time,
    a.event_type,
    c.event_type_name,
    extract_param_val(a.event_params, 'pan'),
    extract_param_val(a.event_params, 'reason'),
    extract_param_val(a.event_params, 'reference'),
    extract_param_val(a.event_params, 'row_numb'),
    a.event_params
FROM
    atm_events a,
    atm_devices b,
    atm_event_types c
WHERE
    a.event_type=c.event_type_id
    AND a.device_id=b.device_id
    AND c.event_type_group=3
/

