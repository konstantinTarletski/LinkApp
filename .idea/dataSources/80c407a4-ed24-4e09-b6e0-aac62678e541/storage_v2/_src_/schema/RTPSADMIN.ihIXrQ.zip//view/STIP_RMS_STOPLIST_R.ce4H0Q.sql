create view STIP_RMS_STOPLIST_R as
select
		x.centre_id,
		x.card_number,
		x.priority,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.action_code,
		x.rule_expr,
		x.description,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_RMS_STOPLIST x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

