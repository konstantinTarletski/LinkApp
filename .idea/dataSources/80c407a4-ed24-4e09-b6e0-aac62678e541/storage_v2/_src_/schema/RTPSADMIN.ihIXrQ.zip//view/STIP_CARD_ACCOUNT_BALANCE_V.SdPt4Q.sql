create view STIP_CARD_ACCOUNT_BALANCE_V as
select
			ac.account_ccy,
			( nvl(ac.initial_amount, 0) ) as initial_amount,
			( nvl(ac.bonus_amount, 0) ) as bonus_amount,
			( nvl(ac.lock_amount_cms, 0) ) as lock_amount_cms, -- lockedAmount
			( nvl(ac.offline_locked,  0) ) as offline_locked,
			( nvl(ac.offline_cleared, 0) ) as offline_cleared,
			( nvl(ac.credit_limit, 0) ) as credit_limit,
			ca.bonus_expired,
			ca.credit_limit_expired,
			( nvl(ac.lock_amount_cms_ofl, 0) ) as lock_amount_cms_ofl,
			ca.stip_locks,
			ca.creditlimit_locks,
			ca.bonus_locks,
			ac.account_type,
			ca.centre_id,
			ca.card_number,
			ca.crd_holdr_id,
			ca.ccomm_grp as crd_comm_grp,
			ca.acomm_grp as acc_comm_grp
		from
			stip_accounts_pri_v ac,
			stip_card_accounts_v ca
		where
			ac.centre_id = ca.centre_id and
			ac.account_id = ca.account_id
/

