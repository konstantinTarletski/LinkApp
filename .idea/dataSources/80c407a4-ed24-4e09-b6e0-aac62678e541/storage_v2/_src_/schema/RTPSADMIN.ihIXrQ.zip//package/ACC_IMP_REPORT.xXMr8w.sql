create Package
/* $HeadURL$ $Id$ */
ACC_IMP_REPORT IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
procedure report_reader(aaa in varchar2);
procedure txt_report;
END;
/*= History =============================================================
 * $Log: acc_imp_report-package.sql,v $
 * Revision 1.5  2002/10/31 15:25:02  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.4  2000/10/10 06:36:14  uldis
 * Pievienots Header,REVISION un Log
 *
 ========================================================================*/
/

