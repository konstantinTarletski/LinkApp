create view CCY_CODES as
SELECT ccy_num, ccy_alpha, exp_dot, description
FROM RTPSADMIN.currency_codes
/

