create PACKAGE
/*
$HeadURL$
$Id$
*/
ISSWP_REPORTS IS

   PROCEDURE auth_hist (PrintStatistic NUMBER DEFAULT 1, PrintData NUMBER DEFAULT 1,
      DateF DATE DEFAULT SYSDATE-1, DateT DATE DEFAULT SYSDATE,
      dev_typeA NUMBER DEFAULT 1, dev_typeP NUMBER DEFAULT 1, dev_typeN NUMBER DEFAULT 1,
      dev_typeNULL NUMBER DEFAULT 1,
      RespAppr NUMBER DEFAULT 1, RespDecl NUMBER DEFAULT 1,
      RespPUp NUMBER DEFAULT 1, RespOth NUMBER DEFAULT 1, RespCode VARCHAR2 DEFAULT '%',
      TransType VARCHAR2 DEFAULT '%',
      IssuerCentre_ID VARCHAR2 DEFAULT '%',
      Prefix NUMBER DEFAULT -1,
      CardType VARCHAR2 DEFAULT '%', Card# VARCHAR2 DEFAULT '%',
      acquirer VARCHAR2 DEFAULT '%', forwarder VARCHAR2 DEFAULT '%', MCC CHAR DEFAULT '%',
      Merchant_ID CHAR DEFAULT '%', Terminal_ID CHAR DEFAULT '%',
      TransCurrency CHAR DEFAULT '%', GroupBy NUMBER DEFAULT 1,
      GroupByTimeInterval_minutes NUMBER DEFAULT 60,/*10 or 30 or 60 or 360 or 1440*/
      OnlyUndelivered NUMBER DEFAULT 0,
      ResponseCodeWithDescr NUMBER DEFAULT 0,
      RowNumb_1 NUMBER DEFAULT 0,
      RowNumb_N NUMBER DEFAULT 0);

   PROCEDURE auth_hist_txt;

   TYPE ascii_files_pk IS RECORD (Hist_numb stip_filehist.hist_numb%type
      ,IssuerCentre_ID stip_filehist.centre_id%type
      ,Effective_date stip_filehist.effective_date%type);
   TYPE ascii_files_tab_type IS TABLE OF ascii_files_pk INDEX BY BINARY_INTEGER;
      ascii_files_tab ascii_files_tab_type;

   PROCEDURE ascii_files_hist (ReportType NUMBER DEFAULT 3,
      DateF DATE DEFAULT NULL, DateT DATE DEFAULT NULL,
      Last_files NUMBER DEFAULT NULL,
      IssuerCentre_ID VARCHAR2 DEFAULT NULL,
      Select_Without_Filters NUMBER DEFAULT 1);

   PROCEDURE ascii_files_hist_txt;

   PROCEDURE ASCIIFilesHistItemInsert (order_numb IN NUMBER, h_numb IN VARCHAR2,
      centre_id IN VARCHAR2, eff_date IN VARCHAR2);

END;
/

