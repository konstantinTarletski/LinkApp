create view R_RETAINED_CARDS_GROUPS
            (TERMINAL_GROUP_ID, DEVICE_NAME, DEVICE_ID, DEVICE_AUDIT, EVENT_ID, EVENT_TIME, EVENT_TIME2, EVENT_TYPE,
             EVENT_TYPE_NAME, PAN, REASON, REFERENCE, ROW_NUMB, EVENT_PARAMS)
as
SELECT
    b.terminal_group_id,
    a.device_name,
    a.device_id,
    a.device_audit,
    a.event_id,
    a.event_time,
    a.event_time,
    a.event_type,
    a.event_type_name,
    extract_param_val(a.event_params, 'pan'),
    extract_param_val(a.event_params, 'reason'),
    extract_param_val(a.event_params, 'reference'),
    extract_param_val(a.event_params, 'row_numb'),
    a.event_params
FROM
    r_retained_cards a,
    atm_terminal_group_members b
WHERE a.device_name=b.terminal_id
/

