create view RTPS_PROFILES as
select distinct profile from DBA_PROFILES
/

