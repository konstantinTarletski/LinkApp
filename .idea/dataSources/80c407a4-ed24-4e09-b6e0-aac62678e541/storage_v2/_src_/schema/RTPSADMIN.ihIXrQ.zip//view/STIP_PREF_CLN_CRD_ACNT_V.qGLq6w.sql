create view STIP_PREF_CLN_CRD_ACNT_V as
SELECT
		p.centre_id AS p_centre_id,
		p.pref_rec_num AS p_pref_rec_num,
		p.pref_min AS p_pref_min,
		p.pref_max AS p_pref_max,
		p.pref_delta AS p_pref_delta,
		p.abbreviature AS p_abbreviature,
		p.card_family AS p_card_family,
		v."H_CENTRE_ID",v."H_EFFECTIVE_DATE",v."H_UPDATE_DATE",v."H_PURGE_DATE",v."H_CRD_HOLDR_ID",v."H_PARENT_CENTRE_ID",v."H_PARENT_CRD_HOLDR_ID",v."H_CRD_HOLDR_PWD",v."H_CRD_HOLDR_MSG",v."H_PARAM_GRP_1",v."H_PARAM_GRP_2",v."H_ACNT_CHANGE",v."H_CRD_HOLDR_NAME",v."H_COMM_GRP",v."H_ADD_INFO",v."H_PERSON_CODE",v."A_CENTRE_ID",v."A_EFFECTIVE_DATE",v."A_UPDATE_DATE",v."A_CRD_HOLDR_ID",v."A_ACCOUNT_TYPE",v."A_ACCOUNT_ID",v."A_ACCOUNT_CCY",v."A_INITIAL_AMOUNT",v."A_BONUS_AMOUNT",v."A_ACCOUNT_ID_BANK",v."A_ADD_INFO",v."A_CREDIT_LIMIT",v."A_LOCK_TIME",v."A_LOCK_AMOUNT_CMS",v."A_AMOUNT_SET_TIME",v."A_COMM_GRP",v."A_SHADOW_AMOUNT",v."A_TIME_STAMP",v."A_PRIORITY",v."A_STATUS",v."A_CREDIT_LIMIT_EXPIRY",v."A_BONUS_AMOUNT_EXPIRY",v."A_LOCK_AMOUNT_CMS_OFL",v."A_OFFLINE_LOCKED",v."A_OFFLINE_CLEARED",v."C_CENTRE_ID",v."C_EFFECTIVE_DATE",v."C_UPDATE_DATE",v."C_PREF_REC_NUM",v."C_CARD_NUMBER",v."C_CRD_HOLDR_ID",v."C_CRD_HOLDR_NAME",v."C_CRD_HOLDR_PWD",v."C_CRD_HOLDR_MSG",v."C_PARAM_GRP_1",v."C_PARAM_GRP_2",v."C_ACNT_RESTR",v."C_AVLAMNT_FLAG",v."C_STAT_CODE_1",v."C_STAT_CODE_2",v."C_EXPIRY_DATE_1",v."C_EXPIRY_DATE_2",v."C_CVC_STRIPE_1",v."C_CVC_STRIPE_2",v."C_CVC_PRINT_1",v."C_CVC_PRINT_2",v."C_PVV_CODE_1",v."C_PVV_CODE_2",v."C_PVV_COUNT_1",v."C_PVV_COUNT_2",v."C_TRACK_1_1",v."C_TRACK_1_2",v."C_TRACK_2_1",v."C_TRACK_2_2",v."C_COMM_GRP",v."C_PVV_CODE_1_CHG",v."C_PVV_CODE_2_CHG",v."C_PVV_CODE_1_DATE",v."C_PVV_CODE_2_DATE",v."C_PVV_CODE_1_PRV",v."C_PVV_CODE_2_PRV",v."C_ADD_INFO",v."C_CARD_SEQ_1",v."C_CARD_SEQ_2",v."C_PKI_1",v."C_PKI_2",v."C_DKI_1",v."C_DKI_2",v."C_APP_ID",v."C_OFFL_LIMIT_1",v."C_OFFL_LIMIT_2",v."C_OFFL_LIMIT_CTRL",v."C_CLIENT_ID",v."C_PVV_COUNT_1_CHG",v."C_PVV_COUNT_2_CHG",v."C_PVV_CODE_1_ALG",v."C_PVV_CODE_2_ALG"
	FROM
		stip_prefixes p INNER JOIN stip_clnt_crd_acnt_v v
		ON p.centre_id = v.c_centre_id AND p.pref_rec_num = v.c_pref_rec_num
	with check option
/

