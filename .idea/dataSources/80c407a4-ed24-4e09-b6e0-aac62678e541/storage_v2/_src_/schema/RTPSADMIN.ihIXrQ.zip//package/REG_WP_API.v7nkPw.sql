create package
/* $HeadURL$ $Id$ */
reg_wp_api is
/*#=================================================================================================================
--#	$HeadURL$ $Id$
--#	(C) Tieto Konts Financial Systems Ltd. 1998,1999
--#=================================================================================================================*/
/*================================================================================================*\
Interfeisu konfiguraacijas tabulas(REGDIR) API (wrapper around REG package)
Kodeja: Vilis Sviklis
\*================================================================================================*/
function open(name in varchar2,key_out in out number) return char;
function openk(key_in in number,sub_name varchar2,key_out in out number) return char;
function create_key(name in varchar2,key_out in out number) return char;
function create_keyk(key_in in number,sub_name varchar2,key_out in out number) return char;
function getc(name in varchar2,key_value in out varchar2) return char;
function getck(key_in in number,sub_name in varchar2,key_value in out varchar2) return char;
function getn(name in varchar2,key_value in out number) return char;
function getnk(key_in in number,sub_name in varchar2,key_value in out number) return char;
function setn(name in varchar2,key_value in number) return char;
function setnk(key_in in number,sub_name in varchar2,key_value in number) return char;
function setc(name in varchar2,key_value in varchar2) return char;
function setck(key_in in number,sub_name in varchar2,key_value in varchar2) return char;
function enum(name in varchar2,types in char,sub_name in out varchar2,prev_key in out number) return char;
function enumk(key_in in number,types in char,sub_name in out varchar2,prev_key in out number) return char;
function delkey(name in varchar2) return char;
function create_symlink(name in varchar2,link_path in varchar2) return char;
/*#=== History ================================================================
--#	$Log: reg_wp_api-package.sql,v $
--#	Revision 1.2  2002/10/31 15:25:55  uldis
--#	Netiek lietots REVISIO N buferis
--#
--#	Revision 1.1  2002/05/02 10:21:14  uldis
--#	Pielikta pakotne reg_wp_api
--#
--#============================================================================*/
end;
/

