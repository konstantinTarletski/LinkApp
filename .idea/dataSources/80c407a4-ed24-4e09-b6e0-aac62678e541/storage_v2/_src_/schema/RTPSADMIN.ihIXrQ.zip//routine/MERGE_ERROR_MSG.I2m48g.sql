create Function /* $HeadURL$ $Id$ */
MERGE_ERROR_MSG
    (
        template         IN   varchar2,
        arguments        IN   varchar2,
        arg_map             varchar2    default null,
        msg_template        varchar2    default null,
        msg_arguments       varchar2    default null,
        error_arguments     varchar2    default null,
        err_rec_num         number      default null,
        error_date          date        default null,
        error_code          number      default null,
        program_code        number      default null,
        program_name        varchar2    default null,
        error_source        varchar2    default null,
        program_type        number      default null,
        program_name_abbr   varchar2    default null,
        program_type_abbr   varchar2    default null,
        action_code         char        default null,
        error_class         number      default null,
        error_class_abbr    varchar2    default null,
        error_severity      number      default null,
        error_severity_abbr varchar2    default null,
        msg_full            varchar2    default null
    )   RETURN varchar IS
    message  varchar2(1024);
    the_arguments   varchar2(256):=null;
    the_arg_map  varchar2(256):=null;
BEGIN
    if arg_map is null then
        declare
            i              number;
            j              number;
        begin
            i:=instr(template,'<<');
            j:=instr(template,'>>',i+2);
            while j>0 and i>0 loop
                if substr(template,i+2,1)<>'%' then
                    if the_arg_map is not null then the_arg_map:=the_arg_map||'|'; end if;
                    the_arg_map:=the_arg_map||substr(template,i+2,j-i-2);
                end if;
                i:=instr(template,'<<',j+2);
                j:=instr(template,'>>',i+2);
            end loop;
        end;
    else
        the_arg_map:=arg_map;
    end if;
    message:=template;
    the_arguments:=arguments;
    if /*the_arguments is not null and */the_arg_map is not null then
        declare
            arg_i              number;
            map_i              number;
        begin
            loop
                if nvl(length(the_arg_map),0)=0 then
                    exit;
                end if;
                arg_i:=instr(the_arguments,'|');
                if arg_i=0 then
                    arg_i:=nvl(length(the_arguments),0)+1;
                end if;
                map_i:=instr(the_arg_map,'|');
                if map_i=0 then
                    map_i:=nvl(length(the_arg_map),0)+1;
                end if;
                message:=replace(message,'<<'||substr(the_arg_map,1,map_i-1)||'>>',substr(the_arguments,1,arg_i-1));
                the_arguments:=substr(the_arguments,arg_i+1);
                the_arg_map:=substr(the_arg_map,map_i+1);
            end loop;
        end;
    end if;
    if  err_rec_num         is not null then message:=replace(message,'<<%err_rec_num>>',to_char(err_rec_num)); end if;
    if  error_date          is not null then message:=replace(message,'<<%error_date>>',to_char(error_date,'YYYY/MM/DD HH24:MI:SS')); end if;
    if  error_code          is not null then message:=replace(message,'<<%error_code>>',to_char(error_code)); end if;
    if  program_code        is not null then message:=replace(message,'<<%program_code>>',to_char(program_code)); end if;
    if  program_name        is not null then message:=replace(message,'<<%program_name>>',program_name); end if;
    if  error_source        is not null then message:=replace(message,'<<%error_source>>',error_source); end if;
    if  program_type        is not null then message:=replace(message,'<<%program_type>>',to_char(program_type)); end if;
    if  program_name_abbr   is not null then message:=replace(message,'<<%program_name_abbr>>',program_name_abbr); end if;
    if  program_type_abbr   is not null then message:=replace(message,'<<%program_type_abbr>>',program_type_abbr); end if;
    if  action_code         is not null then message:=replace(message,'<<%action_code>>',action_code); end if;
    if  error_class         is not null then message:=replace(message,'<<%error_class>>',to_char(error_class)); end if;
    if  error_class_abbr    is not null then message:=replace(message,'<<%error_class_abbr>>',error_class_abbr); end if;
    if  error_severity      is not null then message:=replace(message,'<<%error_severity>>',to_char(error_severity)); end if;
    if  error_severity_abbr is not null then message:=replace(message,'<<%error_severity_abbr>>',error_severity_abbr); end if;
    if  msg_full            is not null then message:=replace(message,'<<%msg_full>>',msg_full); end if;
    if  msg_template        is not null and instr(message,'<<%message>>')>0 then
        message:=replace(message,'<<%message>>',
            MERGE_ERROR_MSG
                (
                    msg_template        ,
                    msg_arguments       ,
                    error_arguments     ,
                    null,
                    null,
                    null,
                    err_rec_num         ,
                    error_date          ,
                    error_code          ,
                    program_code        ,
                    program_name        ,
                    error_source        ,
                    program_type        ,
                    program_name_abbr   ,
                    program_type_abbr   ,
                    action_code         ,
                    error_class         ,
                    error_class_abbr    ,
                    error_severity      ,
                    error_severity_abbr ,
                    msg_full            ));
    end if;
    return message;
END;
/

