create FUNCTION check_to_date(string_in IN VARCHAR2, format_in IN VARCHAR2) RETURN VARCHAR2 IS
    date_test DATE;
BEGIN
    BEGIN
        date_test := TO_DATE(string_in, format_in);
    EXCEPTION WHEN OTHERS THEN
        RETURN NULL;
    END;
    RETURN string_in;
END check_to_date;
/

