create view RTPS_CCY_RATES_R as
select
	    pay_ccy,
	    ccy_num,
	    bank,
	    ccy_rate_buy,
	    ccy_rate_buy_min,
    	ccy_rate_sell,
	    ccy_rate_sell_min,
	    ccy_rate_mid,
	    ccy_rate_mid_min
	from
		rtps_ccy_rates
	where
		exists
			(select null
				from
					centre_users cu,
					processing_entities pe
				where
					pe.iss_bank=bank and
					cu.centre_id = pe.centre_id and
					cu.username = user)
		with check option
/

