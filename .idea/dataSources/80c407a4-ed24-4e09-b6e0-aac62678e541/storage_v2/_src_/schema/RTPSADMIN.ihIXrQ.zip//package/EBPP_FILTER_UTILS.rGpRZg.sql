create PACKAGE ebpp_filter_utils AS
  TYPE filter_detail_list IS TABLE OF ebpp_filters_details.detail_name_regexp%TYPE;

  FUNCTION replace_filter_id_in_services(services IN varchar2, old_filter_id IN varchar2, new_filter_id IN varchar2) RETURN varchar2;

  PROCEDURE create_filter(c_name IN ebpp_filters.filter_name%TYPE, c_type IN ebpp_filters.filter_type%TYPE, c_allowed IN ebpp_filters.filter_allowed%TYPE);

  PROCEDURE merge_duplicate_filters(c_filter_name IN ebpp_filters.filter_name%TYPE);

  PROCEDURE add_details_to_filter(c_filter_name IN ebpp_filters.filter_name%TYPE, details IN filter_detail_list);
END;
/

