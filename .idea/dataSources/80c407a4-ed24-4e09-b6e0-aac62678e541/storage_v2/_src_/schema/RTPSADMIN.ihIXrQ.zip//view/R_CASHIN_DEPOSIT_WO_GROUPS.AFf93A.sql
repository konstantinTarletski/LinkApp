create view R_CASHIN_DEPOSIT_WO_GROUPS as
(SELECT
    d.terminal_device_id,
    d.terminal_device_name,
    a.deposit_bin,
    b.device_name,
    a.payment_id,
    a.ref_num,
    a.card_number,
    a.account_id,
    a.tran_date as TRAN_DATE,
    a.tran_date as TRAN_DATE2,
    to_char(a.audit_date,'YYYYMMDDHH24MISS') as audit_date,
    a.amount,
    c.curr_alpha,
    a.reason,
    c.curr_exp_dot
FROM
    atm_deposits a,
    atm_devices b,
    ccy_codes c,
    r_terminal_devices d
WHERE
    d.terminal_device_id = a.device_id
    AND a.deposit_bin=b.device_id
    AND a.device_id=d.device_id
    AND a.ccy_code=c.curr_num
)
UNION
--select audits WO transactions, for NIGHT_SAFE commonly
(
SELECT DISTINCT
    d.terminal_device_id,
    d.terminal_device_name,
    b.device_id,
    b.device_name,
    NULL,
    to_char(NULL),
    to_char(NULL),
    to_char(NULL),
    to_date(e.device_audit,'YYYYMMDDHH24MISS') as TRAN_DATE,
    to_date(e.device_audit,'YYYYMMDDHH24MISS') as TRAN_DATE2,
    e.device_audit as audit_date,
    to_number(NULL),
    to_char(NULL),
    to_char(NULL),
    to_number(NULL)
FROM
    atm_devices b,
    r_terminal_devices d,
    atm_events e
WHERE
    b.device_parent>0
    AND d.terminal_device_id = b.device_parent
    AND d.device_id = b.device_id
    AND e.device_id = b.device_id
    AND to_date(e.device_audit,'YYYYMMDDHH24MISS') not in (select distinct audit_date from atm_deposits)
    AND e.event_type='1'
)
order by terminal_device_id, reason, curr_alpha, audit_date, tran_date
/

