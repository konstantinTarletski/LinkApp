create view STIP_ACCOUNTS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.crd_holdr_id,
		x.account_type,
		x.account_id,
		x.account_ccy,
		x.initial_amount,
		x.bonus_amount,
		x.locked_amount,
		x.account_id_bank,
		x.add_info,
		x.credit_limit,
		x.lock_time,
		x.lock_amount_cms,
		x.lock_amount_cms_ofl,
		x.amount_set_time,
		x.comm_grp,
		x.shadow_amount,
		x.time_stamp,
		x.priority,
		x.status,
		x.credit_limit_expiry,
		x.bonus_amount_expiry,
		x.offline_locked,
		x.offline_cleared,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_ACCOUNTS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

