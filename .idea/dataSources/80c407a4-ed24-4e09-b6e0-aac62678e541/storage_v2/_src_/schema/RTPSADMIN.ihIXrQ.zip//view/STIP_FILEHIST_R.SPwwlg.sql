create view STIP_FILEHIST_R as
SELECT
     STIP_FIHI.HIST_NUMB
    ,STIP_FIHI.CENTRE_ID
    ,STIP_FIHI.EFFECTIVE_DATE
	,STIP_FIHI.START_DATE
	,STIP_FIHI.END_DATE
    ,STIP_FIHI.FILE_NAME
    ,AUTO_LOG.ORACLE_USER
    ,AUTO_LOG.MANUAL_START
    ,AUTO_LOG.START_DATE
    ,AUTO_LOG.END_DATE
	,STIP_FIHI.EXTRACT_FLAG
    ,STIP_FIHI.IMPORT_FLAG
    ,STIP_FIHI.UNLOCK_FLAG
	,decode(proc_ent.authdat_alg_nr,
			2,EXPORT_FLAG,
			5,EXPORT_FLAG,
			6,EXPORT_FLAG,
			8,EXPORT_FLAG,
			9,EXPORT_FLAG,
			10,EXPORT_FLAG,
			least(extract_flag,import_flag,unlock_flag)) EXPORT_FLAG
	,decode(proc_ent.authdat_alg_nr,
			2,PACK_FLAG,
			5,PACK_FLAG,
			6,PACK_FLAG,
			8,PACK_FLAG,
			9,PACK_FLAG,
			10,PACK_FLAG,
			least(extract_flag,import_flag,unlock_flag)) PACK_FLAG
    ,least(extract_flag,import_flag,unlock_flag,
		decode(proc_ent.authdat_alg_nr,1,'T',3,'T',4,'T',7,'T',least(export_flag,pack_flag))) report_flag
from
    stip_filehist  stip_fihi,
    autotasks_log  auto_log,
	processing_entities proc_ent
 where auto_log.hist_numb = stip_fihi.hist_numb and
 exists (select null from centre_users where
 centre_id = stip_fihi.centre_id and username = user) and
 proc_ent.centre_id=stip_fihi.centre_id
 with check option
/

comment on column STIP_FILEHIST_R.HIST_NUMB is 'Automated task history row number'
/

comment on column STIP_FILEHIST_R.CENTRE_ID is 'Data owner processing entity identifier'
/

comment on column STIP_FILEHIST_R.EFFECTIVE_DATE is 'File effective date and time'
/

comment on column STIP_FILEHIST_R.FILE_START_DATE is 'Start date and time of file processing'
/

comment on column STIP_FILEHIST_R.FILE_END_DATE is 'End date and time of file processing'
/

comment on column STIP_FILEHIST_R.FILE_NAME is 'File name, used in data import/export processing'
/

comment on column STIP_FILEHIST_R.USERNAME is 'Database user identifier, who is responsible for task start'
/

comment on column STIP_FILEHIST_R.MANUAL_START is 'Task start manual request flag'
/

comment on column STIP_FILEHIST_R.START_DATE is 'Task execution start date and time'
/

comment on column STIP_FILEHIST_R.END_DATE is 'Task execution end date and time'
/

comment on column STIP_FILEHIST_R.EXTRACT_FLAG is 'Data extracting successfull completion flag'
/

comment on column STIP_FILEHIST_R.IMPORT_FLAG is 'Extracted data import successfull completion flag'
/

comment on column STIP_FILEHIST_R.UNLOCK_FLAG is 'Transaction unlocking successfull completion flag'
/

comment on column STIP_FILEHIST_R.EXPORT_FLAG is 'Data export successfull completion flag'
/

comment on column STIP_FILEHIST_R.PACK_FLAG is 'Exported data packing successfull completion flag'
/

comment on column STIP_FILEHIST_R.REPORT_FLAG is 'Report generation successfull completion flag'
/

