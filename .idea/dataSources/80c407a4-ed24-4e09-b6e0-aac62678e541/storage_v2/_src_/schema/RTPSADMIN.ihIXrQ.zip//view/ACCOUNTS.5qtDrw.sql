create view ACCOUNTS as
select ac.centre_id,pe.abbreviature,ac.account_id,ac.account_ccy,ac.locked_amount from stip_accounts ac,processing_entities pe
where pe.centre_id=ac.centre_id
/

