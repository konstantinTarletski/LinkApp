create FUNCTION MSG_EXPIRY_CATEGORY( fld_024 varchar2,fld_025 varchar2)
RETURN number
DETERMINISTIC
IS
BEGIN
	if fld_024 = '101' and fld_025 = '1806' then
		return 2;
	end if;
	if fld_024 = '107' and fld_025 = '1777' then
		return 2;
	end if;
	return 1;
END;
/

