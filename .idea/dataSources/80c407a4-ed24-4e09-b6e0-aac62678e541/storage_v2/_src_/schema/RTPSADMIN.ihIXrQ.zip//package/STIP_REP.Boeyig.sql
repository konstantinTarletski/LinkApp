create PACKAGE
/*$HeadURL$ $Id$*/
STIP_REP IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
--------- Client Configuration REPORT ---------
FUNCTION TLV_GET_TAG( tlv IN VARCHAR2, tag IN VARCHAR2 ) RETURN VARCHAR2;
FUNCTION EXTRACT_OTB( l_additional_amounts IN VARCHAR2 ) RETURN VARCHAR2;

PROCEDURE ClientInfo(pvalue in varchar2, centre_id in varchar2 default null, switches in varchar2 default 'T|T|T', ptype in varchar2 default 'CARD');
PROCEDURE ClientInfoTxtReport;
/*
dfrom     - no kura laika drukat izmainju vesturi
dto       - lidz kuram laikam drukat izmainju vesturi
centre_id - izdeveja centra ID.
switches  - iesledz(T) / izsledz(F) kadu no reporta daljam:
              1 - Parametru grupu drukashana;
              2 - Prefiksu drukashana;
              3 - Akumulatoru drukashana;
            Atdliitaajs '|'.
            Pilna gadijuma bus 'T|T|T', var ari nedot neko, automatiski tiek saprasts, ka vajag visas daljas.
pvalue	- parametra vertiba
ptype	- parametra tips (CARD, ACCOUNT, CARDHOLDER)
*/

--------- Client Authorisation data change REPORT ---------
PROCEDURE AuthDataChangeHist(dfrom IN date,dto IN date, pvalue in varchar2, header_sw in varchar2, rep_type in varchar2 default 'P', centre_id in varchar2 default null, ptype in varchar2 default 'CARD');
PROCEDURE AuthDatChngTxtRep;

function MASKED_PAN(PAN IN VARCHAR2) return VARCHAR2;

END; -- Package spec
/*= History =============================================================
 * $Log: stip_rep-package.sql,v $
 * Revision 1.19  2008/02/07 14:15:37  liukiagn
 * RemoteEventsSend function moved to iia.services
 *
 * Revision 1.18  2007/12/03 08:24:54  liukiagn
 * changed RemoteEventsSend function to use rowid and row_numb parameters
 *
 * Revision 1.17  2007/11/26 15:58:21  liukiagn
 * added RemoteEventsSend function declaration (Jira task CIR 1000)
 *
 * Revision 1.16  2006/04/05 09:42:52  vladimirs
 * manual butification
 *
 * Revision 1.15  2005/06/20 14:34:00  vladimirs
 * Changes due to Bug 8670
 * Added EXTRACT_OTB to allow IssWP use it from graphical report
 *
 * Revision 1.14  2004/06/28 19:44:46  vilis
 * tlv_get_tag() added
 *
 * Revision 1.13  2003/02/06 15:41:51  vilis
 * Fake changes
 *
 * Revision 1.12  2003/02/06 15:37:21  vilis
 * added revisions
 *
 * Revision 1.11  2003/02/06 15:35:52  vilis
 * Added revisions
 *
 * Revision 1.10  2003/01/23 15:40:52  vilis
 * Authorization data change history for centres with new unlocking
 *
 * Revision 1.9  2002/11/19 13:59:31  vilis
 * param_grp related changes (char to varchar(5)) ...
 *
 * Revision 1.8  2002/10/31 15:26:10  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.7  2000/10/02 08:38:01  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.6  2000/08/22 18:33:07  isais
 * Uzkodeeta STIP_REP 'Autorisation data change history' atskaite.
 *
 * Revision 1.5  2000/06/06 09:53:41  grin
 * Iesaakts darbs pie auth_data_hist paarstraadaashanas peec specifikaacijas. Paartraukts deelj darbiem pie kriptoservera.
 *
 * Revision 1.4  2000/05/29 15:39:23  grin
 * Kosmeetiski labojumi Prefiksa tabulaa, kas atteelojas atskaitee.
 *
 * Revision 1.3  2000/05/16 14:41:38  grin
 * Dazhi komentaari un aareeji nejuutamas izmainjas ClientInfo proceduuras izsaukumaa.
 *
 * Revision 1.1  2000/01/10 11:13:55  uldis
 * Jauna kartes tur'et'aja autoriz'acijas datu atskaite.
 *
 ========================================================================*/
/

