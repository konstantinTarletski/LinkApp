create view RA_SCM_MESSAGES as
SELECT ROW_NUMB,
    VALIDITY_FLAG,
    LOCALITY_FLAG,
    REQUEST_DATE,
    RESPONSE_DATE,
    STAN_INTERNAL,
    CARD_TYPE,
    DEV_TYPE,
    BATCH_OWNER,
    MSG_TYPE_IN,
    MSG_TYPE_OUT,
    MSG_ORIG_IN,
    MSG_ORIG_OUT,
    FLD_002,
    FLD_003,
    FLD_004,
    FLD_005,
    FLD_006,
    FLD_007,
    FLD_008,
    FLD_009,
    FLD_010,
    FLD_011,
    FLD_012,
    FLD_013,
    FLD_014,
    FLD_015,
    FLD_016,
    FLD_017,
    FLD_018,
    FLD_019,
    FLD_020,
    FLD_021,
    FLD_022,
    FLD_023,
    FLD_024,
    FLD_025,
    FLD_026,
    FLD_027,
    FLD_028,
    FLD_029,
    FLD_030A,
    FLD_030B,
    FLD_031,
    FLD_032,
    FLD_033,
    FLD_034,
    FLD_035,
    FLD_036,
    FLD_037,
    FLD_038,
    FLD_039,
    FLD_040,
    FLD_041,
    FLD_042,
    FLD_043,
    FLD_044,
    FLD_045,
    FLD_046,
    FLD_048,
    FLD_049,
    FLD_050,
    FLD_051,
    FLD_054,
    FLD_055,
    FLD_056A,
    FLD_056B,
    FLD_056C,
    FLD_056D,
    FLD_057,
    FLD_058,
    FLD_059,
    FLD_060,
    FLD_066,
    FLD_067,
    FLD_068,
    FLD_069,
    FLD_070,
    FLD_071,
    FLD_072,
    FLD_073,
    FLD_074,
    FLD_075,
    FLD_076,
    FLD_077,
    FLD_078,
    FLD_079,
    FLD_080,
    FLD_081,
    FLD_082,
    FLD_083,
    FLD_084,
    FLD_085,
    FLD_086,
    FLD_087,
    FLD_088,
    FLD_089,
    FLD_090,
    FLD_091,
    FLD_092,
    FLD_093,
    FLD_094,
    FLD_095,
    FLD_097,
    FLD_098,
    FLD_099,
    FLD_100,
    FLD_101,
    FLD_102,
    FLD_103,
    FLD_104,
    FLD_105,
    FLD_106,
    FLD_107,
    FLD_108,
    FLD_109,
    FLD_110,
    FLD_122,
    FLD_123,
    FLD_124,
    ORIG_ROW_NUMB
FROM MESSAGES_LOG
/

comment on column RA_SCM_MESSAGES.ROW_NUMB is 'Oracle uniq ROW NUMB'
/

comment on column RA_SCM_MESSAGES.VALIDITY_FLAG is 'Validity flag'
/

comment on column RA_SCM_MESSAGES.LOCALITY_FLAG is 'Locality flag'
/

comment on column RA_SCM_MESSAGES.REQUEST_DATE is 'Authorisations request date'
/

comment on column RA_SCM_MESSAGES.RESPONSE_DATE is 'Authorisations response date'
/

comment on column RA_SCM_MESSAGES.STAN_INTERNAL is 'Uniq Internal STAN'
/

comment on column RA_SCM_MESSAGES.CARD_TYPE is 'Card type'
/

comment on column RA_SCM_MESSAGES.DEV_TYPE is 'Device type - Pos, ATM, Unknown'
/

comment on column RA_SCM_MESSAGES.BATCH_OWNER is 'Batch owner entity identifier'
/

comment on column RA_SCM_MESSAGES.MSG_TYPE_IN is 'Request message type'
/

comment on column RA_SCM_MESSAGES.MSG_TYPE_OUT is 'Response message type'
/

comment on column RA_SCM_MESSAGES.MSG_ORIG_IN is 'Original message Request message type'
/

comment on column RA_SCM_MESSAGES.MSG_ORIG_OUT is 'Original message Response message type'
/

comment on column RA_SCM_MESSAGES.FLD_002 is 'Primary account number'
/

comment on column RA_SCM_MESSAGES.FLD_003 is 'Transaction type'
/

comment on column RA_SCM_MESSAGES.FLD_004 is 'Transaction amount'
/

comment on column RA_SCM_MESSAGES.FLD_005 is 'Reconciliation amount'
/

comment on column RA_SCM_MESSAGES.FLD_006 is 'Cardholder billing amount'
/

comment on column RA_SCM_MESSAGES.FLD_007 is 'Transmission date and time'
/

comment on column RA_SCM_MESSAGES.FLD_008 is 'Amount, Cardholder Billing Fee '
/

comment on column RA_SCM_MESSAGES.FLD_009 is 'Reconciliation conversion rate'
/

comment on column RA_SCM_MESSAGES.FLD_010 is 'Billing conversion rate'
/

comment on column RA_SCM_MESSAGES.FLD_011 is 'Systems trace audit number'
/

comment on column RA_SCM_MESSAGES.FLD_012 is 'Transaction date and time'
/

comment on column RA_SCM_MESSAGES.FLD_013 is 'Card effective date'
/

comment on column RA_SCM_MESSAGES.FLD_014 is 'Card expiration date'
/

comment on column RA_SCM_MESSAGES.FLD_015 is 'Settlement date'
/

comment on column RA_SCM_MESSAGES.FLD_016 is 'Conversion date and time'
/

comment on column RA_SCM_MESSAGES.FLD_017 is 'Date, Capture'
/

comment on column RA_SCM_MESSAGES.FLD_018 is 'Merchant type'
/

comment on column RA_SCM_MESSAGES.FLD_019 is 'Acquiring institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_020 is 'PAN country code'
/

comment on column RA_SCM_MESSAGES.FLD_021 is 'Forwarding institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_022 is 'Point of service data code'
/

comment on column RA_SCM_MESSAGES.FLD_023 is 'Card sequence number'
/

comment on column RA_SCM_MESSAGES.FLD_024 is 'Message function code'
/

comment on column RA_SCM_MESSAGES.FLD_025 is 'Message reason code'
/

comment on column RA_SCM_MESSAGES.FLD_026 is 'Card acceptor business code'
/

comment on column RA_SCM_MESSAGES.FLD_027 is 'Acceptable approval code length'
/

comment on column RA_SCM_MESSAGES.FLD_028 is 'Reconciliation date'
/

comment on column RA_SCM_MESSAGES.FLD_029 is 'Reconciliation indicator'
/

comment on column RA_SCM_MESSAGES.FLD_030A is 'Original amount, transaction '
/

comment on column RA_SCM_MESSAGES.FLD_030B is 'Original amount, reconciliation'
/

comment on column RA_SCM_MESSAGES.FLD_031 is 'Acquirer reference data'
/

comment on column RA_SCM_MESSAGES.FLD_032 is 'Acquirer institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_033 is 'Forwarding institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_034 is 'Extended primary account number'
/

comment on column RA_SCM_MESSAGES.FLD_035 is 'Track 2 data'
/

comment on column RA_SCM_MESSAGES.FLD_036 is 'Track 3 data'
/

comment on column RA_SCM_MESSAGES.FLD_037 is 'Retrieval reference number'
/

comment on column RA_SCM_MESSAGES.FLD_038 is 'Approval identification code'
/

comment on column RA_SCM_MESSAGES.FLD_039 is 'Response action code'
/

comment on column RA_SCM_MESSAGES.FLD_040 is 'Card service code'
/

comment on column RA_SCM_MESSAGES.FLD_041 is 'Card acceptor terminal identification'
/

comment on column RA_SCM_MESSAGES.FLD_042 is 'Card acceptor identification code'
/

comment on column RA_SCM_MESSAGES.FLD_043 is 'Card acceptor name and location'
/

comment on column RA_SCM_MESSAGES.FLD_044 is 'Additional response data'
/

comment on column RA_SCM_MESSAGES.FLD_045 is 'Track 1 data'
/

comment on column RA_SCM_MESSAGES.FLD_046 is 'Amounts, Fees'
/

comment on column RA_SCM_MESSAGES.FLD_048 is 'Additional Data, Private'
/

comment on column RA_SCM_MESSAGES.FLD_049 is 'Transaction currency'
/

comment on column RA_SCM_MESSAGES.FLD_050 is 'Reconciliation currency'
/

comment on column RA_SCM_MESSAGES.FLD_051 is 'Cardholder billing currency'
/

comment on column RA_SCM_MESSAGES.FLD_054 is 'Amounts, Additional'
/

comment on column RA_SCM_MESSAGES.FLD_055 is 'Integrated Circuit Card System Related Data'
/

comment on column RA_SCM_MESSAGES.FLD_056A is 'Original MTI'
/

comment on column RA_SCM_MESSAGES.FLD_056B is 'Original STAN(fld_011)'
/

comment on column RA_SCM_MESSAGES.FLD_056C is 'Original Date and time(fld_012)'
/

comment on column RA_SCM_MESSAGES.FLD_056D is 'Original Acquiring institution code(fld_032)'
/

comment on column RA_SCM_MESSAGES.FLD_057 is 'Authorization Life Cycle Code'
/

comment on column RA_SCM_MESSAGES.FLD_058 is 'Authorizing agent identifier'
/

comment on column RA_SCM_MESSAGES.FLD_059 is 'Transport Data'
/

comment on column RA_SCM_MESSAGES.FLD_060 is 'Reserved'
/

comment on column RA_SCM_MESSAGES.FLD_066 is 'Amounts, original fees'
/

comment on column RA_SCM_MESSAGES.FLD_067 is 'Extended Payment Data'
/

comment on column RA_SCM_MESSAGES.FLD_068 is 'Receiving institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_069 is 'Settlement institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_070 is 'Authorizing agent country code'
/

comment on column RA_SCM_MESSAGES.FLD_071 is 'Message sequence number'
/

comment on column RA_SCM_MESSAGES.FLD_072 is 'Data record'
/

comment on column RA_SCM_MESSAGES.FLD_073 is 'Date, Action'
/

comment on column RA_SCM_MESSAGES.FLD_074 is 'Credits, Number'
/

comment on column RA_SCM_MESSAGES.FLD_075 is 'Credits, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_076 is 'Debits, Number'
/

comment on column RA_SCM_MESSAGES.FLD_077 is 'Debits, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_078 is 'Transfer, Number'
/

comment on column RA_SCM_MESSAGES.FLD_079 is 'Transfer, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_080 is 'Inquiries, Number'
/

comment on column RA_SCM_MESSAGES.FLD_081 is 'Authorizations, Number'
/

comment on column RA_SCM_MESSAGES.FLD_082 is 'Inquiries, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_083 is 'Payments, Number'
/

comment on column RA_SCM_MESSAGES.FLD_084 is 'Payments, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_085 is 'Fee Collections, Number'
/

comment on column RA_SCM_MESSAGES.FLD_086 is 'Credits, Amount'
/

comment on column RA_SCM_MESSAGES.FLD_087 is 'Credits, Reversal Amount'
/

comment on column RA_SCM_MESSAGES.FLD_088 is 'Debits, Amount'
/

comment on column RA_SCM_MESSAGES.FLD_089 is 'Debits, Reversal Amount'
/

comment on column RA_SCM_MESSAGES.FLD_090 is 'Authorisations, Reversal Number'
/

comment on column RA_SCM_MESSAGES.FLD_091 is 'Destination institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_092 is 'Originator institution country code'
/

comment on column RA_SCM_MESSAGES.FLD_093 is 'Destination institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_094 is 'Originator institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_095 is 'Card issuer reference data'
/

comment on column RA_SCM_MESSAGES.FLD_097 is 'Amount, Net Reconciliation'
/

comment on column RA_SCM_MESSAGES.FLD_098 is 'Payee'
/

comment on column RA_SCM_MESSAGES.FLD_099 is 'Settlement institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_100 is 'Receiving institution identifier'
/

comment on column RA_SCM_MESSAGES.FLD_101 is 'File Name'
/

comment on column RA_SCM_MESSAGES.FLD_102 is '"FROM" account identification'
/

comment on column RA_SCM_MESSAGES.FLD_103 is '"TO" account identification'
/

comment on column RA_SCM_MESSAGES.FLD_104 is 'Transaction description'
/

comment on column RA_SCM_MESSAGES.FLD_105 is 'Credits, Chargeback Amount'
/

comment on column RA_SCM_MESSAGES.FLD_106 is 'Debits, Chargeback Amount'
/

comment on column RA_SCM_MESSAGES.FLD_107 is 'Credits, Chargeback Number'
/

comment on column RA_SCM_MESSAGES.FLD_108 is 'Debits, Chargeback Number'
/

comment on column RA_SCM_MESSAGES.FLD_109 is 'Credits, Fee Amounts'
/

comment on column RA_SCM_MESSAGES.FLD_110 is 'Debits, Fee Amounts'
/

comment on column RA_SCM_MESSAGES.FLD_122 is '3D-secure, SPA/UCAF data'
/

comment on column RA_SCM_MESSAGES.FLD_123 is 'CVC2 data'
/

comment on column RA_SCM_MESSAGES.FLD_124 is 'Ministatement information'
/

comment on column RA_SCM_MESSAGES.ORIG_ROW_NUMB is 'ROW NUMB for Original'
/

