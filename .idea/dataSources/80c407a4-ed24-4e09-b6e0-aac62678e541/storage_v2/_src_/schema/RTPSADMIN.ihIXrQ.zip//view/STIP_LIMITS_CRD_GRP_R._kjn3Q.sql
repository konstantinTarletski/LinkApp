create view STIP_LIMITS_CRD_GRP_R as
select
	l.effective_date,
	l.update_date,
	l.purge_date,
	l.centre_id,
	l.param_grp,
	l.limit_id,
	l.limit_type,
	l.limit_ccy,
	l.period_type,
	l.amount,
	l.count,
	l.amount_extra,
	l.count_extra,
	l.expiry_extra,
	l.answ_code_amount,
	l.answ_code_count
from
	stip_limits_crd_grp l
where exists
	(select null
		from centre_users
		where centre_id = l.centre_id and
			username = user)
with check option
/

