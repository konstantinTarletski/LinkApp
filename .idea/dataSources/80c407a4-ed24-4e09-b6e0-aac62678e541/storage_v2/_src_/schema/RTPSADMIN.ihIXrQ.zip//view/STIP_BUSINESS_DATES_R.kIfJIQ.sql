create view STIP_BUSINESS_DATES_R as
select
        bank,
        bank_business_day,
        iia_business_day,
        rec_id,
        step_count,
        deleted
    from
        stip_business_dates
    where
        exists
            (select null
                from
                    centre_users cu,
                    processing_entities pe
                where
                    pe.iss_bank=bank and
                    cu.centre_id=pe.centre_id and
                    cu.username=user)
    with check option
/

