create view STIP_ACTIVATION_RULES_R as
select
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.centre_id,
		x.param_grp,
		x.rule,
		x.rule_id
	from STIP_ACTIVATION_RULES x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

