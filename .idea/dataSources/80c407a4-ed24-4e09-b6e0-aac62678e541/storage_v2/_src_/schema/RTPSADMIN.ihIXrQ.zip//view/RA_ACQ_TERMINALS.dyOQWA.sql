create view RA_ACQ_TERMINALS as
SELECT TERMINAL_ID,
	 MERCHANT_ID,
	 TERMINAL_CITY,
	 TERMINAL_STREET,
	 TERMINAL_PHONE,
	 TERMINAL_TYPE,
	 POINT_CODE,
	 ENABLE_FLAG,
	 CAPTURE_FLAG,
	 FULL_STOP_FLAG,
	 HOT_STOP_FLAG,
	 SOFT_STOP_FLAG,
	 LOG_REQ_FLAG,
	 MAC_FLAG,
	 ZPK_FLAG,
	 DCR_FLAG,
	 LAST_STAN,
	 LAST_REFNUMB,
	 LAST_CARD,
	 LAST_DIAP,
	 BATCH_UPLOAD
FROM MERCHANT_TERMINALS
/

comment on column RA_ACQ_TERMINALS.TERMINAL_ID is 'Terminal identifier'
/

comment on column RA_ACQ_TERMINALS.MERCHANT_ID is 'Card acceptor identifier'
/

comment on column RA_ACQ_TERMINALS.TERMINAL_CITY is 'Terminal location city'
/

comment on column RA_ACQ_TERMINALS.TERMINAL_STREET is 'Terminal location street'
/

comment on column RA_ACQ_TERMINALS.TERMINAL_PHONE is 'Terminal phone'
/

comment on column RA_ACQ_TERMINALS.TERMINAL_TYPE is 'Terminal type identifier'
/

comment on column RA_ACQ_TERMINALS.POINT_CODE is 'Point of service data code (individual data)'
/

comment on column RA_ACQ_TERMINALS.ENABLE_FLAG is 'Terminal activity enable flag'
/

comment on column RA_ACQ_TERMINALS.CAPTURE_FLAG is 'Transactions information capture activation flag'
/

comment on column RA_ACQ_TERMINALS.FULL_STOP_FLAG is 'Full stoplist transmission request flag'
/

comment on column RA_ACQ_TERMINALS.HOT_STOP_FLAG is 'Hot stoplist inclusion in terminal stoplist flag'
/

comment on column RA_ACQ_TERMINALS.SOFT_STOP_FLAG is 'Soft stoplist inclusion in terminal stoplist flag'
/

comment on column RA_ACQ_TERMINALS.LOG_REQ_FLAG is 'LOG file requesting flag'
/

comment on column RA_ACQ_TERMINALS.MAC_FLAG is 'Message authentication code usage flag'
/

comment on column RA_ACQ_TERMINALS.ZPK_FLAG is 'Zone PIN encryption usage flag'
/

comment on column RA_ACQ_TERMINALS.DCR_FLAG is 'Message data contents encryption usage flag'
/

comment on column RA_ACQ_TERMINALS.LAST_STAN is 'Last terminal message system trace audit number used'
/

comment on column RA_ACQ_TERMINALS.LAST_REFNUMB is 'Last terminal message retrieval reference number used'
/

comment on column RA_ACQ_TERMINALS.LAST_CARD is 'Last stoplist version for cards'
/

comment on column RA_ACQ_TERMINALS.LAST_DIAP is 'Last stoplist version for diapasons'
/

comment on column RA_ACQ_TERMINALS.BATCH_UPLOAD is 'Batch processing type'
/

