create view STIP_RESTRMCC_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.param_grp,
		x.mcc_code
	from STIP_RESTRMCC x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

