create view STIP_ACCOUNTS_PRI_V as
SELECT "CENTRE_ID","EFFECTIVE_DATE","UPDATE_DATE","PURGE_DATE","CRD_HOLDR_ID","ACCOUNT_TYPE","ACCOUNT_ID","ACCOUNT_CCY","INITIAL_AMOUNT","BONUS_AMOUNT","LOCKED_AMOUNT","ACCOUNT_ID_BANK","ADD_INFO","CREDIT_LIMIT","LOCK_TIME","LOCK_AMOUNT_CMS","AMOUNT_SET_TIME","COMM_GRP","SHADOW_AMOUNT","TIME_STAMP","PRIORITY","STATUS","CREDIT_LIMIT_EXPIRY","BONUS_AMOUNT_EXPIRY","REC_ID","STEP_COUNT","DELETED","LOCK_AMOUNT_CMS_OFL","OFFLINE_LOCKED","OFFLINE_CLEARED" FROM (
			SELECT ac.centre_id,
						ac.effective_date, ac.update_date, ac.purge_date,
						ac.crd_holdr_id, ac.account_type, ac.account_id,
						ac.account_ccy, ac.initial_amount, ac.bonus_amount,
						ac.locked_amount, ac.account_id_bank, ac.add_info,
						ac.credit_limit, ac.lock_time, ac.lock_amount_cms,
						ac.amount_set_time, ac.comm_grp, ac.shadow_amount,
						ac.time_stamp, ac.priority, ac.status,
						ac.credit_limit_expiry, ac.bonus_amount_expiry, ac.rec_id,
						ac.step_count, ac.deleted, ac.lock_amount_cms_ofl,
						ac.offline_locked, ac.offline_cleared
				FROM
					stip_accounts ac
				WHERE
					ac.account_type = '00'
				ORDER BY
					nvl(ac.priority, '1') ASC
		)
	UNION ALL
		SELECT "CENTRE_ID","EFFECTIVE_DATE","UPDATE_DATE","PURGE_DATE","CRD_HOLDR_ID","ACCOUNT_TYPE","ACCOUNT_ID","ACCOUNT_CCY","INITIAL_AMOUNT","BONUS_AMOUNT","LOCKED_AMOUNT","ACCOUNT_ID_BANK","ADD_INFO","CREDIT_LIMIT","LOCK_TIME","LOCK_AMOUNT_CMS","AMOUNT_SET_TIME","COMM_GRP","SHADOW_AMOUNT","TIME_STAMP","PRIORITY","STATUS","CREDIT_LIMIT_EXPIRY","BONUS_AMOUNT_EXPIRY","REC_ID","STEP_COUNT","DELETED","LOCK_AMOUNT_CMS_OFL","OFFLINE_LOCKED","OFFLINE_CLEARED" FROM (
				SELECT ac.centre_id,
						ac.effective_date, ac.update_date, ac.purge_date,
						ac.crd_holdr_id, ac.account_type, ac.account_id,
						ac.account_ccy, ac.initial_amount, ac.bonus_amount,
						ac.locked_amount, ac.account_id_bank, ac.add_info,
						ac.credit_limit, ac.lock_time, ac.lock_amount_cms,
						ac.amount_set_time, ac.comm_grp, ac.shadow_amount,
						ac.time_stamp, ac.priority, ac.status,
						ac.credit_limit_expiry, ac.bonus_amount_expiry, ac.rec_id,
						ac.step_count, ac.deleted, ac.lock_amount_cms_ofl,
						ac.offline_locked, ac.offline_cleared
					FROM
						stip_accounts ac
					WHERE
						ac.account_type <> '00'
					ORDER BY
						nvl(ac.priority, '1') ASC
		)
/

