create view ERR_MSG_SEC_FULL
            (SECTION_CODE, COL1, COL2, COL3, MESSAGE, ERR_REC_NUM, ERROR_DATE, ERROR_CODE, PROGRAM_CODE, ERROR_SOURCE,
             MSG_ARGUMENTS, PROGRAM_TYPE, PROGRAM_NAME, PROGRAM_NAME_ABBR, PROGRAM_TYPE_ABBR, STORE_FLAG, ERROR_CLASS,
             ERROR_CLASS_ABBR, ERROR_SEVERITY, ERROR_SEVERITY_ABBR, ERROR_ARGUMENTS, MSG_TEMPLATE, ACTION_CODE,
             MSG_FULL)
as
select --+ rule
   err_msg_sec.section_code,
   err_msg_sec.col1,
   err_msg_sec.col2,
   err_msg_sec.col3,
    substr(replace(replace(merge_error_msg('<<%message>>',
                    null,
                    null,
                    nvl(err_dict.msg_template,'Undeffined message "<<msg>>"'),
                    decode(err_dict.msg_template,null,translate(err_msg.msg_arguments,'|','!'),err_msg.msg_arguments),
                    decode(err_dict.msg_template,null,'msg',err_desc.error_arguments),
                    err_msg.err_rec_num,
                    err_msg.error_date,
                    err_msg.error_code,
                    err_msg.program_code,
                    prog_n.program_name,
                    err_msg.error_source,
                    prog_n.program_type,
                    prog_n.abbreviature,
                    prog_t.abbreviature,
                    err_desc.action_code,
                    err_desc.error_class,
                    err_clas.abbreviature,
                    err_desc.error_severity,
                    err_sev.abbreviature,
                    null
                    ),CHR(13)||CHR(10),CHR(10)),CHR(10),CHR(13)||CHR(10)),1,255),
    err_msg.err_rec_num,
    err_msg.error_date,
    err_msg.error_code,
    err_msg.program_code,
    err_msg.error_source,
    err_msg.msg_arguments,
    prog_n.program_type,
    prog_n.program_name,
    prog_n.abbreviature,
    prog_t.abbreviature,
    err_desc.store_flag,
    err_desc.error_class,
    err_clas.abbreviature,
    err_desc.error_severity,
    err_sev.abbreviature,
    err_desc.error_arguments,
    err_dict.msg_template,
    err_desc.action_code,
    null
from
    error_severities    err_sev,
    error_descriptions  err_desc,
    program_names       prog_n,
    program_types       prog_t,
    error_msg_sections  err_msg_sec,
    error_messages      err_msg,
    error_classes       err_clas,
    error_dictionary    err_dict
where
    err_desc.program_code=err_msg.program_code and
    err_desc.error_code=err_msg.error_code and
    prog_n.program_code=err_desc.program_code and
    prog_t.program_type=prog_n.program_type and
    err_clas.error_class=err_desc.error_class and
    err_sev.error_severity=err_desc.error_severity and
    err_dict.program_code (+) =err_desc.program_code and
    err_dict.error_code (+) =err_desc.error_code and
    err_dict.msg_template_nr (+) = 0 and
    err_msg.err_rec_num=err_msg_sec.err_rec_num
--	order by err_msg.err_rec_num
/

