create PACKAGE
STIP_CALL_API
IS
--#===================================================================================================================================
--#		RTPS.IIA
--#
--#		API priekss Call Center
--#			Kodeja: Karlis Ogsts
--#
--#		(C) Tieto Konts Financial Systems Ltd. 1998-2004
--#===================================================================================================================================
	type t_Account_Item is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		crd_holdr_id varchar2(19),
		account_type char(2),
		account_id varchar2(28),
		account_ccy char(3),
		initial_amount number(16),
		bonus_amount number(16),
		locked_amount number(16),
		lock_amount_cms number(16),
		credit_limit number(16),
		account_id_bank varchar2(35)
		);
	type t_AccChg_Item is record
		(
		jn_operation char(3),
		jn_oracle_user varchar2(30),
		jn_datetime date,
		jn_notes varchar2(240),
		jn_appln varchar2(30),
		jn_session number(38),
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		crd_holdr_id varchar2(19),
		account_type char(2),
		account_id varchar2(28),
		account_ccy char(3),
		initial_amount number(16),
		bonus_amount number(16),
		locked_amount number(16),
		credit_limit number(16),
		account_id_bank varchar2(35)
		);
	type t_RMSStopList_Item is record
		(
		centre_id varchar2(11),
		card_number varchar2(19),
		effective_date date,
		update_date date,
		purge_date date,
		action_code char(3),
		description varchar2(255),
		rule_expression varchar2(1000),
		priority number(6)
		);
	type t_Cards_Item is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		card_number varchar2(19),
		crd_holdr_id varchar2(19),
		crd_holdr_name varchar2(30),
		crd_holdr_pwd varchar2(20),
		crd_holdr_msg varchar2(99),
		stat_code_1 char(3),
		stat_code_2 char(3),
		expiry_date_1 char(4),
		expiry_date_2 char(4),

		card_seq_1 varchar2(3),
		card_seq_2 varchar2(3),

		acnt_restr varchar2(1),
		----------------------
		stop_action_code char(3),
		stop_effective_date date,
		stop_description varchar2(255),
		----------------------
		ustop_action_code char(3),
		ustop_effective_date date,
		ustop_description varchar2(255)
		);

	type t_Cards2_Item is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		card_number varchar2(19),
		crd_holdr_id varchar2(19),
		crd_holdr_name varchar2(30),
		crd_holdr_pwd varchar2(20),
		crd_holdr_msg varchar2(99),
		stat_code_1 char(3),
		stat_code_2 char(3),
		expiry_date_1 char(4),
		expiry_date_2 char(4),
		acnt_restr varchar2(1),
		param_grp_1 varchar2(5),
		param_grp_2 varchar2(5),
		----------------------
		stop_action_code char(3),
		stop_effective_date date,
		stop_description varchar2(255),
		----------------------
		ustop_action_code char(3),
		ustop_effective_date date,
		ustop_description varchar2(255)
		);

	type t_Auth_Item is record
		(
		row_numb number(11),
		msg_type char(4),
		fld_002  varchar2(19),
		fld_003  char(6),
		fld_004  number(12),
		fld_049  char(3),
		fld_006  number(12),
		fld_051  char(3),
		fld_012  date,
		fld_022  char(12),
		fld_026  char(4),
		fld_032  varchar2(11),
		fld_033  varchar2(11),
		fld_038  char(6),
		fld_041  char(8),
		fld_042  char(15),
		fld_043  varchar2(99)
		);
	type t_Auth_Item2 is record
		(
		row_numb number(11),
		msg_type char(4),
		fld_002  varchar2(19),
		fld_003  char(6),
		fld_004  number(12),
		fld_049  char(3),
		fld_006  number(12),
		fld_051  char(3),
		fld_012  date,
		fld_022  char(12),
		fld_026  char(4),
		fld_032  varchar2(11),
		fld_033  varchar2(11),
		fld_038  char(6),
		fld_041  char(8),
		fld_042  char(15),
		fld_043  varchar2(99),
		lock_amount number(16)
		);
	type t_Client_Item is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		crd_holdr_id varchar2(19),
		crd_holdr_pwd varchar2(20),
		crd_holdr_msg varchar2(99),
		crd_holdr_name varchar2(200)
		);
	type t_Auth_Ext_Item is record
		(
		row_numb number(11),
		centre_id varchar2(11),
		request_date date,
		card_type char(2),
		dev_type char(1),
		msg_type char(4),
		fld_002 varchar2(19),
		fld_003 char(6),
		fld_004 number(12),
		fld_006 number(12),
		fld_007 date,
		fld_010 number(16,9),
		fld_011 char(6),
		fld_012 date,
		fld_014 char(4),
		fld_022 char(12),
		fld_024 char(3),
		fld_025 char(4),
		fld_026 char(4),
		fld_030a number(12),
		fld_032 varchar2(11),
		fld_033 varchar2(11),
		fld_035 varchar2(37),
		fld_037 char(12),
		fld_038 char(6),
		fld_039 char(3),
		fld_041 char(8),
		fld_042 char(15),
		fld_043 varchar2(99),
		fld_049 char(3),
		fld_051 char(3),
		fld_054 varchar2(360),
		fld_055 varchar2(255),
		fld_056a char(4),
		fld_056b char(6),
		fld_056c date,
		fld_056d varchar2(11),
		fld_072 varchar2(4000),
		fld_093 varchar2(11),
		fld_094 varchar2(11),
		fld_100 varchar2(11),
		fld_102 varchar2(28),
		param_grp varchar2(5),
		child_row number(11),
		reverse_flag char(1),
		locking_sign number(2),
		locking_flag char(1),
		unlocking_reason char(1),
		unlocking_date date,
		fld_046 varchar2(204),
		fld_095 varchar2(99),
		comm_grp varchar2(12),
		comm_id number(4),
		fld_005 number(12),
		fld_009 number(8),
		fld_023 varchar2(3),
		fld_028 date,
		fld_029 varchar2(3),
		fld_031 varchar2(99),
		fld_050 varchar2(3),
		fld_103 varchar2(28),
		fld_123 varchar2(999)
		);

	type t_Tran_Item is record
		(
		hist_numb number(11),
		centre_id varchar2(11),
		effective_date date,
		dev_type char(1),
		msg_type char(4),
		fld_002 varchar2(19),
		fld_003 char(6),
		fld_004 number(12),
		fld_005 number(12),
		fld_006 number(12),
		fld_011 char(6),
		fld_012 date,
		fld_022 char(12),
		fld_026 char(4),
		fld_037 char(12),
		fld_038 char(6),
		fld_041 char(8),
		fld_042 char(15),
		fld_043 varchar2(99),
		fld_046 varchar2(204),
		fld_049 char(3),
		fld_050 char(3),
		fld_051 char(3),
		fld_072 varchar2(999),
		fld_101 varchar2(17),
		fld_102 varchar2(28),
		fld_103 varchar2(28),
		fld_102_bank varchar2(28),
		fld_103_bank varchar2(28),
		tran_id varchar2(11),
		post_date date,
		batch_nr varchar2(7),
		slip_nr varchar2(8),
		tran_desc varchar2(350),
		add_info varchar2(999),
		event_numb number(11),
		authoriz_flag char(1),
		process_flag char(1)
		);
	type t_Auth_Hist_Item is record
		(
		msg_type varchar2(4),
		auth_date varchar2(19),
		amount varchar2(14),
		trans_type varchar2(2),
		locking varchar2(1),
		ccy_num varchar2(3),
		ccy_alpha varchar2(3),
		location varchar2(99)
		);
	type t_Client_Item2 is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		crd_holdr_id varchar2(19),
		crd_holdr_pwd varchar2(20),
		crd_holdr_msg varchar2(99),
		crd_holdr_name varchar2(200),
		add_info varchar2(999)
		);
	type t_Account_OTB_Item is record
		(
		centre_id varchar2(11),
		effective_date date,
		update_date date,
		purge_date date,
		crd_holdr_id varchar2(19),
		account_type char(2),
		account_id varchar2(28),
		account_ccy_alpha char(3),	-- alphanumeric currency code
		initial_amount number(16),
		bonus_amount number(16),
		locked_amount number(16),
		lock_amount_cms number(16),
		credit_limit number(16),
		account_id_bank varchar2(35),
		open_to_buy number(16)
		);
	subtype t_CmdQueue_Item is stip_chip_cmd_queue_r%rowtype;

	type t_Account_OTB_List is table of t_Account_OTB_Item index by binary_integer;
	type t_AccountList is table of t_Account_Item index by binary_integer;
	type t_AccChgList is table of t_AccChg_Item index by binary_integer;
	type t_RMSStopList is table of t_RMSStopList_Item index by binary_integer;
	type t_CardsList is table of t_Cards_Item index by binary_integer;
	type t_AuthList is table of t_Auth_Item index by binary_integer;
	type t_AuthList2 is table of t_Auth_Item2 index by binary_integer;
	type t_Auth_Ext_List is table of t_Auth_Ext_Item index by binary_integer;
	type t_TranList is table of t_Tran_Item index by binary_integer;
	type t_Auth_Hist_List is table of t_Auth_Hist_Item index by binary_integer;

	type t_Account_OTB_Curs is ref cursor return t_Account_OTB_Item;
	type t_Auth_Hist_Curs is ref cursor return t_Auth_Hist_Item;
	--#======================================================================================================================================
	--#
	--#									A	P	I				F	U	N	K	C	I	J	A	S
	--#
	--#======================================================================================================================================

	--============================================================================
	-- Konta statusa iestatiisana
	--============================================================================
	function SetAccStatus(
		p_centre_id in varchar2,
		p_account_id in varchar2,
		p_status in varchar2 ) return boolean;

	--============================================================================
	-- Peedeejaas klluudas kods un texts
	--============================================================================
	procedure GetLastError(p_errortext_maxlen in number,
								p_errorcode out number,
								p_oraerrcode out number,
								p_errortext out varchar2);
	--#===========================================================================================================================
	--#
	--#									CLIENT => ACCOUNTLIST
	--#
	--#===========================================================================================================================
	function GetClientsAccounts(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_accountslist out t_accountlist,
								p_more out boolean) return boolean;
	function GetClientsAccounts(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_accountslist out t_accountlist,
								p_more out boolean,
								p_regerr in boolean) return boolean;
	--============================================================================
	-- Atgriezz karssu sarakstu peec klienta id.
	--============================================================================
	function GetClientsCards(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_cardslist out t_cardslist,
								p_more out boolean) return boolean;
	--============================================================================
	-- Atgriezz karssu sarakstu peec account id.
	--============================================================================
	function GetAccountsCards(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in varchar2,
								p_cardslist out t_cardslist,
								p_more out boolean) return boolean;
	--============================================================================
	-- Atgriezz konta izmainnu veestures sarakstu peec konta id.
	--============================================================================
	function GetAccChangeHistory(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in date,
								p_accchglist out t_accchglist,
								p_more out boolean) return boolean;
	--============================================================================
	-- Atgriezz konta blokkeejossaas autorizaacijas peec konta id.
	--============================================================================
	function GetAccLockingAuth(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in number,
								p_authlist out t_authlist,
								p_more out boolean) return boolean;
	--============================================================================
	-- Atgriezz konta blokkeejossaas autorizaacijas peec konta id. + locked amount
	--============================================================================
	function GetAccLockingAuth2(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in number,
								p_authlist out t_authlist2,
								p_more out boolean) return boolean;
	--#===========================================================================================================================
	--#
	--#								ATGRIEZZ KARTES INFORMACIJU PEEC KARTES NUMURA
	--#
	--#===========================================================================================================================
	function GetCardInfo(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_cardinfo out t_cards_item) return boolean;
	function GetCard2Info(p_centre_id in varchar2,
						p_card_numb in varchar2,
						p_cardinfo out t_cards2_item) return boolean;

	--#===========================================================================================================================
	--#
	--#							ATGRIEZZ KARTES INFORMACIJU NO RMS STOP-SARAKSTA PEEC KARTES NUMURA
	--#
	--#===========================================================================================================================
	function GetCardRMSStopListInfo(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_cardinfo out t_RMSStopList) return boolean;
	--#===========================================================================================================================
	--#
	--#									KARTES NUMURS => CENTRA IDENTIFIKATORS
	--#
	--#===========================================================================================================================
	function GetCardCentreId(p_card_num in varchar2,
							p_centre_id out varchar2) return boolean;
	--#===========================================================================================================================
	--#
	--#									KARTES NUMURS => CENTRA IDENTIFIKATORS UN EXPIRY (MMYY)
	--#
	--#===========================================================================================================================
	function GetCentreIdExpCrdNum(p_card_num in varchar2,
							p_centre_id out varchar2, p_expiry_date out varchar2) return boolean;

	function GetStatCode( l_cardinfo in t_cards_item ) return varchar2;
	--#===========================================================================================================================
	--#
	--#											KARTES NUMURS => OTB
	--#
	--#===========================================================================================================================
	function GetCardOtb(p_card_num in varchar2,
							p_centre_id out varchar2,
							p_otb out number,
							p_locked out number,
							p_ccy out varchar2,
							p_hot_status out varchar2,
							p_hot_status_msg out varchar2,
							p_hot_description out varchar2,
							p_iss_status out varchar2,
							p_iss_status_msg out varchar2,
							p_iss_description out varchar2,
							p_status out varchar2,
							p_status_msg out varchar2,
							p_account_type in varchar2 default NULL
							) return boolean;

	function GetCardOtbAdmin(p_card_num in varchar2, p_centre_id out varchar2, p_locked out number,
		p_lock_rtps out number, p_lock_cms out number, p_cleared out number, p_overdraft out number,
		p_bonus out number, p_otb out number, p_ccy out varchar2,
		p_hot_status out varchar2, p_hot_status_msg out varchar2, p_hot_description out varchar2,
		p_iss_status out varchar2, p_iss_status_msg out varchar2, p_iss_description out varchar2,
		p_usr_status out varchar2, p_usr_status_msg out varchar2, p_usr_description out varchar2,
		p_status out varchar2, p_status_msg out varchar2, p_account_type in varchar2 default NULL) return boolean;

	-- CIR-7403 added p_account_id, p_account_id_bank
	function GetCardOtbAdmin(p_card_num in varchar2, p_centre_id out varchar2, p_locked out number,
		p_lock_rtps out number, p_lock_cms out number, p_cleared out number, p_overdraft out number,
		p_bonus out number, p_otb out number, p_ccy out varchar2,
		p_hot_status out varchar2, p_hot_status_msg out varchar2, p_hot_description out varchar2,
		p_iss_status out varchar2, p_iss_status_msg out varchar2, p_iss_description out varchar2,
		p_usr_status out varchar2, p_usr_status_msg out varchar2, p_usr_description out varchar2,
		p_status out varchar2, p_status_msg out varchar2, p_account_id out varchar2, p_account_id_bank out varchar2, p_account_type in varchar2 default NULL) return boolean;

	--#====================================================================================================================
	--#
	--#					GETCARDACCOUNTSOTBCURS - gets information about card (with stop-list inf. and cursor)
	--#
	--#====================================================================================================================
	function GetCardAccountsOtbCurs(
		p_card_number IN varchar2,      -- Card number
		p_hot_status OUT varchar2,      -- Operative stoplist status
		p_hot_status_msg OUT varchar2,  -- Op. stoplist status description
		p_hot_description OUT varchar2, -- Op. stoplist reason description
		p_iss_status OUT varchar2,      -- Issuer stoplist status
		p_iss_status_msg OUT varchar2,  -- Issuer stoplist status description
		p_iss_description OUT varchar2, -- Issuer stoplist reason description
		p_status OUT varchar2,          -- Card status code
		p_status_msg OUT varchar2,      -- Card status description
		p_accounts IN OUT NOCOPY t_Account_OTB_Curs  -- Account and OTB cursor
	) return boolean;

--#====================================================================================================================
--#
--#					EXECUTEPAYMENT -
--#
--#====================================================================================================================
	function executePayment(
		p_centre_id IN varchar2,
		p_account_id IN varchar2,
		p_tran_amnt IN number,
		p_otb_calc_mode IN varchar2) return number;


	--#============================================================================
	--# Atgriezz kartes un RTPS stopsaraksta informaciju peec kartes numura.
	--#============================================================================
	function GetCardInfoExt(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_cardinfo out t_cards_item,
							p_action_code out varchar2,
							p_description out varchar2) return boolean;
	--============================================================================
	-- Atgriezz klienta informaciju peec klienta id.
	--============================================================================
	function GetClientInfo(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_clientinfo out t_client_item) return boolean;
	function GetClientInfo2(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_clientinfo out t_client_item2) return boolean;

	--============================================================================
	-- Atgriezz konta informaciju peec konta id.
	--============================================================================
	function GetAccountInfo(p_centre_id in varchar2,
							p_account_id in varchar2,
							p_accountinfo out t_account_item) return boolean;
	--============================================================================
	-- Atgriezz konta informaciju peec bankas konta numura.
	--============================================================================
	function GetBankAccountInfo(p_centre_id in varchar2,
							p_account_id_bank in varchar2,
							p_accountinfo out t_account_item) return boolean;
	--============================================================================
	-- Atgriezz kartes blokkeejossaas autorizaacijas peec kartes numura.
	--============================================================================
	function GetCrdLockingAuth(p_centre_id in varchar2,
							p_card in varchar2,
							p_starting_from in number,
							p_authlist out t_authlist,
							p_More OUT boolean) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura.
	--============================================================================
	function GetCrdAuth(p_centre_id in varchar2,
							p_card in varchar2,
							p_starting_from in date,
							p_last_row_numb in varchar2,
							p_l out t_auth_ext_list,
							p_more out boolean) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura.
	--============================================================================
	function GetCardAuthList(p_card_num in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura un konta tipa.
	--============================================================================
	function GetCardAuthListByAcType(p_card_num in out varchar2,p_acnt_type_from in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura un alfa valutas.
	--============================================================================
	function GetCardAuthListByCcyAlpha(p_card_num in out varchar2,p_ccy_alpha in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura.
	--============================================================================
	function GetCardAuthCurs(p_card_num in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura un konta tipa.
	--============================================================================
	function GetCardAuthCursByAcType(p_card_num in out varchar2,p_acnt_type_from in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return boolean;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura un alfa valutas.
	--============================================================================
	function GetCardAuthCursByCcyAlpha(p_card_num in out varchar2,p_ccy_alpha in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return boolean;
        --============================================================================
        -- ATLASA KLIENTA KONTUS
        --============================================================================
	function GetCardsAccounts(p_centre_id in varchar2,
						p_card in varchar2,
						p_crd_holdr_id in varchar2,
						p_restrict in varchar2,
						p_accountslist out t_accountlist) return boolean;

	--============================================================================
	-- Uzstaada kartes statusu peec kartes numura.
	--============================================================================
	function SetCardStatus(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_card_seq in number,
							p_cardstatus in char) return boolean;
	--============================================================================
	-- Kartes iznnemssana no stopsaraksta
	--============================================================================
	function RemoveCardFromStop(p_centre_id in varchar2,p_card_numb in varchar2) return boolean;
	--============================================================================
	-- Kartes ielikssana stopsarakstaa
	--============================================================================
	function AddCardToStop(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_action_code in varchar2,
							p_description in varchar2) return boolean;

	--============================================================================
	-- Kartes akumulaatoru resets
	--============================================================================
	function ResetCardAccum(
			p_centre_id in varchar2,
			p_card_numb in varchar2) return boolean;
	--============================================================================
	-- Konta INITIAL summas izmainna
	--============================================================================
	function SetAccInitialAmount(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_initialamount in number,
			p_relativeAmountChange in boolean default false,
			p_effective_date in date default null) return boolean;
	--============================================================================
	-- Konta BONUS summas izmainna
	--============================================================================
	function SetAccBonusAmount(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_bonusamount in number) return boolean;
	--==============================================================================
	-- Uzstaada konta valuutu (cipariskaa formaa)
	--==============================================================================
	function SetAccountCcy(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_ccy_num in varchar2) return boolean;
	--==============================================================================
	-- Uzstaada konta valuutu (alfacipariskaa formaa)
	--==============================================================================
	function SetAccountCcyAlpha(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_ccy_alpha in varchar2) return boolean;
	--============================================================================
	-- Blokkeejossaas autorizaacijas atblokkeessana
	--============================================================================
	function UnlockAuthAmount(
			p_centre_id in varchar2,
			p_authrownumb in number) return boolean;
	--============================================================================
	-- Paarbauda kartes CVC2
	--============================================================================
	function Verify_CVC2(p_centre_id in varchar2,
			p_card_numb in varchar2,
			p_expiry_date in varchar2,
			p_cvc2 in varchar2) return boolean;
	--========================================================================
	-- Seting card limits for calendar limits
	--========================================================================
	function SetCrdLimit(bank_c in	varchar2,
							groupc in varchar2,
							ctime in date,
							data_action in char,
							card_number in varchar2,
							limit_id in varchar2,
							limit_type in char,
							limit_ccy in char,
							period_type in char,
							amount in number,
							auth_count in number,
							amount_extra in number,
							count_extra in number,
							expiry_extra in date,
							answ_code_amount in char,
							answ_code_count in char) return boolean;
	--========================================================================
	-- Seting card group limits for calendar limits
	--========================================================================
	function SetCrdGrpLimit(bank_c in	varchar2,
							groupc in varchar2,
							ctime in date,
							data_action in char,
							param_grp in varchar2,
							limit_id in varchar2,
							limit_type in char,
							limit_ccy in char,
							period_type in char,
							amount in number,
							auth_count in number,
							amount_extra in number,
							count_extra in number,
							expiry_extra in date,
							answ_code_amount in char,
							answ_code_count in char) return boolean;

	procedure msg(e integer,m varchar2);
	--============================================================================
	-- Kartes iznnemssana no user stopsaraksta
	--============================================================================
	function RemoveCardFromUserStop(
			p_centre_id in varchar2,
			p_card_numb in varchar2) return boolean;
	--============================================================================
	-- Kartes ielikssana user stopsarakstaa
	--============================================================================
	function AddCardToUserStop(
			p_centre_id in varchar2,
			p_card_numb in varchar2,
			p_action_code in varchar2,
			p_description in varchar2) return boolean;
	--============================================================================
	-- Konta LOCK_AMOUNT_CMS summas izmainna
	--============================================================================
	function SetAccLockCMSAmount(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_lock_amount_cms in number) return boolean;
	--------------------------------------------------------------------------------
	-- Change card carholder
	--------------------------------------------------------------------------------
	function ChangeCardClient (
		p_centre_id in varchar2,
		p_card_num in varchar2,
		p_crd_holdr_id in varchar2) return boolean;
	--------------------------------------------------------------------------------
	-- Bind account to card
	--------------------------------------------------------------------------------
	function CardAccountLinkage (
		p_centre_id in varchar2,
		p_crd_holdr_id in varchar2,
		p_card_num in varchar2,
		p_account_id in varchar2,
		p_account_type in varchar2) return boolean;
	--------------------------------------------------------------------------------
	-- Relink card and accounts
	--------------------------------------------------------------------------------
	function RelinkCardAndAccounts(p_centre_id in varchar2,
									p_crd_holdr_id in varchar2,
									p_card_num in varchar2,
									p_new_crd_holdr_id in varchar2,
									p_account_mapping in varchar2,
									p_mapping_type in varchar2,
									p_new_client_id in varchar2 default null) return boolean;

	--------------------------------------------------------------------------------
	-- Relink card and accounts
	--------------------------------------------------------------------------------

	function RelinkCardAndAccounts2(p_centre_id in varchar2,
									p_crd_holdr_id in varchar2,
									p_card_num in varchar2,
									p_new_crd_holdr_id in varchar2,
									p_account_mapping in varchar2,
									p_mapping_type in varchar2,
									p_new_client_id in varchar2 default null) return boolean;

	--------------------------------------------------------------------------------
	-- Change cardholder for Account
	--------------------------------------------------------------------------------

	function LinkClientToAccount(p_centre_id in varchar2,
									p_crd_holdr_id_new in varchar2,
									p_account_id in varchar2) return boolean;

	--------------------------------------------------------------------------------
	-- Log funkcija (paredzeeta, lai tiktu izsaukta no citaam saistiitaam packaageem
	--------------------------------------------------------------------------------
	procedure Logs(p_level number,p_msg varchar2);

	--------------------------------------------------------------------------------
	-- FlushLog funkcija paradzÄ“ta, lai viss Log saturs tiktu momentÄ ierakstÄ«ts failÄ
	--------------------------------------------------------------------------------
	procedure FlushLog;


	--------------------------------------------------------------------------------
	--							GET BUSINESS DAY
	--------------------------------------------------------------------------------
	function GetBusinessDay(p_bank_id in varchar2,
							p_rtps_date out varchar2,
							p_bank_date out varchar2) return boolean;

	--------------------------------------------------------------------------------
	--							SET BUSINESS DAY
	--------------------------------------------------------------------------------
	function SetBusinessDay(p_bank_id in varchar2,
							p_rtps_date in varchar2,
							p_bank_date in varchar2) return boolean;

	--========================================================================
	-- Add card to RMS stoplist
	--========================================================================
	function AddCardToRMSStop(
							p_centre_id   varchar2, -- card STIP CENTRE_ID, if NULL searched in STIP_PREFIXES
							p_card_number varchar2, -- card number, no default value
							p_rule_expr   varchar2, -- FML rule to check, no default value
							p_priority    number,   -- rule search priority, always negative, if NULL search next acceptable
							p_action_code varchar2, -- action code for card in stoplist, if NULL 100 used
							p_description varchar2  -- description, if NULL function name used
					) return boolean;

	--========================================================================
	-- Remove card from RMS stoplist
	--========================================================================
	function RemoveCardFromRMSStop(
							p_centre_id   varchar2, -- card STIP CENTRE_ID, if NULL not used
							p_card_number varchar2, -- card number, not NULL accepted
							p_rule_expr   varchar2, -- FML rule, if NULL not used
							p_priority    number,   -- rule search priority, always negative, if NULL not used
							p_action_code varchar2, -- action code for card in stoplist, if NULL not used
							p_description varchar2  -- description, if NULL not used
					) return boolean;

	--========================================================================
	-- Add card to RMS stoplist 2, no commit
	--========================================================================
	function AddCardToRMSStop2(
							p_centre_id   varchar2, -- card STIP CENTRE_ID, if NULL searched in STIP_PREFIXES
							p_card_number varchar2, -- card number, no default value
							p_rule_expr   varchar2, -- FML rule to check, no default value
							p_priority    number,   -- rule search priority, always negative, if NULL search next acceptable
							p_action_code in out varchar2, -- action code for card in stoplist, if NULL 100 used
							p_description varchar2,  -- description, if NULL function name used
							p_err_str out varchar2 --error description
					) return boolean;

	--========================================================================
	-- Remove card from RMS stoplist 2, no commit
	--========================================================================
	function RemoveCardFromRMSStop2(
							p_centre_id   varchar2, -- card STIP CENTRE_ID, if NULL not used
							p_card_number varchar2, -- card number, not NULL accepted
							p_priority    number,   -- rule search priority, always negative, if NULL not used
							p_action_code out varchar2, -- action code for card in stoplist, if NULL not used
							p_err_str out varchar2 --error description
					) return boolean;

	--============================================================================
	-- Set Risk Group for client
	--============================================================================
	function SetClientParamGrp(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_param_grp in varchar2) return boolean;

	--============================================================================
	-- Set Risk Group for card
	--============================================================================
	function SetCardParamGrp(p_centre_id in varchar2,
							p_card_num in varchar2,
							p_param_grp in varchar2) return boolean;

	--============================================================================
	-- Set credit limit or overdraft for account
	--============================================================================
	function SetAccCreditLimit(
		p_centre_id in varchar2,
		p_account_id in varchar2,
		p_creditlimit in number,
		p_relativeAmountChange in boolean default false,
		p_initial_amount_adj in boolean default false,
		p_credit_limit_exp in date default null) return boolean;

	--============================================================================
	-- Kartes pintry resets
	--============================================================================
	function ResetCardPinTryCounter(
			p_bank_c in varchar2,
			p_groupc in varchar2,
			p_card_numb in varchar2,
			p_reason in out varchar2,
			p_reset_offline in boolean default false,
			p_expiry in varchar2 default null
			) return boolean;
	function ResetCardPinTryCounter(
			p_bank_c in varchar2,
			p_groupc in varchar2,
			p_card_numb in varchar2,
			p_reason in out varchar2,
			p_cmd_item in out t_CmdQueue_Item,
			p_reset_offline in boolean default false,
			p_expiry in varchar2 default null
			) return boolean;
	--============================================================================
	-- Kartes pintry skaits
	--============================================================================
	function GetCardPinTryCounter(
			p_bank_c in varchar2,
			p_groupc in varchar2,
			p_card_numb in varchar2,
			p_update_date out varchar2,
			p_pintry_count out number
			) return boolean;

	--============================================================================
	-- Update rtps currency conversion rates
	--============================================================================
	function UpdateRates(l_pay_ccy_alpha in varchar2, l_ccy_to_alpha in varchar2, l_bank in varchar2,
			l_buy_rate in number, l_mid_rate in number,
			l_sell_rate in number) return boolean;


--#===========================================================================================================================
--#
--#			N U M E R I C A L   D E C L A R A T I O N S   F O R   T H E   S A M E   F U N C T I O N S
--#
--#===========================================================================================================================
	--#===========================================================================================================================
	--#
	--#									CLIENT => ACCOUNTLIST
	--#
	--#===========================================================================================================================
	function GetClientsAccounts_N(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_accountslist out t_accountlist,
								p_more out boolean) return number;
	function GetClientsAccounts_N(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_accountslist out t_accountlist,
								p_more out boolean,
								p_regerr in boolean) return number;
	--============================================================================
	-- Atgriezz karssu sarakstu peec klienta id.
	--============================================================================
	function GetClientsCards_N(p_centre_id in varchar2,
								p_crd_holdr_id in varchar2,
								p_starting_from in varchar2,
								p_cardslist out t_cardslist,
								p_more out boolean) return number;
	--============================================================================
	-- Atgriezz karssu sarakstu peec account id.
	--============================================================================
	function GetAccountsCards_N(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in varchar2,
								p_cardslist out t_cardslist,
								p_more out boolean) return number;
	--============================================================================
	-- Atgriezz konta izmainnu veestures sarakstu peec konta id.
	--============================================================================
	function GetAccChangeHistory_N(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in date,
								p_accchglist out t_accchglist,
								p_more out boolean) return number;
	--============================================================================
	-- Atgriezz konta blokkeejossaas autorizaacijas peec konta id.
	--============================================================================
	function GetAccLockingAuth_N(p_centre_id in varchar2,
								p_account_id in varchar2,
								p_starting_from in number,
								p_authlist out t_authlist,
								p_more out boolean) return number;
	--#===========================================================================================================================
	--#
	--#								ATGRIEZZ KARTES INFORMACIJU PEEC KARTES NUMURA
	--#
	--#===========================================================================================================================
	function GetCardInfo_N(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_cardinfo out t_cards_item) return number;
	function GetCard2Info_N(p_centre_id in varchar2,p_card_numb in varchar2,p_cardinfo out t_cards2_item)return number;
	--#===========================================================================================================================
	--#
	--#									KARTES NUMURS => CENTRA IDENTIFIKATORS
	--#
	--#===========================================================================================================================
	function GetCardCentreId_N(p_card_num in varchar2,
							p_centre_id out varchar2) return number;
	--#===========================================================================================================================
	--#
	--#									KARTES NUMURS => CENTRA IDENTIFIKATORS UN EXPIRY (MMYY)
	--#
	--#===========================================================================================================================
	function GetCentreIdExpCrdNum_N(p_card_num in varchar2,
							p_centre_id out varchar2, p_expiry_date out varchar2) return number;
	--#===========================================================================================================================
	--#
	--#											KARTES NUMURS => OTB
	--#
	--#===========================================================================================================================
	function GetCardOtb_N(p_card_num in varchar2,
							p_centre_id out varchar2,
							p_otb out number,
							p_locked out number,
							p_ccy out varchar2,
							p_hot_status out varchar2,
							p_hot_status_msg out varchar2,
							p_hot_description out varchar2,
							p_iss_status out varchar2,
							p_iss_status_msg out varchar2,
							p_iss_description out varchar2,
							p_status out varchar2,
							p_status_msg out varchar2,
							p_account_type in varchar2 default NULL
							) return number;

	function GetCardOtbAdmin_N(p_card_num in varchar2, p_centre_id out varchar2,p_locked out number,
		p_lock_rtps out number, p_lock_cms out number, p_cleared out number,p_overdraft out number,
		p_bonus out number,p_otb out number, p_ccy out varchar2,
		p_hot_status out varchar2, p_hot_status_msg out varchar2, p_hot_description out varchar2,
		p_iss_status out varchar2, p_iss_status_msg out varchar2, p_iss_description out varchar2,
		p_usr_status out varchar2, p_usr_status_msg out varchar2, p_usr_description out varchar2,
		p_status out varchar2, p_status_msg out varchar2, p_account_type in varchar2 default NULL) return number;

	-- CIR-7403 added p_account_id, p_account_id_bank
	function GetCardOtbAdmin_N(p_card_num in varchar2, p_centre_id out varchar2,p_locked out number,
		p_lock_rtps out number, p_lock_cms out number, p_cleared out number,p_overdraft out number,
		p_bonus out number,p_otb out number, p_ccy out varchar2,
		p_hot_status out varchar2, p_hot_status_msg out varchar2, p_hot_description out varchar2,
		p_iss_status out varchar2, p_iss_status_msg out varchar2, p_iss_description out varchar2,
		p_usr_status out varchar2, p_usr_status_msg out varchar2, p_usr_description out varchar2,
		p_status out varchar2, p_status_msg out varchar2, p_account_id out varchar2, p_account_id_bank out varchar2, p_account_type in varchar2 default NULL) return number;

	--#============================================================================
	--# Atgriezz kartes un RTPS stopsaraksta informaciju peec kartes numura.
	--#============================================================================
	function GetCardInfoExt_N(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_cardinfo out t_cards_item,
							p_action_code out varchar2,
							p_description out varchar2) return number;
	--============================================================================
	-- Atgriezz klienta informaciju peec klienta id.
	--============================================================================
	function GetClientInfo_N(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_clientinfo out t_client_item) return number;
	function GetClientInfo2_N(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_clientinfo out t_client_item2) return number;

	--============================================================================
	-- Atgriezz konta informaciju peec konta id.
	--============================================================================
	function GetAccountInfo_N(p_centre_id in varchar2,
							p_account_id in varchar2,
							p_accountinfo out t_account_item) return number;
	--============================================================================
	-- Atgriezz kartes blokkeejossaas autorizaacijas peec kartes numura.
	--============================================================================
	function GetCrdLockingAuth_N(p_centre_id in varchar2,
							p_card in varchar2,
							p_starting_from in number,
							p_authlist out t_authlist,
							p_More OUT boolean) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura.
	--============================================================================
	function GetCrdAuth_N(p_centre_id in varchar2,
							p_card in varchar2,
							p_starting_from in date,
							p_last_row_numb in varchar2,
							p_l out t_auth_ext_list,
							p_more out boolean) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura.
	--============================================================================
	function GetCardAuthList_N(p_card_num in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura un konta tipa.
	--============================================================================
	function GetCardAuthListByAcType_N(p_card_num in out varchar2,p_acnt_type_from in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veesturi peec kartes numura un alfa valutas.
	--============================================================================
	function GetCardAuthListByCcyAlpha_N(p_card_num in out varchar2,p_ccy_alpha in out varchar2,
						p_auth_hist out t_Auth_Hist_List) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura.
	--============================================================================
	function GetCardAuthCurs_N(p_card_num in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura un konta tipa.
	--============================================================================
	function GetCardAuthCursByAcType_N(p_card_num in out varchar2,p_acnt_type_from in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return number;
	--============================================================================
	-- Atgriezz kartes autorizaaciju veestures kursoru peec kartes numura un alfa valutas.
	--============================================================================
	function GetCardAuthCursByCcyAlpha_N(p_card_num in out varchar2,p_ccy_alpha in out varchar2,
						p_auth_hist in out nocopy t_Auth_Hist_Curs) return number;
	--============================================================================
	-- Uzstaada kartes statusu peec kartes numura.
	--============================================================================
	function SetCardStatus_N(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_card_seq in number,
							p_cardstatus in char) return number;
	--============================================================================
	-- Kartes iznnemssana no stopsaraksta
	--============================================================================
	function RemoveCardFromStop_N(p_centre_id in varchar2,p_card_numb in varchar2) return number;
	--============================================================================
	-- Kartes ielikssana stopsarakstaa
	--============================================================================
	function AddCardToStop_N(p_centre_id in varchar2,
							p_card_numb in varchar2,
							p_action_code in varchar2,
							p_description in varchar2) return number;

	--============================================================================
	-- Kartes akumulaatoru resets
	--============================================================================
	function ResetCardAccum_N(
			p_centre_id in varchar2,
			p_card_numb in varchar2) return number;
	--============================================================================
	-- Konta INITIAL summas izmainna
	--============================================================================
	function SetAccInitialAmount_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_initialamount in number,
			p_relativeAmountChange in boolean default false,
			p_effective_date in date default null) return number;
	--============================================================================
	-- Konta BONUS summas izmainna
	--============================================================================
	function SetAccBonusAmount_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_bonusamount in number) return number;
	--==============================================================================
	-- Uzstaada konta valuutu (cipariskaa formaa)
	--==============================================================================
	function SetAccountCcy_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_ccy_num in varchar2) return number;
	--==============================================================================
	-- Uzstaada konta valuutu (alfacipariskaa formaa)
	--==============================================================================
	function SetAccountCcyAlpha_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_ccy_alpha in varchar2) return number;
	--============================================================================
	-- Blokkeejossaas autorizaacijas atblokkeessana
	--============================================================================
	function UnlockAuthAmount_N(
			p_centre_id in varchar2,
			p_authrownumb in number) return number;
	--============================================================================
	-- Paarbauda kartes CVC2
	--============================================================================
	function Verify_CVC2_N(p_centre_id in varchar2,
			p_card_numb in varchar2,
			p_expiry_date in varchar2,
			p_cvc2 in varchar2) return number;
	--========================================================================
	-- Seting card limits for calendar limits
	--========================================================================
	function SetCrdLimit_N(bank_c in	varchar2,
							groupc in varchar2,
							ctime in date,
							data_action in char,
							card_number in varchar2,
							limit_id in varchar2,
							limit_type in char,
							limit_ccy in char,
							period_type in char,
							amount in number,
							auth_count in number,
							amount_extra in number,
							count_extra in number,
							expiry_extra in date,
							answ_code_amount in char,
							answ_code_count in char) return number;
	--========================================================================
	-- Seting card group limits for calendar limits
	--========================================================================
	function SetCrdGrpLimit_N(bank_c in	varchar2,
							groupc in varchar2,
							ctime in date,
							data_action in char,
							param_grp in varchar2,
							limit_id in varchar2,
							limit_type in char,
							limit_ccy in char,
							period_type in char,
							amount in number,
							auth_count in number,
							amount_extra in number,
							count_extra in number,
							expiry_extra in date,
							answ_code_amount in char,
							answ_code_count in char) return number;

	 --============================================================================
	-- Kartes iznnemssana no user stopsaraksta
	--============================================================================
	function RemoveCardFromUserStop_N(
			p_centre_id in varchar2,
			p_card_numb in varchar2) return number;
	--============================================================================
	-- Kartes ielikssana user stopsarakstaa
	--============================================================================
	function AddCardToUserStop_N(
			p_centre_id in varchar2,
			p_card_numb in varchar2,
			p_action_code in varchar2,
			p_description in varchar2) return number;
	--============================================================================
	-- Konta LOCK_AMOUNT_CMS summas izmainna
	--============================================================================
	function SetAccLockCMSAmount_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_lock_amount_cms in number) return number;
	--------------------------------------------------------------------------------
	-- Change card carholder
	--------------------------------------------------------------------------------
	function ChangeCardClient_N(
		p_centre_id in varchar2,
		p_card_num in varchar2,
		p_crd_holdr_id in varchar2) return number;
	--------------------------------------------------------------------------------
	-- Bind account to card
	--------------------------------------------------------------------------------
	function CardAccountLinkage_N(
		p_centre_id in varchar2,
		p_crd_holdr_id in varchar2,
		p_card_num in varchar2,
		p_account_id in varchar2,
		p_account_type in varchar2) return number;
	--------------------------------------------------------------------------------
	-- Relink card and accounts
	--------------------------------------------------------------------------------
	function RelinkCardAndAccounts_N(p_centre_id in varchar2,
									p_crd_holdr_id in varchar2,
									p_card_num in varchar2,
									p_new_crd_holdr_id in varchar2,
									p_account_mapping in varchar2,
									p_mapping_type in varchar2) return number;

	--------------------------------------------------------------------------------
	--							GET BUSINESS DAY
	--------------------------------------------------------------------------------
	function GetBusinessDay_N(p_bank_id in varchar2,
							p_rtps_date out varchar2,
							p_bank_date out varchar2) return number;

	--------------------------------------------------------------------------------
	--							SET BUSINESS DAY
	--------------------------------------------------------------------------------
	function SetBusinessDay_N(p_bank_id in varchar2,
							p_rtps_date in varchar2,
							p_bank_date in varchar2) return number;

	--============================================================================
	-- Set Risk Group for client
	--============================================================================
	function SetClientParamGrp_N(p_centre_id in varchar2,
							p_crd_holdr_id in varchar2,
							p_param_grp in varchar2) return number;

	--============================================================================
	-- Set Risk Group for card
	--============================================================================
	function SetCardParamGrp_N(p_centre_id in varchar2,
							p_card_num in varchar2,
							p_param_grp in varchar2) return number;

	--============================================================================
	-- Set credit limit or overdraft for account
	--============================================================================
	function SetAccCreditLimit_N(
			p_centre_id in varchar2,
			p_account_id in varchar2,
			p_creditlimit in number,
			p_relativeAmountChange in boolean default false,
			p_initial_amount_adj in boolean default false,
			p_credit_limit_exp in date default null) return number;

	--============================================================================
	-- Update rtps currency conversion rates
	--============================================================================
	function UpdateRates_N(l_pay_ccy in varchar2, l_ccy_to in varchar2, l_bank in varchar2,
			l_buy_rate in number, l_mid_rate in number,
			l_sell_rate in number) return number;

	--============================================================================
	-- Update rtps card, client, account and client information for single card
	--============================================================================
	function ReceiveDataFromCms(p_centre_id in varchar2, p_card_number in varchar2) return boolean;


END;
/

