create view RA_ACQ_TRANSACTIONS as
SELECT batch_owner,
    reconcile_date,
    reconcile_cntr,
    update_date,
    authoriz_flag,
    authoriz_row,
    transact_row,
    reconcile_flag,
    process_flag,
    process_task,
    request_date,
    stan_internal,
    card_type,
    dev_type,
    msg_type_in,
    msg_type_out,
    msg_orig_in,
    msg_orig_out,
    fld_002,
    fld_003,
    fld_004,
    fld_005,
    fld_006,
    fld_009,
    fld_010,
    fld_011,
    fld_012,
    fld_014,
    fld_015,
    fld_016,
    fld_017,
    fld_019,
    fld_020,
    fld_021,
    fld_022,
    fld_023,
    fld_024,
    fld_025,
    fld_026,
    fld_030a,
    fld_030b,
    fld_031,
    fld_032,
    fld_033,
    fld_034,
    fld_035,
    fld_036,
    fld_037,
    fld_038,
    fld_039,
    fld_040,
    fld_041,
    fld_042,
    fld_043,
    fld_045,
    fld_046,
    fld_049,
    fld_050,
    fld_051,
    fld_055,
    fld_056a,
    fld_056b,
    fld_056c,
    fld_056d,
    fld_057,
    fld_058,
    fld_093,
    fld_094,
    fld_095,
    fld_098,
    fld_100,
    fld_101,
    fld_102,
    fld_103,
    fld_104,
    suspect_cause,
    ACQ_SCHG_AMT,
    ACQ_ORIG_AMT,
    ACQ_BANK,
    ISS_BANK,
    fld_122,
    fld_123,
    epi_48_42,
    orig_row_numb,
    fld_126,
    fld_127
FROM ACQ_TRANSACTION_LOG
order by request_date desc
/

comment on column RA_ACQ_TRANSACTIONS.BATCH_OWNER is 'Batch owner entity identifier'
/

comment on column RA_ACQ_TRANSACTIONS.RECONCILE_DATE is 'Batch reconciliation date'
/

comment on column RA_ACQ_TRANSACTIONS.RECONCILE_CNTR is 'Batch reconciliation counter for single reconciliation date'
/

comment on column RA_ACQ_TRANSACTIONS.UPDATE_DATE is 'Transaction information update date'
/

comment on column RA_ACQ_TRANSACTIONS.AUTHORIZ_FLAG is 'Authorization presence flag'
/

comment on column RA_ACQ_TRANSACTIONS.AUTHORIZ_ROW is 'Authorization information reference row number'
/

comment on column RA_ACQ_TRANSACTIONS.TRANSACT_ROW is 'Transaction information reference row number'
/

comment on column RA_ACQ_TRANSACTIONS.RECONCILE_FLAG is 'Reconciliation occurence flag'
/

comment on column RA_ACQ_TRANSACTIONS.PROCESS_FLAG is 'Processing occurence flag'
/

comment on column RA_ACQ_TRANSACTIONS.PROCESS_TASK is 'Transaction processing automated task history number'
/

comment on column RA_ACQ_TRANSACTIONS.REQUEST_DATE is 'Authorisations request date'
/

comment on column RA_ACQ_TRANSACTIONS.STAN_INTERNAL is 'Uniq Internal STAN'
/

comment on column RA_ACQ_TRANSACTIONS.CARD_TYPE is 'Card type'
/

comment on column RA_ACQ_TRANSACTIONS.DEV_TYPE is 'Device type - Pos, ATM, Unknown'
/

comment on column RA_ACQ_TRANSACTIONS.MSG_TYPE_IN is 'Request message type'
/

comment on column RA_ACQ_TRANSACTIONS.MSG_TYPE_OUT is 'Response message type'
/

comment on column RA_ACQ_TRANSACTIONS.MSG_ORIG_IN is 'Original message Request message type'
/

comment on column RA_ACQ_TRANSACTIONS.MSG_ORIG_OUT is 'Original message Response message type'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_002 is 'Primary account number'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_003 is 'Transaction type'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_004 is 'Transaction amount'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_005 is 'Reconciliation amount'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_006 is 'Cardholder billing amount'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_009 is 'Reconciliation conversion rate'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_010 is 'Billing conversion rate'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_011 is 'Systems trace audit number'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_012 is 'Transaction date and time'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_014 is 'Card expiration date'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_015 is 'Settlement date'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_016 is 'Conversion date and time'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_017 is 'Date, Capture'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_019 is 'Acquiring institution country code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_020 is 'PAN country code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_021 is 'Forwarding institution country code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_022 is 'Point of service data code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_023 is 'Card sequence number'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_024 is 'Message function code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_025 is 'Message reason code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_026 is 'Card acceptor business code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_030A is 'Original amount, transaction '
/

comment on column RA_ACQ_TRANSACTIONS.FLD_030B is 'Original amount, reconciliation'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_031 is 'Acquirer reference data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_032 is 'Acquirer institution identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_033 is 'Forwarding institution identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_034 is 'Extended primary account number'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_035 is 'Track 2 data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_036 is 'Track 3 data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_037 is 'Retrieval reference number'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_038 is 'Approval identification code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_039 is 'Response action code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_040 is 'Card service code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_041 is 'Card acceptor terminal identification'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_042 is 'Card acceptor identification code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_043 is 'Card acceptor name and location'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_045 is 'Track 1 data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_046 is 'Amounts, Fees'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_049 is 'Transaction currency'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_050 is 'Reconciliation currency'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_051 is 'Cardholder billing currency'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_055 is 'Integrated Circuit Card System Related Data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_056A is 'Original MTI'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_056B is 'Original STAN(fld_011)'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_056C is 'Original Date and time(fld_012)'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_056D is 'Original Acquiring institution code(fld_032)'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_057 is 'Authorization Life Cycle Code'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_058 is 'Authorizing agent identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_093 is 'Destination institution identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_094 is 'Originator institution identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_095 is 'Card issuer reference data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_098 is 'Payee'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_100 is 'Receiving institution identifier'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_101 is 'File Name'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_102 is '"FROM" account identification'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_103 is '"TO" account identification'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_104 is 'Transaction description'
/

comment on column RA_ACQ_TRANSACTIONS.SUSPECT_CAUSE is 'Transaction suspection cause'
/

comment on column RA_ACQ_TRANSACTIONS.ACQ_SCHG_AMT is 'ACQ Surcharge fee amount'
/

comment on column RA_ACQ_TRANSACTIONS.ACQ_ORIG_AMT is 'Original FLD_004 before applying ACQ Surcharge'
/

comment on column RA_ACQ_TRANSACTIONS.ACQ_BANK is 'Acquirer'' bank'
/

comment on column RA_ACQ_TRANSACTIONS.ISS_BANK is 'Issuer''s bank'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_122 is 'ACQ Additional Data Transport'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_123 is 'CVC2 data'
/

comment on column RA_ACQ_TRANSACTIONS.EPI_48_42 is 'Electronic Commerce Security Level Indicator/UCAF Status'
/

comment on column RA_ACQ_TRANSACTIONS.ORIG_ROW_NUMB is 'ROW NUMB for Original'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_126 is 'Acquirer Request Additional Data'
/

comment on column RA_ACQ_TRANSACTIONS.FLD_127 is 'Issuer Response Additional Data  contin'
/

