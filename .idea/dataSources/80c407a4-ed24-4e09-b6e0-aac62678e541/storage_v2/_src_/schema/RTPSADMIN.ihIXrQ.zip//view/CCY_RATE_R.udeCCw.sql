create view CCY_RATE_R as
select
	r.pay_ccy,
	r.ccy_num,
	r.bank,
	r.ccy_rate_buy,
	r.ccy_rate_buy_min,
	r.ccy_rate_mid,
	r.ccy_rate_mid_min,
	r.ccy_rate_sell,
	r.ccy_rate_sell_min
from
	rtps_ccy_rates r
with check option
/

