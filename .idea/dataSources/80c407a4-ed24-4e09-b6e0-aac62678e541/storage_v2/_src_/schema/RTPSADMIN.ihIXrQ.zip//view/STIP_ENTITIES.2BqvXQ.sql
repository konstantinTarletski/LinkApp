create view STIP_ENTITIES as
select
		p.centre_id,
		p.authdat_alg_nr,
		p.prevalid_flag,
		p.advice_flag,
		substr(p.authdat_path,instr(p.authdat_path,'=',instr(p.authdat_path,'BANK_C'))+1,instr(p.authdat_path,';',instr(p.authdat_path,'BANK_C')+1)-instr(p.authdat_path,'=',instr(p.authdat_path,'BANK_C'))-1) bank_c,
		substr(p.authdat_path,instr(p.authdat_path,'=',instr(p.authdat_path,'GROUPC'))+1,instr(p.authdat_path,';',instr(p.authdat_path,'GROUPC')+1)-instr(p.authdat_path,'=',instr(p.authdat_path,'GROUPC'))-1) groupc,
		substr(p.authdat_path,instr(p.authdat_path,'=',instr(p.authdat_path,'EXP_URL'))+1,instr(p.authdat_path,';',instr(p.authdat_path,'EXP_URL')+1)-instr(p.authdat_path,'=',instr(p.authdat_path,'EXP_URL'))-1) exp_url,
		substr(p.authdat_path,instr(p.authdat_path,'=',instr(p.authdat_path,'IMP_URL'))+1,instr(p.authdat_path,';',instr(p.authdat_path,'IMP_URL')+1)-instr(p.authdat_path,'=',instr(p.authdat_path,'IMP_URL'))-1) imp_url,
		p.params_type
	from
	    processing_entities p
	where p.stip_flag='T' and
		p.authdat_alg_nr in (8,9,10) and
		exists
			(select null from centre_users u
				where u.centre_id = p.centre_id and
					username = user)
with check option
/

comment on table STIP_ENTITIES is 'STIP entities'
/

comment on column STIP_ENTITIES.CENTRE_ID is 'Center ID'
/

comment on column STIP_ENTITIES.AUTHDAT_ALG_NR is 'Central issuer authorization data files import/export algorithm number'
/

comment on column STIP_ENTITIES.PREVALID_FLAG is 'Request prevalidation enable flag'
/

comment on column STIP_ENTITIES.ADVICE_FLAG is 'Advice message generation necessity flag'
/

comment on column STIP_ENTITIES.BANK_C is 'Bank code (from ISSUING)'
/

comment on column STIP_ENTITIES.GROUPC is 'Group code (from ISSUING)'
/

comment on column STIP_ENTITIES.EXP_URL is 'Issuer authorization data export resource locator'
/

comment on column STIP_ENTITIES.IMP_URL is 'Issuer authorization data import resource locator'
/

comment on column STIP_ENTITIES.PARAMS_TYPE is 'Parametric restriction algorithm'
/

