create view STIP_CHIP_CMD_SET_R as
select
		a.effective_date,
		a.update_date,
		a.purge_date,
		a.bank,
		a.app_id,
		a.cla,
		a.ins,
		a.p1,
		a.p2,
		a.description,
		a.rec_id,
		a.step_count,
		a.deleted
	from
		stip_chip_cmd_set a
	where
		exists (select null
					from
						centre_users cu,
						processing_entities pe
					where
						pe.iss_bank=a.bank and
						cu.centre_id=pe.centre_id and
						cu.username = user)
	with check option
/

comment on column STIP_CHIP_CMD_SET_R.EFFECTIVE_DATE is 'Effective date'
/

comment on column STIP_CHIP_CMD_SET_R.UPDATE_DATE is 'Last update date'
/

comment on column STIP_CHIP_CMD_SET_R.PURGE_DATE is 'Purge date'
/

comment on column STIP_CHIP_CMD_SET_R.BANK is 'Issuer bank code'
/

comment on column STIP_CHIP_CMD_SET_R.APP_ID is 'Chip application identifier'
/

comment on column STIP_CHIP_CMD_SET_R.CLA is 'Script command class'
/

comment on column STIP_CHIP_CMD_SET_R.INS is 'Script command instruction'
/

comment on column STIP_CHIP_CMD_SET_R.P1 is 'Script command Parametr 1'
/

comment on column STIP_CHIP_CMD_SET_R.P2 is 'Script command Parametr 2'
/

comment on column STIP_CHIP_CMD_SET_R.DESCRIPTION is 'Chip application command description'
/

