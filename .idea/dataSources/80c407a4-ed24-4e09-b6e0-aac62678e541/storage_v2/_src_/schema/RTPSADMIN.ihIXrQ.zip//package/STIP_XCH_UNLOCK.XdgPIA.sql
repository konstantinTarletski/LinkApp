create PACKAGE
/* $HeadURL$ $Id$ */
STIP_XCH_UNLOCK IS
--==============================================================================
--		RTPS.IIA.XCH
--			Unlocking with transaction
--
-- $HeadURL$ $Id$
-- (C) Tieto Konts Financial Systems Ltd. 1998-2002
--==============================================================================
	FUNCTION amount_unlock (
		p_hist_numb INTEGER DEFAULT NULL,
		p_centre_id VARCHAR2 DEFAULT NULL,
		p_effective_date DATE DEFAULT NULL,
		p_use_local_acnt_table boolean default false
	) RETURN BOOLEAN;
	--=============================================================================
	-- Parsledz uz centra specifisku log failu, vai otradi, ja ir tukss p_centre_id
	--=============================================================================
	procedure SwitchLog(p_centre_id varchar2);

END;
--==============================================================================
-- $Log: stip_xch_unlock-package.sql,v $
-- Revision 1.14  2005/12/01 16:01:26  kovacs
-- - Pielikts ka kontu atlikumus var paarbaudiit lokaalaa tabulaa
--
-- Revision 1.13  2005/06/22 08:01:23  karlisl
-- bug #8527 effective date
--
-- Revision 1.12  2002/12/17 10:51:32  vilis
-- Some formatting issues
--
-- Revision 1.11  2002/12/16 17:25:25  vilis
-- Removed duplicated error codes from logs
--
-- Revision 1.9  2002/10/31 15:26:11  uldis
-- Netiek lietots REVISIO N buferis
--
-- Revision 1.8  2002/09/17 13:23:07  karlis
-- SPEC un BODY dallaas DEFAULT parametru veertiibaam jaasakriit, preteejaa
-- gadiijumaa nekompileejas uz HPUX 11 ar Oracle 8. (MKS probleema instaleejot
-- oktobra '02 versiju)
--
-- Revision 1.7  2001/12/27 13:55:08  karlis
-- Saakta atblokkeessanas paarveide, lai atsekotu gadiijumus, kad kaa
-- tranzakcija naak dalleejais reversaalis.
--==============================================================================
/

