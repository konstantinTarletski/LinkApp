create view STIP_FARE_CONFIG_R as
select
	c.centre_id,
	c.pref_rec_num,
	c.stat_func_name,
	c.limit_name
from
    stip_fare_config c
where exists
	(select null
		from
			centre_users u,
			stip_entities_all e
		where
			u.centre_id=e.centre_id and
			u.username=user)
	with check option
/

comment on table STIP_FARE_CONFIG_R is 'Stip Fare limits configuration interface for GUI'
/

