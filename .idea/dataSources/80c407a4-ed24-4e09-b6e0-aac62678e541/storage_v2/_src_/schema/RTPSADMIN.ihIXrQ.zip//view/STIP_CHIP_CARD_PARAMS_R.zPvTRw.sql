create view STIP_CHIP_CARD_PARAMS_R as
select
		x.centre_id,
		x.card_number,
		x.expiry_date,
		x.card_seq,
		x.cmd_count,
		x.update_date,
		x.lower_offline_limit,
		x.upper_offline_limit,
		x.lower_offline_limit_chg,
		x.upper_offline_limit_chg,
		x.rec_id,
		x.step_count,
		x.deleted,
		x.app_id,
		x.app_numb
	from STIP_CHIP_CARD_PARAMS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

