create view STIP_CHIP_APP_R as
select
		a.effective_date,
		a.update_date,
		a.purge_date,
		a.bank,
		a.app_id,
		a.mac_length,
		a.description,
		a.script_counter_mode
	from
		stip_chip_app a
	where
		exists (select null
					from
						centre_users cu,
						processing_entities pe
					where
						pe.iss_bank=a.bank and
						cu.centre_id=pe.centre_id and
						cu.username = user)
	with check option
/

comment on column STIP_CHIP_APP_R.EFFECTIVE_DATE is 'Effective date'
/

comment on column STIP_CHIP_APP_R.UPDATE_DATE is 'Last update date'
/

comment on column STIP_CHIP_APP_R.PURGE_DATE is 'Purge date'
/

comment on column STIP_CHIP_APP_R.BANK is 'Issuer bank code'
/

comment on column STIP_CHIP_APP_R.APP_ID is 'Chip application identifier'
/

comment on column STIP_CHIP_APP_R.MAC_LENGTH is 'Length of MAC for chip command. 4 - 8 bytes'
/

comment on column STIP_CHIP_APP_R.DESCRIPTION is 'Chip application description'
/

comment on column STIP_CHIP_APP_R.SCRIPT_COUNTER_MODE is 'Chip script counter mode'
/

