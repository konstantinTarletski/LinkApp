create PACKAGE
/* $HeadURL$ $Id$ */
ACQ_ATM_POS_REPORT IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/

	procedure atm_pos_report (
		ReportType number default 1,
		DateFrom date default sysdate-1,
		DateTo date default sysdate,
		BatchOwnerID varchar2 default '%',
		SuspendedBatches_Included number default 1);

	procedure show_text_report (OutputType number default 1);

END;

/*= History =============================================================
 * $Log: acq_atm_pos_report-package.sql,v $
 * Revision 1.7  2004/03/24 16:39:34  santa
 * Parameter OutputType moved from procedure atm_pos_report() to procedure
 * show_text_report(), because it is related to text report only.
 *
 * Revision 1.6  2004/02/17 15:55:43  santa
 * Parameter name fixed in package definition.
 *
 * Revision 1.5  2004/02/09 13:12:57  santa
 * Fixes to bug 3021.
 *
 * RTPS WP must call functions "acq_atm_pos_report.show_text_report()" and "batches_history.batches_hist_txt_complex()" with parameter
 * OutputType => 2 to take an effect on text report output style. In such case text report will be stored in the REPORTS table:
 * - Report_ID='RTPSWP.ATM_POS_REP_T' for atm/pos report;
 * - Report_ID='RTPSWP.B_HIST_TXT' for batches history report;
 * - Data_type='text_report_row' for both reports.
 *
 * By default text report output will be stored in dbms_output buffer as till now.
 *
 * Revision 1.4  2004/01/19 21:12:08  santa
 * ACQ_ATM_POS_REPORT - report data select statements changed; also new column in text report added.
 *
 * Revision 1.3  2004/01/12 19:54:44  santa
 * Full acq-bank name will be used in ATM/POS report instead of bank code.
 * Also some cosmetic changes in header EXIT
 *
 *
 ========================================================================*/
/

