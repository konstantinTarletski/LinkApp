create package
/* $HeadURL$ $Id$ */
stip_recalc_tuxedo_long is
/*#===================================================================================================
--#	RTPS.IIA.RECALC
--#		MCC bazeeto parametrisko paarbaudes akumulaatoru paarreekkins
--#
--#		Janis Kovalevskis
--#		Karlis Ogsts
--#
--#	$HeadURL$ $Id$
--#	(C) Tieto Konts Financial Systems Ltd. 1998-2002
--#===================================================================================================*/
-- LONG PERIODA PAARREEKKINS TUXEDO BASED
-----------------------------------
function Recalc_tuxedo_long(p_centre_id varchar2, p_hist_numb integer) return boolean;
/*
--#= History =============================================================
--# $Log: stip_recalc_tuxedo_long-package.sql,v $
--# Revision 1.9  2002/12/17 10:47:02  vilis
--# Fixed duplicated errorcodes
--#
--# Revision 1.5  2002/10/31 15:26:09  uldis
--# Netiek lietots REVISIO N buferis
--#
--# Revision 1.4  2002/01/23 12:51:56  karlis
--# Labojumi peec CODE REVIEW.
--#
--# Revision 1.3  2002/01/22 16:02:01  karlis
--# Paarveidots TUXEDO baazeeto LONG limitu paarreekkins, lai tiktu lietotas
--# PL/SQL tabulas.
--#
--#=======================================================================
*/
end;
/

