create view STIP_COMM_GRP_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.comm_grp,
		x.comm_ccy,
		x.abbreviature,
		x.description
	from STIP_COMM_GRP x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

