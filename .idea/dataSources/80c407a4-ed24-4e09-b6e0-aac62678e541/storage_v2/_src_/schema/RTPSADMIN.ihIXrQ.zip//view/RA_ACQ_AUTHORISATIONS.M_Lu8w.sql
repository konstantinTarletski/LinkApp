create view RA_ACQ_AUTHORISATIONS as
SELECT row_numb,
    request_date,
    batch_owner,
    reconcile_date,
    reconcile_cntr,
    card_type,
    dev_type,
    msg_type_in,
    msg_type_out,
    msg_orig_in,
    msg_orig_out,
    fld_002,
    fld_003,
    fld_004,
    fld_006,
    fld_007,
    fld_010,
    fld_011,
    fld_012,
    fld_014,
    fld_015,
    fld_022,
    fld_023,
    fld_024,
    fld_025,
    fld_026,
    fld_030a,
    fld_030b,
    fld_032,
    fld_033,
    fld_035,
    fld_037,
    fld_038,
    fld_039,
    fld_040,
    fld_041,
    fld_042,
    fld_043,
    fld_045,
    fld_049,
    fld_051,
    fld_055,
    fld_056a,
    fld_056b,
    fld_056c,
    fld_056d,
    fld_093,
    fld_094,
    fld_095,
    fld_098,
    fld_100,
    fld_102,
    fld_103,
    fld_104,
    fld_122,
    FLD_123,
    EPI_48_42,
    reconcile_flag,
    ACQ_SCHG_AMT,
    ACQ_ORIG_AMT,
    ACQ_BANK,
    ISS_BANK,
    ORIG_ROW_NUMB,
    fld_126,
    fld_127
FROM ACQ_AUTHORISATION_LOG
order by request_date desc
/

comment on column RA_ACQ_AUTHORISATIONS.ROW_NUMB is 'Oracle uniq ROW NUMB'
/

comment on column RA_ACQ_AUTHORISATIONS.REQUEST_DATE is 'Authorisations request date'
/

comment on column RA_ACQ_AUTHORISATIONS.BATCH_OWNER is 'Batch owner entity (centre, merchant or terminal) identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.RECONCILE_DATE is 'Batch reconciliation date'
/

comment on column RA_ACQ_AUTHORISATIONS.RECONCILE_CNTR is 'Batch reconciliation counter within single date'
/

comment on column RA_ACQ_AUTHORISATIONS.CARD_TYPE is 'Card type'
/

comment on column RA_ACQ_AUTHORISATIONS.DEV_TYPE is 'Device type - Pos, ATM, Unknown'
/

comment on column RA_ACQ_AUTHORISATIONS.MSG_TYPE_IN is 'Request message type'
/

comment on column RA_ACQ_AUTHORISATIONS.MSG_TYPE_OUT is 'Response message type'
/

comment on column RA_ACQ_AUTHORISATIONS.MSG_ORIG_IN is 'Original message Request message type'
/

comment on column RA_ACQ_AUTHORISATIONS.MSG_ORIG_OUT is 'Original message Response message type'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_002 is 'Primary account number'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_003 is 'Transaction type'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_004 is 'Transaction amount'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_006 is 'Cardholder billing amount'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_007 is 'Transmission date and time'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_010 is 'Billing conversion rate'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_011 is 'Systems trace audit number'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_012 is 'Transaction date and time'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_014 is 'Card expiration date'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_015 is 'Settlement date'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_022 is 'Point of service data code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_023 is 'Card sequence number'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_024 is 'Message function code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_025 is 'Message Reason Code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_026 is 'Card acceptor business code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_030A is 'Original amount, transaction '
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_030B is 'Original amount, reconciliation'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_032 is 'Acquirer institution identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_033 is 'Forwarding institution identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_035 is 'Track 2 data'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_037 is 'Retrieval reference number'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_038 is 'Approval Code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_039 is 'Response action code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_040 is 'Card service code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_041 is 'Card acceptor terminal identification'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_042 is 'Card acceptor identification code'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_043 is 'Card acceptor name and location'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_045 is 'Track 1 data'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_049 is 'Transaction currency'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_051 is 'Cardholder billing currency'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_055 is 'Integrated Circuit Card System Related Data'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_056A is 'Original MTI'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_056B is 'Original STAN(fld_011)'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_056C is 'Original Date and time(fld_012)'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_056D is 'Original Acquiring institution code(fld_032)'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_093 is 'Destination institution identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_094 is 'Originator institution identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_095 is 'Card issuer reference data'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_098 is 'Payee'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_100 is 'Receiving institution identifier'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_102 is '"FROM" account identification'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_103 is '"TO" account identification'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_104 is 'Transaction description'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_122 is 'ACQ Additional Data Transport'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_123 is 'CVC2 data'
/

comment on column RA_ACQ_AUTHORISATIONS.EPI_48_42 is 'Electronic Commerce Security Level Indicator/UCAF Status'
/

comment on column RA_ACQ_AUTHORISATIONS.RECONCILE_FLAG is 'Reconciliation occurence flag'
/

comment on column RA_ACQ_AUTHORISATIONS.ACQ_SCHG_AMT is 'ACQ Surcharge fee amount'
/

comment on column RA_ACQ_AUTHORISATIONS.ACQ_ORIG_AMT is 'Original FLD_004 before applying ACQ Surcharge'
/

comment on column RA_ACQ_AUTHORISATIONS.ACQ_BANK is 'Acquirer'' bank'
/

comment on column RA_ACQ_AUTHORISATIONS.ISS_BANK is 'Issuer''s bank'
/

comment on column RA_ACQ_AUTHORISATIONS.ORIG_ROW_NUMB is 'ROW NUMB for Original'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_126 is 'Acquirer Request Additional Data'
/

comment on column RA_ACQ_AUTHORISATIONS.FLD_127 is 'Issuer Response Additional Data  contin'
/

