create PACKAGE MENU_AUTH IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	CURRENT_MENU  VARCHAR2(1000); -- viens MENU_NAME ir liidz 50 simboliem
	CURRENT_APP  VARCHAR2(50);
	PAN_MASK  BOOLEAN;
	AUDIT_TRAIL  BOOLEAN;
	ROOT_MENU      VARCHAR(60);
    menu_short varchar2(100);
    menu_cap varchar2(100);
        CURRENT_MODULE  VARCHAR2(64);
        CURRENT_OWNER   VARCHAR2(30);
        CURRENT_USER   VARCHAR2(30);

	PROCEDURE DROP_CONTEXT;
	PROCEDURE SET_CONTEXT ( MENU_NAME IN VARCHAR2);
	procedure SET_CONTEXT_E ( MENU_NAME IN VARCHAR2);
	PROCEDURE REMOVE_CONTEXT ( MENU_NAME IN VARCHAR2);
	FUNCTION ACC ( OBJ_NAME IN VARCHAR2, OBJ_PRIVILEGE IN CHAR) RETURN CHAR;
	function MASK_PAN ( PAN IN VARCHAR2) return VARCHAR2;
	function MASK_PAN_DATA ( DATA IN VARCHAR2, PAN IN VARCHAR2) return VARCHAR2;
	TYPE MENU_OBJ_ACC_TYPE IS RECORD (
      object_name	menu_objects.object_name%TYPE,
      privilege  menu_obj_priv.privilege%TYPE);
	TYPE MENU_OBJ_ACC_TABLE IS TABLE OF MENU_OBJ_ACC_TYPE INDEX BY BINARY_INTEGER;
	MENU_OBJ_ACC	MENU_OBJ_ACC_TABLE;
	procedure print;
	pragma restrict_references (ACC, WNDS,WNPS);
	procedure Trigger_acc (object_name varchar2,operation varchar2);
	pragma restrict_references (Trigger_acc, WNDS,WNPS);
END;/*= History =============================================================
 * $Log: menu_auth-package.sql,v $
 * Revision 1.5  2002/10/31 15:25:56  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.4  2000/10/02 08:37:56  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.3  2000/09/27 08:53:33  uldis
 * Menu trigeru 'kerme'ni p'arnesti uz pakotni.
 *
 * Revision 1.2  1999/11/03 19:31:16  uldis
 * P'artais'its ar cache lieto'sanu
 *
 ========================================================================*/
/

