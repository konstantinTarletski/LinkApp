create view UNPROC_DETALISATIONS as
select
      t.BATCH_OWNER
      ,t.RECONCILE_DATE
      ,t.RECONCILE_CNTR
      ,t.TRANSACT_ROW
      ,m.row_numb
      ,m.request_date
      ,m.msg_type_in
      ,m.fld_002
      ,m.fld_003
      ,m.fld_004
      ,m.FLD_006
      ,m.fld_011
      ,m.fld_014
      ,m.fld_022
      ,m.fld_024
      ,m.fld_025
      ,m.fld_033
      ,m.fld_037
      ,m.fld_038
      ,m.FLD_039
      ,m.fld_041
      ,m.fld_042
      ,m.fld_049
      ,m.FLD_051
      ,m.FLD_071
      ,m.FLD_072
      ,m.FLD_093
      ,m.FLD_094
      ,m.FLD_100
 from
 	acq_transaction_log t
	,acq_details_log m
 where
 	m.transact_row=t.transact_row and
	t.process_flag='F'
/

