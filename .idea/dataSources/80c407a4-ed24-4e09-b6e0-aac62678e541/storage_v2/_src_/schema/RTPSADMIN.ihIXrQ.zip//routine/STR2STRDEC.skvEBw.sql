create Function /* $HeadURL$ $Id$ */
STR2STRDEC ( str IN varchar2) RETURN varchar IS
	tmp	varchar2(6000);-- darba buferis, kura sintiz?sies konversijas rezultats
	i	binary_integer;-- ciklu iterators
	l	binary_integer;-- virknes garums
	c	binary_integer;-- konvert?jamais simbols
BEGIN
	tmp:=replace(str,'\','\092'); -- rinda tiek pie?kirta darba buferim
 -- ta, ka simbolu konversijas laika rodas simbols '\',
	l:=length(tmp);
	i:=1;
	while i<=l loop
		c:=ascii(substr(tmp,i,1));
		if c<0 then	-- NPC charset bug, ascii may return negative value
			c:=256+c;
		end if;
		if c<32 or c>126 or c=34 or c=38 or c=39 then -- chr(34)=" , chr(38)=&, chr(39)='
			tmp:=replace(tmp,chr(c),'\'||to_char(c,'FM000'));
			i:=i+4;
			l:=l+3;
		else
			i:=i+1;
		end if;
	end loop;
    RETURN tmp;
END;
/

