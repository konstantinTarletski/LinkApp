create view R_CASHIN_TOTALS as
SELECT a.terminal_group_id AS term_group,
       a.terminal_id AS term_id,
       (SELECT c.param_value FROM atm_parameters c WHERE c.terminal_id = a.terminal_id AND c.param_name='TERMINAL_CITY') AS term_city,
       (SELECT c.param_value FROM atm_parameters c WHERE c.terminal_id = a.terminal_id AND c.param_name='TERMINAL_STREET') AS term_str,
       d.curr_alpha AS curr_alpha,
       d.curr_exp_dot AS curr_exp,
       b.audit_date AS device_audit,
       sum(CASE WHEN b.reason = 'F' THEN b.amount ELSE 0 END) AS acc_amnt,
       sum(CASE WHEN b.reason = 'K' THEN b.amount ELSE 0 END) AS timed_amnt,
       sum(CASE WHEN b.reason = 'I' OR b.reason = 'J' THEN b.amount ELSE 0 END) AS unc_amnt
    FROM atm_terminal_group_members a,
        r_cashin_deposit b,
         ccy_codes d
    WHERE a.terminal_id = b.terminal_name
          AND d.curr_alpha = b.curr_alpha
    GROUP BY
       a.terminal_group_id,
       a.terminal_id,
       d.curr_alpha,
       d.curr_exp_dot,
       b.audit_date
    ORDER BY
       a.terminal_group_id,
       a.terminal_id,
       d.curr_alpha,
       b.audit_date
/

