create view STIP_UNL_WEIGHTS_CFG_R as
select
		x.centre_id,
		x.weight_id,
		x.weight_value
	from STIP_UNL_WEIGHTS_CFG x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

