create view STIP_IMPORT_R as
select
     stip_imp.hist_numb
    ,stip_imp.centre_id
    ,stip_imp.effective_date
    ,tabl_name.abbreviature
    ,stip_imp.full_flag
    ,stip_imp.rows_dat_del
    ,stip_imp.rows_rej_del
    ,stip_imp.rows_ign_del
    ,stip_imp.rows_dat_upd
    ,stip_imp.rows_rej_upd
    ,stip_imp.rows_ign_upd
    ,stip_imp.rows_dat_ins
    ,stip_imp.rows_rej_ins
    ,stip_imp.rows_ign_ins
from
    stip_import  stip_imp,
    table_names  tabl_name
 where stip_imp.table_name = tabl_name.table_name and
 exists (select null from centre_users where
 centre_id = stip_imp.centre_id and username = user)
 with check option
/

comment on column STIP_IMPORT_R.HIST_NUMB is 'Automated task history row number'
/

comment on column STIP_IMPORT_R.CENTRE_ID is 'Data owner processing entity identifier'
/

comment on column STIP_IMPORT_R.EFFECTIVE_DATE is 'File effective date and time'
/

comment on column STIP_IMPORT_R.TABLE_ABBREVIATURE is 'Name of table affected by import in current file processing'
/

comment on column STIP_IMPORT_R.FULL_FLAG is 'Full authorization data replacement (as opposite to partial) flag'
/

comment on column STIP_IMPORT_R.ROWS_DAT_DEL is 'Number of rows for current table to be deleted'
/

comment on column STIP_IMPORT_R.ROWS_REJ_DEL is 'Number of rows to be deleted rejected according to row data requirements'
/

comment on column STIP_IMPORT_R.ROWS_IGN_DEL is 'Number of rows to be deleted ignored as expired'
/

comment on column STIP_IMPORT_R.ROWS_DAT_UPD is 'Number of rows for current table to be updated'
/

comment on column STIP_IMPORT_R.ROWS_REJ_UPD is 'Number of rows to be updated rejected according to row data requirements'
/

comment on column STIP_IMPORT_R.ROWS_IGN_UPD is 'Number of rows to be updated ignored as expired'
/

comment on column STIP_IMPORT_R.ROWS_DAT_INS is 'Number of rows for current table to be inserted'
/

comment on column STIP_IMPORT_R.ROWS_REJ_INS is 'Number of rows to be inserted rejected according to row data requirements'
/

comment on column STIP_IMPORT_R.ROWS_IGN_INS is 'Number of rows to be inserted ignored as expired'
/

