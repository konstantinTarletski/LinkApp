create Package
/* $HeadURL$ $Id$ */
BIN_IMP_REPORT IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
--
-- To modify this template, edit file PKGBODY.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package body
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
  -- Enter procedure, function bodies as shown below
PROCEDURE report_reader (aaa in varchar2);
procedure txt_report;
  -- Enter further code below as specified in the Package spec.
END;
/*= History =============================================================
 * $Log: bin_imp_report-package.sql,v $
 * Revision 1.4  2002/10/31 15:24:13  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.3  2000/10/10 06:34:57  uldis
 * Pievienots REVISION buferis
 *
 * Revision 1.2  2000/10/02 08:38:09  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.1  2000/02/09 15:18:11  uldis
 * Pievienoti atskai'su faili
 *
 * Revision 1.2  2000/01/05 11:35:21  grin
 * Pirmaa gatavaa versija. Notesteeta.
 *
 * Revision 1.1  1999/11/05 20:10:05  uldis
 * Jauni modu'li
 *
 ========================================================================*/
/

