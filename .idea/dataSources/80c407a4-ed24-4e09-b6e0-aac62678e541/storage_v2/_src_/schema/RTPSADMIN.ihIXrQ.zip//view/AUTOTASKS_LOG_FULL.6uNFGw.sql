create view AUTOTASKS_LOG_FULL as
Select --+ rule
al.hist_numb,
        AL.TASK_NUMBER,
       AT.ABBREVIATURE TASK_ABBR,
       AL.ORACLE_USER,
       AL.MANUAL_START,
       AL.START_DATE,
       AL.END_DATE,
       AL.TASK_COMPLETE,
       AL.PROGR_TOTAL,
       AL.PROGR_SUBTASK,
       ER.LAST_MESSAGE,
       SUB.HEAD_SUBTASK
from AUTOTASKS_LOG AL,
     AUTOTASKS_TYPES AT,
     (select LOG.HIST_NUMB,
            substr(merge_error_msg('<<%message>>',
                    null,
                    null,
                    nvl(err_dict.msg_template,'<<arg>>'),
                    decode(err_dict.msg_template,null,replace(LOG.MSG_ARGUMENTS,'|','!'),LOG.MSG_ARGUMENTS),
                    decode(err_dict.msg_template,null,'arg',err_desc.error_arguments)
                    ),1,255) LAST_MESSAGE
      from AUTOTASKS_LOG LOG,
           Error_descriptions Err_desc,error_dictionary err_dict
          where LOG.PROGRAM_CODE=Err_Desc.PROGRAM_CODE(+) and
            LOG.MSG_CODE=Err_Desc.ERROR_CODE(+) and
            err_dict.program_code (+) =err_desc.program_code and
            err_dict.error_code (+) =err_desc.error_code and
            err_dict.msg_template_nr (+) = 0
                ) ER,
     (select LOG.HIST_NUMB,
    substr(merge_error_msg('<<%message>>',
                    null,
                    null,
                    nvl(err_dict.msg_template,'<<arg>>'),
                    decode(err_dict.msg_template,null,replace(LOG.HEAD_ARGUMENTS,'|','!'),LOG.HEAD_ARGUMENTS),
                    decode(err_dict.msg_template,null,'arg',err_desc.error_arguments)
                    ),1,255) HEAD_SUBTASK
      from AUTOTASKS_LOG LOG,
           Error_descriptions Err_desc,error_dictionary err_dict
      where LOG.PROGRAM_CODE=Err_Desc.PROGRAM_CODE(+) and
            LOG.HEAD_CODE=Err_Desc.ERROR_CODE(+) and
            err_dict.program_code(+)  =err_desc.program_code and
            err_dict.error_code (+) =err_desc.error_code and
            err_dict.msg_template_nr (+)= 0
            ) SUB
 where AL.HIST_NUMB=ER.HIST_NUMB
 and AL.HIST_NUMB=SUB.HIST_NUMB
 and AL.TASK_NUMBER=AT.TASK_NUMBER
/

