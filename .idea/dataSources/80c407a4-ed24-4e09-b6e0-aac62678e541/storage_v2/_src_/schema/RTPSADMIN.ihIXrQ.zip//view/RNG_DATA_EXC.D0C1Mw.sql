create view RNG_DATA_EXC as
SELECT
	state,
    CARD_TYPE,
    CENTRE_ID,
    EFFECTIVE_DATE,
--    UPDATE_DATE,
    PURGE_DATE,
    PREF_MIN,
    PREF_MAX,
--    PREF_DELTA,
    ACTION_CODE,
    DESCRIPTION
 FROM cards_data_exc where diap_flag='T'
/

