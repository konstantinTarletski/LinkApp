create Procedure
/* $HeadURL$ $Id$ */
CARD_PREFIX_QUEST (
		card_number in	varchar2,
		dev_type	in	char,
		centre_id	out	varchar2,
		card_type out char,
		error_code	out number,
		error_msg	out varchar2)
   IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
BEGIN
	centre_id:=null;
	card_type:=0;
	error_code:=SQLCODE;
	error_msg:=SQLERRM;
	begin
		-- Iznemuma kartas meklesana
                select /*+ index_desc(CARD_PREFIXES I_CARD_PREFIXES_MIN_MAX) */
			centre_id,card_type into CARD_PREFIX_QUEST.centre_id,CARD_PREFIX_QUEST.card_type
			FROM CARD_PREFIXES
			WHERE
				priority='X' AND
				RPAD(CARD_PREFIX_QUEST.card_number,19,'9') BETWEEN PREF_MIN AND RPAD(PREF_MAX,19,'9') AND
				((CARD_PREFIX_QUEST.dev_type='A' AND ATM_ENABLE='T') OR
				 (CARD_PREFIX_QUEST.dev_type='P' AND POS_ENABLE='T') OR
				 (CARD_PREFIX_QUEST.dev_type='N' AND IMP_ENABLE='T')) AND ROWNUM=1;
		return;
	exception
		when no_data_found then
			null;
		when others then
			raise;
	end;
	begin
                SELECT centre_id,card_type into CARD_PREFIX_QUEST.centre_id,CARD_PREFIX_QUEST.card_type
                FROM (
		select /*+ index_desc(CARD_PREFIXES I_CARD_PREFIXES_MIN_MAX) */
			centre_id,card_type
			FROM CARD_PREFIXES
			WHERE
				RPAD(CARD_PREFIX_QUEST.card_number,19,'9') BETWEEN PREF_MIN AND RPAD(PREF_MAX,19,'9') AND
				((CARD_PREFIX_QUEST.dev_type='A' AND ATM_ENABLE='T') OR
				 (CARD_PREFIX_QUEST.dev_type='P' AND POS_ENABLE='T') OR
				 (CARD_PREFIX_QUEST.dev_type='N' AND IMP_ENABLE='T'))
                        ORDER BY priority DESC
                     )
                WHERE ROWNUM=1;
		return;
	exception
		when no_data_found then
			null;
		when others then
			raise;
	end;
	raise no_data_found;
EXCEPTION
    WHEN others THEN
		centre_id:=null;
		card_type:=0;
		error_code:=SQLCODE;
		error_msg:=SQLERRM;
END;
/*= History =============================================================
 * $Log: card_prefix_quest-procedure.sql,v $
 * Revision 1.1.1.1  2003/01/29 17:09:09  haris
 * Imported
 *
 * Revision 1.6  2002/10/31 15:24:13  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.5  2002/03/07 10:51:30  uldis
 * Pievienoti Revision buferi.
 *
 ========================================================================*/
/

