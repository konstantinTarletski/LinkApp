create view STIP_CFG_PVALUES_UI as
select
	a.rule_id,
	a.cfg_parameter_name,
	a.cfg_parameter_value
from
	stip_cfg_pvalues a
/

comment on column STIP_CFG_PVALUES_UI.RULE_ID is 'Rule identification number'
/

comment on column STIP_CFG_PVALUES_UI.CFG_PARAMETER_NAME is 'Configuration parameter name'
/

comment on column STIP_CFG_PVALUES_UI.CFG_PARAMETER_VALUE is 'Configuration parameter value'
/

