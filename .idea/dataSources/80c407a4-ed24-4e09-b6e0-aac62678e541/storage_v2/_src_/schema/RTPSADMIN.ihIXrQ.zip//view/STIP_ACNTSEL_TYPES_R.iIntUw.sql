create view STIP_ACNTSEL_TYPES_R as
select
		x.acntsel_type,
		x.abreviature,
		x.description
	from STIP_ACNTSEL_TYPES x
/

