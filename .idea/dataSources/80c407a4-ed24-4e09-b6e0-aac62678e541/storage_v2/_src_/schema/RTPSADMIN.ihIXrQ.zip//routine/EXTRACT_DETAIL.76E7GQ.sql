create FUNCTION extract_detail(in_list VARCHAR2, in_det_name VARCHAR2) RETURN VARCHAR2
    IS
       start_pos NUMBER;
       end_pos NUMBER;
    BEGIN
       start_pos := INSTR(in_list, '' || in_det_name || '', 1, 1);
       IF start_pos = 0 THEN
           IF INSTR(in_list, in_det_name || '', 1, 1) != 1 THEN
               RETURN NULL;
           END IF;
           start_pos := length(in_det_name) + 2;
       ELSE
           start_pos := start_pos + length(in_det_name) + 3;
       END IF;
       end_pos := INSTR(in_list, '', start_pos, 1);
       IF end_pos = 0 THEN
           RETURN SUBSTR(in_list, start_pos);
       ELSE
           RETURN SUBSTR(in_list, start_pos, end_pos - start_pos);
       END IF;
    END;
/

