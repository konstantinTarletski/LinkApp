create view STIP_CHIP_CMD_QUEUE_R as
select
		x.centre_id,
		x.card_number,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.expiry_date,
		x.card_seq,
		x.cla,
		x.ins,
		x.p1,
		x.p2,
		x.data,
		x.cmd_id,
		x.template_type,
		x.source_id,
		x.priority,
		x.receive_date,
		x.mac_flag,
		x.enc_flag,
		x.retries_left,
		x.last_delivery_date,
		x.last_delivery_row,
		x.atc,
		x.script_seq_id,
		x.script_id,
		x.add_info,
		x.cmdid_auto,
		x.exclusive_cmd,
		x.rec_id,
		x.step_count,
		x.deleted,
		x.receive_tmst,
		x.cmd_type
	from STIP_CHIP_CMD_QUEUE x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

