create Procedure
/* $HeadURL$ $Id$*/
RUN_DBMS_JOB
   ( command IN varchar2)  IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	job	binary_integer;
begin
	sys.dbms_job.submit(job,command);
	sys.dbms_job.run( job);
end;
/*= History =============================================================
 * $Log: run_dbms_job-procedure.sql,v $
 * Revision 1.3  2002/10/31 15:25:54  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.2  2000/10/02 08:38:07  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.1  1999/07/20 16:23:01  uldis
 * Pievienots reakcijas izpild'it'ajs dbms_job, kur's palaiz uzdevumu.
 *
 *
 ========================================================================*/
/

