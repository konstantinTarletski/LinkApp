create PROCEDURE ebpp_access_control(ID IN NUMBER := 0)
IS
    mbiller_id   NUMBER := 0;
BEGIN
    /* Recurse for all childs first */
    FOR c IN (SELECT switching_id
                FROM ebpp_switching
               WHERE parent_id = ID)
    LOOP
        ebpp_access_control(c.switching_id);
    END LOOP;

    /* There is no switching entry for main root (0) */
    IF ID <> 0
    THEN
        SELECT biller_id
        INTO mbiller_id
        FROM ebpp_switching
        WHERE switching_id = ID;

    /* Cleanup existing AC config */
    DELETE FROM ebpp_ac_customers
          WHERE switching_id = ID;
    DELETE FROM ebpp_ac_channels
          WHERE switching_id = ID;
    DELETE FROM ebpp_ac_capabilities
          WHERE switching_id = ID;
    DELETE FROM ebpp_ac_netsw_rules
          WHERE switching_id = ID;

    /* Switching AC =
     * biller AC + all biller payinstr AC + all switching child AC (only if not exists child with empty AC)*/
    INSERT INTO ebpp_ac_customers(switching_id, card_type, centre_id)
        SELECT ID, c.card_type, c.centre_id
        FROM ebpp_ac_customers c
        WHERE c.biller_id = mbiller_id
        UNION
        SELECT ID, c.card_type, c.centre_id
        FROM ebpp_ac_customers c
        WHERE c.payinstr_id IN(SELECT payinstr_id
                               FROM ebpp_billers_payinstr
                               WHERE biller_id = mbiller_id)
        UNION
        SELECT ID, c.card_type, c.centre_id
        FROM ebpp_ac_customers c
        WHERE c.switching_id IN(SELECT b.switching_id
                                FROM ebpp_switching b
                                WHERE b.parent_id = ID)
        AND NOT EXISTS (SELECT b.switching_id
                        FROM ebpp_switching b
                        WHERE b.parent_id = ID
                        AND NOT EXISTS (SELECT NULL
                                        FROM ebpp_ac_customers a
                                        WHERE a.switching_id = b.switching_id));

    /* Switching AC =
     * biller AC + all biller payinstr AC + all switching child AC (only if not exists child with empty AC) */
    INSERT INTO ebpp_ac_channels(switching_id, domain, OBJECT)
        SELECT ID, c.domain, c.OBJECT
        FROM ebpp_ac_channels c
        WHERE c.biller_id = mbiller_id
        UNION
        SELECT ID, c.domain, c.OBJECT
        FROM ebpp_ac_channels c
        WHERE c.payinstr_id IN(SELECT payinstr_id
                               FROM ebpp_billers_payinstr
                               WHERE biller_id = mbiller_id)
        UNION
        SELECT ID, c.domain, c.OBJECT
        FROM ebpp_ac_channels c
        WHERE c.switching_id IN(SELECT b.switching_id
                                FROM ebpp_switching b
                                WHERE b.parent_id = ID)
        AND NOT EXISTS (SELECT b.switching_id
                        FROM ebpp_switching b
                        WHERE b.parent_id = ID
                        AND NOT EXISTS (SELECT NULL
                                        FROM ebpp_ac_channels a
                                        WHERE a.switching_id = b.switching_id));

    /* Switching AC =
     * biller AC + all biller payinstr AC + all switching child AC (only if not exists child with empty AC) */
    INSERT INTO ebpp_ac_capabilities
                (switching_id, cash_in, cash_out, printer, barcode, envelope)
        SELECT ID, c.cash_in, c.cash_out, c.printer, c.barcode, c.envelope
        FROM ebpp_ac_capabilities c
        WHERE c.biller_id = mbiller_id
        UNION
        SELECT ID, c.cash_in, c.cash_out, c.printer, c.barcode, c.envelope
        FROM ebpp_ac_capabilities c
        WHERE c.payinstr_id IN(SELECT payinstr_id
                               FROM ebpp_billers_payinstr
                               WHERE biller_id = mbiller_id)
        UNION
        SELECT ID, c.cash_in, c.cash_out, c.printer, c.barcode, c.envelope
        FROM ebpp_ac_capabilities c
        WHERE c.switching_id IN(SELECT b.switching_id
                                FROM ebpp_switching b
                                WHERE b.parent_id = ID)
        AND NOT EXISTS (SELECT b.switching_id
                        FROM ebpp_switching b
                        WHERE b.parent_id = ID
                        AND NOT EXISTS (SELECT NULL
                                        FROM ebpp_ac_capabilities a
                                        WHERE a.switching_id = b.switching_id));

    /* Switching AC =
     * biller AC + all biller payinstr AC */

    INSERT INTO ebpp_ac_netsw_rules(switching_id, netsw_rule_def)
        SELECT ID, c.netsw_rule_def
        FROM ebpp_ac_netsw_rules c
        WHERE c.biller_id = mbiller_id
        UNION
        SELECT ID, c.netsw_rule_def
        FROM ebpp_ac_netsw_rules c
        WHERE c.payinstr_id IN(SELECT payinstr_id
                               FROM ebpp_billers_payinstr
                               WHERE biller_id = mbiller_id);
    END IF;
END;
/

