create package
	/*$HeadURL$ $Id$*/
aqif_api is
--#==============================================================================
--#  RTPS.IIA.AQIF
--#
--# 	Oracle Advanced Queueing interface PL/SQL part
--#
--#  Copyright (C) 2003 TietoEnator Financial Solutions
--#==============================================================================
function enqueue (p_queue in varchar2,
					p_msg in out varchar2,
					p_msg_key out varchar2,
					p_expiry in number default null,
					p_priority in number default null) return boolean;

function enqueue (p_queue in varchar2,
					p_msg in out clob,
					p_msg_key out varchar2,
					p_expiry in number default null,
					p_priority in number default null) return boolean;

function dequeue (	p_queue in varchar2,
					p_msg in out varchar2,
					p_msg_key in varchar2,
					p_timeout in number ) return boolean;

function dequeue (	p_queue in varchar2,
					p_msg in out clob,
					p_msg_key in varchar2,
					p_timeout in number ) return boolean;

function unsentcount (p_queue in varchar2,
						p_msg_cnt out number ) return boolean;

procedure getlasterror (p_errortext_maxlen in number,
						p_errorcode out number,
						p_oraerrcode out number,
						p_errortext out varchar2 );
end;

--#==============================================================================
--# $Log: aqif_api-package.sql,v $
--# Revision 1.8  2003/08/15 07:55:28  karlis
--# Funkcijaam ENQUEUE pielikti jauni parametri EXPIRY un PRIORITY ar defaultaam
--# veertiibaam null.
--#
--# Revision 1.7  2003/05/13 11:11:26  vilis
--# Added p_queue parameter parsing to get schema name
--#
--# Revision 1.6  2003/05/12 09:16:28  vilis
--# Added parameter msg_key to Enqueue(), Dequeue();
--# Added parameter timeout to Dequeue().
--#
--# Revision 1.5  2003/05/08 17:12:35  vilis
--# AQIF_API.CALL() now are highly deprecated because in distributed transactions
--# environment autonomous transactions not allowed
--# (we used autonomous transactions that to commit enqueued message),
--# instead should be used Enqueue(), Dequeue() functions.
--#
--# Revision 1.4  2003/05/02 11:51:37  vilis
--# Created functions with varchar2 parameters instead of clob parameters
--# because lob parameters in remote calls is not permitted :((
--#
--# Revision 1.3  2003/04/22 17:23:58  vilis
--# Enqueue and Dequeue functions now are just wrappers
--# to L_Enqueue and L_Dequeue functions
--# so locally used additional parameters
--# can be easy added without changing external interface
--#
--# Revision 1.2  2003/04/11 17:11:52  vilis
--# Call(), EnQueue(), DeQueue() WIP ...
--#
--# Revision 1.1  2003/04/11 13:35:12  vilis
--# AQIF_API package added
--#
--#==============================================================================
/

