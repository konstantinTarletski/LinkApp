create PACKAGE
/* $HeadURL$ $Id$ */
RTPS_USER_MANAGEMENT IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
  FUNCTION RTPS_RECONCILE_USER(user_name IN VARCHAR2 )RETURN CHAR;
  -- RTPS user synonyms and roles reconciling procedure, Equivalent to RTPS_RECONCILE_USER
  PROCEDURE RECONCILE_USER(user_name IN VARCHAR2 );
  --  Exceptions:
  --    ORA-20000: User reconcialtion failed.
  PROCEDURE CHANGE_PASSWORD(new_password IN VARCHAR2,old_password IN VARCHAR2);
  --  Exceptions:
  --    ORA-20000: Password change failed.
  PROCEDURE ALTER_PASSWORD(username IN VARCHAR2,new_password IN VARCHAR2);
  --  Exceptions:
  --    ORA-20000: Password change failed.
  PROCEDURE ALTER_PROFILE(username IN VARCHAR2,new_profile IN VARCHAR2);
  --  Exceptions:
  --    ORA-20000: Profile change failed.
  PROCEDURE CREATE_USER(username IN VARCHAR2,password IN VARCHAR2);
  PROCEDURE CREATE_USER2(username IN VARCHAR2, password IN VARCHAR2, full_name IN VARCHAR2, profile_name IN VARCHAR2);
  PROCEDURE DROP_USER(username IN VARCHAR2);
  PROCEDURE SET_USER_STATE(username IN VARCHAR2, locked IN VARCHAR2);

END RTPS_USER_MANAGEMENT;
/*= History =============================================================
 * $Log: rtps_user_management-package.sql,v $
 * Revision 1.12  2006/01/20 09:36:52  aleks
 * Added new procedure for user creation (CREATE_USER2) with additional parameters FULL_NAME and PROFILE
 *
 * Revision 1.11  2006-01-13 13:48:13  aleks
 * Added new procedure ALTER_PROFILE
 * K05-1308 Changes in RTPS wp Access right management
 *
 * Revision 1.10  2003/01/28 13:02:30  uldis
 * Pievienota komentaara rindinja.
 *
 * Revision 1.9  2003/01/24 16:02:18  uldis
 * aaa
 *
 * Revision 1.8  2002/10/31 15:25:56  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.7  2000/10/02 08:38:11  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.6  1999/11/09 12:50:02  uldis
 * Nov'akts alter session
 *
 * Revision 1.4  1999/07/15 20:50:39  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/03/12 11:56:20  uldis
 * Projekta "Menu l'ime'na pieejas ties'ibu kontrole" ietvaros radusies arhi-
 * tekt'ura, kur'a objektu 'ipa'snieks ir ar'i RTPS_MENU_MEDIA. Proced'ura
 * RTPS_RECONCILE_USER piel'agota junajai athitekt'urai, tom'er ir saglab'ata
 * 100% savietojam'iba ar iepriek's'ejo.
 *
 * Revision 1.2  1999/01/22 17:40:20  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:10  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

