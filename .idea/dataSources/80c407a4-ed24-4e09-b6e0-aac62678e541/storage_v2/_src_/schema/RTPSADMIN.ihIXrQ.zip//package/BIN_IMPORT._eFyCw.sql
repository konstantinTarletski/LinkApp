create Package
/* $HeadURL$ $Id$ */
bin_import IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	VISA_CENTRE	varchar2(11):='VISA';
	VISA_CARD_TYPE	char(2):='50';

	VISA_ATM_CENTRE	varchar2(11):='VISA_ATM';
	VISA_OTHER_CENTRE	varchar2(11):='VISA_OTHER';
	VISA_ATM_CARD_TYPE	char(2):='51';
	VISA_OTHER_CARD_TYPE	char(2):='51';
	ECRD_CENTRE	varchar2(11):='ECRD';
	ECRD_CARD_TYPE	char(2):='01';
	EDCM_CENTRE	varchar2(11):='EDCM';
	EDCM_CARD_TYPE	char(2):='02';
	ECHA_CENTRE	varchar2(11):='ECHA';
	ECHA_CARD_TYPE	char(2):='03';
	PROCEDURE bin_import(hist_numb INTEGER);

	-- For fetching domestic records from RTPS_CONFIG.
	TYPE t_domestic_rec IS RECORD (
	     centre varchar2(128),
	     card_id varchar2(128)
	);
	TYPE t_domestic_set IS TABLE OF t_domestic_rec;
	FUNCTION get_domestic_sets return t_domestic_set;
END;
/*= History =============================================================
 * $Log: bin_import-package.sql,v $
 * Revision 1.9  2004/03/26 13:46:00  haris
 * Changed release - needed for version controll
 *
 * Revision 1.8  2003/09/18 15:22:43  haris
 * Added MCC import
 *
 * Revision 1.7  2002/10/31 15:24:13  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.6  2000/10/02 08:38:09  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.5  2000/03/28 13:35:33  uldis
 * Instal'acijai pievienota ties'ibu pie's'kir'sana un sinon'imu veido'sana
 *
 * Revision 1.4  1999/07/15 20:50:32  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/01/23 20:19:14  uldis
 * Izveidots reakciju iel'ades skripts
 *
 * Revision 1.2  1999/01/22 17:40:12  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:08  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

