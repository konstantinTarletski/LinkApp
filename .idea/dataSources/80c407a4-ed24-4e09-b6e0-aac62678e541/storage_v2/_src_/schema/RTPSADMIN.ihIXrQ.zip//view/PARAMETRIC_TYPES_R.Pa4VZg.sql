create view PARAMETRIC_TYPES_R as
select t.params_type,t.abreviature,t.description
		from parametric_types t
/

comment on table PARAMETRIC_TYPES_R is 'Parametric restrictions check modes'
/

comment on column PARAMETRIC_TYPES_R.PARAMS_TYPE is 'Parametric restrictions check mode indentifier'
/

comment on column PARAMETRIC_TYPES_R.ABREVIATURE is 'Parametric restrictions check mode abbreviature'
/

comment on column PARAMETRIC_TYPES_R.DESCRIPTION is 'Parametric restrictions check mode description'
/

