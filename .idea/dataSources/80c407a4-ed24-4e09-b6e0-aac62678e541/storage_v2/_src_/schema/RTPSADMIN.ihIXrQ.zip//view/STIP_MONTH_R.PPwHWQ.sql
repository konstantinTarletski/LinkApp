create view STIP_MONTH_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.account_id,
		x.begin_date,
		x.end_date,
		x.accnt_status,
		x.rep_number,
		x.begin_balance,
		x.credit,
		x.min_balance,
		x.debt,
		x.pay_till,
		x.non_reduce_bal,
		x.rev_intr,
		x.rev_fee,
		x.language,
		x.add_info,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_MONTH x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

