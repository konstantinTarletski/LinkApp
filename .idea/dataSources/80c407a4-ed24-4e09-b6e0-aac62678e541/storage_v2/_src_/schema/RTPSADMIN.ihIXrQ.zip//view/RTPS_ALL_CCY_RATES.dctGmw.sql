create view RTPS_ALL_CCY_RATES as
SELECT
    ct.CCY_NUM ccy_from,
    cf.CCY_NUM ccy_to,
    cf.BANK,
    trunc(ct.ccy_rate_buy/cf.ccy_rate_sell,15) CCY_RATE_MINUS,
    trunc(ct.ccy_rate_buy_min/cf.ccy_rate_sell_min,15) CCY_RATE_MINUS_MIN,
    trunc(ct.ccy_rate_sell/cf.ccy_rate_buy,15) CCY_RATE_PLUS,
    trunc(ct.ccy_rate_sell_min/cf.ccy_rate_buy_min,15) CCY_RATE_PLUS_MIN,
    trunc(ct.ccy_rate_mid/cf.ccy_rate_mid,15) CCY_RATE_MID,
    trunc(ct.ccy_rate_mid_min/cf.ccy_rate_mid_min,15) CCY_RATE_MID_MIN
 FROM RTPS_CCY_RATES cf,RTPS_CCY_RATES ct
where
	cf.pay_ccy=ct.pay_ccy and
	(cf.bank=ct.bank or (cf.bank is null and ct.bank is null))
/

