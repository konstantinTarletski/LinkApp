create view STIP_TRANSACTION_TYPES_R as
select
		type,
		sign,
		fee_flag,
		description
	from
		stip_transaction_types
/

