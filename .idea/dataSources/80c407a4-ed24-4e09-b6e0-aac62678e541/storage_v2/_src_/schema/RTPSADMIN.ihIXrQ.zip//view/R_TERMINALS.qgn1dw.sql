create view R_TERMINALS as
SELECT "DEVICE_ID", "DEVICE_NAME", "DEVICE_MERCHANT"
     FROM (SELECT d.device_id, d.device_name, d.device_merchant
             FROM atm_devices d
            WHERE d.device_parent = -1)
/

