create view IRMS_PREFIXES as
select
		p.centre_id,
		p.pref_min,
		p.pref_max,
		p.pref_delta,
		p.abbreviature,
		p.description
	from
		stip_prefixes p
	where
		exists (select null
					from centre_users
					where centre_id = p.centre_id and
					username = user)
/

