create Package
/* $HeadURL$ $Id$ */
MENU_GENERATE AUTHID CURRENT_USER IS
	PROCEDURE EXEC  ( STAT IN VARCHAR2);
	procedure generate;
END; -- Package spec
/*= History =============================================================
 * $Log: menu_generate-package.sql,v $
 * Revision 1.4  2002/10/31 15:25:56  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.3  2002/10/18 14:05:24  uldis
 * Viskaarshota menu pieejas ties'ibu instalaacija
 *
 * Revision 1.2  2002/10/17 15:02:12  uldis
 * Ties'ibas tiek pie's'kirtas caur lomu.
 *
 * Revision 1.1  2002/04/29 08:48:42  uldis
 * Izcelts lauk'a no menu_update pakotnes.
 *
 * Revision 1.4  2000/10/02 08:37:57  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.3  2000/09/27 08:56:12  uldis
 * Speci'alie lietot'aju v'ardi p'arnesti uz funkciju menu_specusers, t'ad'e'l
 * vairs nav j'anodod.
 *
 * Revision 1.2  2000/07/25 17:06:54  axl
 * Pielikts REVISION mainiigais, lai paraadaas fingerprintaa
 *
 * Revision 1.1  2000/07/07 10:13:41  uldis
 * Menu iel'adi veic ar vienu skriptu: load_menu.sh
 *
 * Revision 1.1  2000/07/06 14:40:47  uldis
 * Proced'ura nepiecie'sama menu pieejas ties'ibu iel'ad'e'sanai
 *
 *
 ========================================================================*/
/

