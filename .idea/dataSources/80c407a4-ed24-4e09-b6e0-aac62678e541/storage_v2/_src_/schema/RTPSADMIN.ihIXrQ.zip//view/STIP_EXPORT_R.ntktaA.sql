create view STIP_EXPORT_R as
select
     stip_exp.hist_numb
    ,stip_exp.centre_id
    ,stip_exp.effective_date
    ,tabl_name.abbreviature
    ,stip_exp.rows_export
from
    stip_export  stip_exp,
    table_names  tabl_name
 where stip_exp.table_name = tabl_name.table_name and
 exists (select null from centre_users where
 centre_id = stip_exp.centre_id and username = user)
 with check option
/

comment on column STIP_EXPORT_R.HIST_NUMB is 'Automated task history row number'
/

comment on column STIP_EXPORT_R.CENTRE_ID is 'Data owner processing entity identifier'
/

comment on column STIP_EXPORT_R.EFFECTIVE_DATE is 'File effective date and time'
/

comment on column STIP_EXPORT_R.TABLE_ABBREVIATURE is 'Name of table used for export in current file processing'
/

comment on column STIP_EXPORT_R.ROWS_EXPORT is 'Number of export data rows from current table'
/

