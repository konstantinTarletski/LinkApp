create view STIP_CLIENTS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.crd_holdr_id,
		x.parent_centre_id,
		x.parent_crd_holdr_id,
		x.crd_holdr_pwd,
		x.crd_holdr_msg,
		x.param_grp_1,
		x.param_grp_2,
		x.acnt_change,
		x.crd_holdr_name,
		x.comm_grp,
		x.add_info,
		x.person_code,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_CLIENTS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

