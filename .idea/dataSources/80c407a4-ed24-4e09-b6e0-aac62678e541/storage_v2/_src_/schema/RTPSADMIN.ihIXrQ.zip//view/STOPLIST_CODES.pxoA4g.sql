create view STOPLIST_CODES as
SELECT
     ANSW_CODE.ACTION_CODE
    ,ANSW_CODE.MSG_SHORT
    ,ANSW_CODE.MSG_FULL
FROM
    answer_codes  answ_code
 WHERE ANSW_CODE.STOP_USAGE = 'T'
/

comment on column STOPLIST_CODES.ACTION_CODE is 'Response action code'
/

comment on column STOPLIST_CODES.MSG_SHORT is 'Short response comment message'
/

comment on column STOPLIST_CODES.MSG_FULL is 'Detailed response comment message'
/

