create view STIP_ENTITIES_ALL as
select
		p.centre_id,
		p.authdat_alg_nr,
		p.prevalid_flag,
		p.advice_flag,
		p.params_type
	from
		processing_entities p
	where exists
		(select null from centre_users u
			where u.centre_id = p.centre_id and
				username = user)
with check option
/

comment on table STIP_ENTITIES_ALL is 'STIP entities all'
/

comment on column STIP_ENTITIES_ALL.CENTRE_ID is 'Center ID'
/

comment on column STIP_ENTITIES_ALL.AUTHDAT_ALG_NR is 'Central issuer authorization data files import/export algorithm number'
/

comment on column STIP_ENTITIES_ALL.PREVALID_FLAG is 'Request prevalidation enable flag'
/

comment on column STIP_ENTITIES_ALL.ADVICE_FLAG is 'Advice message generation necessity flag'
/

comment on column STIP_ENTITIES_ALL.PARAMS_TYPE is 'Parametric restriction algorithm'
/

