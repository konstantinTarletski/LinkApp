create package cardsuite_context is
    procedure set_context(p_var varchar2,p_value varchar2);
end;
/

