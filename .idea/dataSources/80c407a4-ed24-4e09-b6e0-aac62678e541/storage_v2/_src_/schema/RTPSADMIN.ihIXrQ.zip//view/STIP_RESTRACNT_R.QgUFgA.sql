create view STIP_RESTRACNT_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.card_number,
		x.crd_holdr_id,
		x.account_id,
		x.account_type,
		x.card_seq,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_RESTRACNT x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

