create view STIP_REFERENCE_R as
select
		x.row_numb,
		x.centre_id,
		x.unlocking_reason,
		x.unlocking_date
	from STIP_REFERENCE x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

