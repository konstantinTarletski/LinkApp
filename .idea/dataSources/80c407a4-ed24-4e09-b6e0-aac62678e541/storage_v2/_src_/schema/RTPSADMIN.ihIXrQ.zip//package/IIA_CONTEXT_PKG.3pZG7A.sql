create package iia_context_pkg as
	/* $HeadURL$ $Id$ */
	procedure set_value(p_name in varchar2, p_value in varchar2);
	function get_value(p_name in varchar2) return varchar2;
end;
/

