create Package
/* $HeadURL$ $Id$ */
MESSAGESN  IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	TYPE rsw_record IS RECORD
		(
		msg_error_code	number
		,msg_arguments	varchar2(1000)
		,rsw_rtpsid		varchar(11)
		,rsw_stip_flag	char(1)
		,rsw_prevalid_flag	char(1)
		,rsw_advice_flag	char(1)
		,rsw_online_flag	char(1)
		,rsw_offline_flag	char(1)
		,rsw_acq_bank	varchar(2)
		,rsw_iss_bank	varchar(2)
		,rsw_centre_service	varchar(30)
		,rsw_centre_address	varchar(30)
		,rep_row_numb	number(11)
		,orig_row_numb	number(11)
		,rsw_capture_flag	char(1)
		,msg_type	char(4)
		);
	TYPE messages_log_record is record
 (
  row_numb                   NUMBER(11),
  validity_flag              CHAR(1),
  locality_flag              CHAR(1),
  request_date               DATE,
  response_date              DATE,
  session_numb_in            NUMBER(11),
  session_numb_out           NUMBER(11),
  stan_internal              CHAR(6),
  card_type                  CHAR(2),
  dev_type                   CHAR(1),
  batch_owner                CHAR(15),
  orig_fld_038               CHAR(6),
  orig_fld_039               CHAR(3),
  msg_type_in                CHAR(4),
  msg_type_out               CHAR(4),
  msg_orig_in                CHAR(4),
  msg_orig_out               CHAR(4),
  fld_002                    VARCHAR2(19),
  fld_003                    CHAR(6),
  fld_004                    NUMBER(12),
  fld_005                    NUMBER(12),
  fld_006                    NUMBER(12),
  fld_007                    CHAR(14),
  fld_008                    NUMBER(8),
  fld_009                    NUMBER(16,9),
  fld_010                    NUMBER(16,9),
  fld_011                    CHAR(6),
  fld_012                    CHAR(14),
  fld_013                    CHAR(4),
  fld_014                    CHAR(4),
  fld_015                    CHAR(14),
  fld_016                    CHAR(4),
  fld_017                    CHAR(4),
  fld_018                    CHAR(4),
  fld_019                    CHAR(3),
  fld_020                    CHAR(3),
  fld_021                    CHAR(3),
  fld_022                    CHAR(12),
  fld_023                    CHAR(3),
  fld_024                    CHAR(3),
  fld_025                    CHAR(4),
  fld_026                    CHAR(4),
  fld_027                    NUMBER(1),
  fld_028                    CHAR(14),
  fld_029                    NUMBER(3),
  fld_030a                   NUMBER(12),
  fld_030b                   NUMBER(12),
  fld_031                    VARCHAR2(99),
  fld_032                    VARCHAR2(11),
  fld_033                    VARCHAR2(11),
  fld_034                    VARCHAR2(28),
  fld_035                    VARCHAR2(37),
  fld_036                    VARCHAR2(104),
  fld_037                    CHAR(12),
  fld_038                    CHAR(6),
  fld_039                    CHAR(3),
  fld_040                    CHAR(3),
  fld_041                    CHAR(8),
  fld_042                    CHAR(15),
  fld_043                    VARCHAR2(99),
  fld_044                    VARCHAR2(99),
  fld_045                    VARCHAR2(76),
  fld_046                    VARCHAR2(204),
  fld_047                    VARCHAR2(999),
  fld_048                    VARCHAR2(999),
  fld_049                    CHAR(3),
  fld_050                    CHAR(3),
  fld_051                    CHAR(3),
  fld_052                    RAW(8),
  fld_053                    RAW(48),
  fld_054                    VARCHAR2(360),
  fld_055                    RAW(255),
  fld_056a                   CHAR(4),
  fld_056b                   CHAR(6),
  fld_056c                   CHAR(14),
  fld_056d                   VARCHAR2(11),
  fld_057                    CHAR(3),
  fld_058                    VARCHAR2(11),
  fld_059                    VARCHAR2(999),
  fld_060                    VARCHAR2(999),
  fld_061                    VARCHAR2(999),
  fld_062                    VARCHAR2(999),
  fld_063                    VARCHAR2(999),
  fld_064                    RAW(8),
  fld_065                    RAW(8),
  fld_066                    VARCHAR2(204),
  fld_067                    NUMBER(2),
  fld_068                    CHAR(3),
  fld_069                    CHAR(3),
  fld_070                    CHAR(3),
  fld_071                    CHAR(8),
  fld_072                    VARCHAR2(4000),
  fld_073                    CHAR(14),
  fld_074                    NUMBER(10),
  fld_075                    NUMBER(10),
  fld_076                    NUMBER(10),
  fld_077                    NUMBER(10),
  fld_078                    NUMBER(10),
  fld_079                    NUMBER(10),
  fld_080                    NUMBER(10),
  fld_081                    NUMBER(10),
  fld_082                    NUMBER(10),
  fld_083                    NUMBER(10),
  fld_084                    NUMBER(10),
  fld_085                    NUMBER(10),
  fld_086                    NUMBER(16),
  fld_087                    NUMBER(16),
  fld_088                    NUMBER(16),
  fld_089                    NUMBER(16),
  fld_090                    NUMBER(10),
  fld_091                    CHAR(3),
  fld_092                    CHAR(3),
  fld_093                    VARCHAR2(11),
  fld_094                    VARCHAR2(11),
  fld_095                    VARCHAR2(99),
  fld_096                    RAW(999),
  fld_097                    NUMBER(16),
  fld_098                    CHAR(25),
  fld_099                    VARCHAR2(11),
  fld_100                    VARCHAR2(11),
  fld_101                    VARCHAR2(17),
  fld_102                    VARCHAR2(28),
  fld_103                    VARCHAR2(28),
  fld_104                    VARCHAR2(100),
  fld_105                    NUMBER(16),
  fld_106                    NUMBER(16),
  fld_107                    NUMBER(10),
  fld_108                    NUMBER(10),
  fld_109                    VARCHAR2(144),
  fld_110                    VARCHAR2(144),
  fld_111                    VARCHAR2(999),
  fld_112                    VARCHAR2(999),
  fld_113                    VARCHAR2(999),
  fld_114                    VARCHAR2(999),
  fld_115                    VARCHAR2(999),
  fld_116                    VARCHAR2(999),
  fld_117                    VARCHAR2(999),
  fld_118                    VARCHAR2(999),
  fld_119                    VARCHAR2(999),
  fld_120                    VARCHAR2(999),
  fld_121                    VARCHAR2(999),
  fld_122                    VARCHAR2(999),
  fld_123                    VARCHAR2(999),
  fld_124                    VARCHAR2(999),
  fld_125                    VARCHAR2(999),
  fld_126                    VARCHAR2(4000),
  fld_127                    VARCHAR2(999),
  fld_128                    RAW(8)
 );
	FUNCTION GetDataFromTLV(p_tlv VARCHAR2,p_tag VARCHAR2) RETURN VARCHAR2;
	PROCEDURE call_plsql(f IN OUT messages_log_record,proc_name varchar2,rsw in out rsw_record);
	PROCEDURE store(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE gmsg(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE srev(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE crev(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE srep(f  IN OUT messages_log_record,rsw in out rsw_record);
	PROCEDURE crep(f  IN OUT messages_log_record,rsw in out rsw_record);
END;
/*= History =============================================================
 * $Log: messagesn-package.sql,v $
 * Revision 1.2  2002/10/31 15:24:14  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.1  2001/11/27 17:41:08  tuxedo
 * Pievienota proced'ura messagesn.
 * Pievienots serviss messagesn_gmsg (atgrie'z FML zi'nojumu p'ec ROW_NUMB).
 * Netiek lietota rtps zi'nojuma C strukt'ura (rtps_if.vv).
 *
 ========================================================================*/
/

