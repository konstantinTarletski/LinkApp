create view POS_GROUP_ASSOC as
SELECT
     T.TEMPLATE_NAME
    ,T.TERMINAL_ID
FROM
    terminal_idtempl  t
/

