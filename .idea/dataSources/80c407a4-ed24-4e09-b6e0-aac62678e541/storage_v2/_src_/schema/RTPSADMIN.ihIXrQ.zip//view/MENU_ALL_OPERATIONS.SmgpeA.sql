create view MENU_ALL_OPERATIONS as
select /*+ rule */
  ms.username USERNAME,
  ms.menu_name MENU_name,
  m1.operation SEL,
  m2.operation UPD,
  m3.operation INS,
  m4.operation DEL,
  m5.operation EXE
from
  (select upper(username) username,menu_id,menu_name from menus, rtps_users) ms,
  menu_users m1,
  menu_users m2,
  menu_users m3,
  menu_users m4,
  menu_users m5
where
  ms.username = m1.username (+) and
  ms.username = m2.username (+) and
  ms.username = m3.username (+) and
  ms.username = m4.username (+) and
  ms.username = m5.username (+) and
  ms.menu_id  = m1.menu_id (+) and
  ms.menu_id  = m2.menu_id (+) and
  ms.menu_id  = m3.menu_id (+) and
  ms.menu_id  = m4.menu_id (+) and
  ms.menu_id  = m5.menu_id (+) and
  m1.operation (+)= 'S'       and
  m2.operation (+)= 'U'       and
  m3.operation (+)= 'I'       and
  m4.operation (+)= 'D'       and
  m5.operation (+)= 'E'
/

