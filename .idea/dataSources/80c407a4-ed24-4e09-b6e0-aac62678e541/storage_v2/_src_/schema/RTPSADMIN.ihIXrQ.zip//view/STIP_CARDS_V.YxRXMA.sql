create view STIP_CARDS_V as
select
		c.centre_id, c.effective_date, c.update_date,
		c.purge_date, c.pref_rec_num, c.card_number,
		c.crd_holdr_id, c.crd_holdr_name, c.crd_holdr_pwd,
		c.crd_holdr_msg, c.param_grp_1, c.param_grp_2,
		c.acnt_restr, c.avlamnt_flag, c.stat_code_1,
		c.stat_code_2, c.expiry_date_1, c.expiry_date_2,
		c.cvc_stripe_1, c.cvc_stripe_2, c.cvc_print_1,
		c.cvc_print_2, c.pvv_code_1, c.pvv_code_2,
		c.pvv_count_1, c.pvv_count_2, c.track_1_1,
		c.track_1_2, c.track_2_1, c.track_2_2,
		c.comm_grp, c.pvv_code_1_chg, c.pvv_code_2_chg,
		c.pvv_code_1_date, c.pvv_code_2_date, c.pvv_code_1_prv,
		c.pvv_code_2_prv, c.add_info, c.card_seq_1,
		c.card_seq_2, c.pki_1, c.pki_2,
		c.dki_1, c.dki_2, c.app_id,
		c.offl_limit_1, c.offl_limit_2, c.offl_limit_ctrl,
		c.client_id, c.pvv_count_1_chg, c.pvv_count_2_chg,
		decode(c_atc.card_number, null, nvl(c.atc_1, 0), nvl(c_atc.atc_1, 0)) as atc_1,
		decode(c_atc.card_number, null, nvl(c.atc_2, 0), nvl(c_atc.atc_2, 0)) as atc_2,
		c.pvv_code_1_alg, c.pvv_code_2_alg,
		(select a.msg_full
			from answer_codes a
			where a.action_code = c.stat_code_1) as description_1,
		(select a.msg_full
			from answer_codes a
			where a.action_code = c.stat_code_2) as description_2,
		s.effective_date as seffective_date, s.update_date as supdate_date,
		s.purge_date as spurge_date, NVL(s.action_code, '000' ) as saction_code,
		s.description as sdescription,
		u.centre_id as ucentre_id, u.effective_date as ueffective_date,
		u.update_date as uupdate_date, u.purge_date as upurge_date,
		NVL(u.action_code, '000' ) as uaction_code, u.description as udescription,
		e.effective_date as heffective_date, e.update_date as hupdate_date,
		e.purge_date as hpurge_date, e.card_number as hcard_number,
		NVL(e.action_code, '000' ) as haction_code, e.description as hdescription
	FROM
		stip_cards c,
		stip_stoplist s,
		stip_ustoplist u,
		cards_exceptions e,
		stip_cards_atc c_atc
	WHERE
		c.centre_id   = s.centre_id(+) AND
		c.card_number = s.card_number(+) AND
		c.centre_id   = u.centre_id(+) AND
		c.card_number = u.card_number(+) AND
		c.card_number = e.card_number(+) AND
		c.centre_id = c_atc.centre_id (+) AND
		c.card_number = c_atc.card_number(+)
/

