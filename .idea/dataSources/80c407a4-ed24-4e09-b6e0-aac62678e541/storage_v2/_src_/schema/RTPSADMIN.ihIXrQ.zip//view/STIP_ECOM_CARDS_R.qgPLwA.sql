create view STIP_ECOM_CARDS_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.card_number,
		x.status,
		x.auth_fail_count,
		x.block_date,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_ECOM_CARDS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

