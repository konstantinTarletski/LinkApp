create view STIP_CARD_ACCOUNTS_V as
SELECT
		a.centre_id, a.effective_date as aeffective_date, a.update_date as aupdate_date, a.purge_date as apurge_date,
		a.crd_holdr_id, a.account_type, a.account_id, a.account_ccy,
		a.initial_amount, a.bonus_amount, a.locked_amount, a.account_id_bank,
		a.add_info as aadd_info, a.credit_limit, a.lock_time, a.lock_amount_cms,
		a.amount_set_time, a.comm_grp as acomm_grp, a.shadow_amount, a.time_stamp,
		a.priority, a.status, a.credit_limit_expiry, a.bonus_amount_expiry,
		a.rec_id, a.step_count, a.deleted, a.lock_amount_cms_ofl,
		a.offline_locked, a.offline_cleared,
        (case when a.bonus_amount_expiry is NULL or a.bonus_amount_expiry > sysdate then 0 else 1 end) as bonus_expired,
        (case when a.credit_limit_expiry is NULL or a.credit_limit_expiry > sysdate then 0 else 1 end) as credit_limit_expired,
				(select
					nvl( sum(l.amount), 0 )
				from stip_locks l
				where l.centre_id = a.centre_id and
					l.account_id = a.account_id and
					l.ccy = a.account_ccy and
					( nvl(l.lock_type, 'XXX') = 'XXX') ) as stip_locks,
		(select
					nvl( sum(l.amount), 0 )
				from stip_locks l
				where l.centre_id = a.centre_id and
					l.account_id = a.account_id and
					l.ccy = a.account_ccy and
					l.lock_type = 'creditlimit') as creditlimit_locks,
		(select
					nvl( sum(l.amount), 0 )
				from stip_locks l
				where l.centre_id = a.centre_id and
					l.account_id = a.account_id and
					l.ccy = a.account_ccy and
					l.lock_type = 'bonusamount') as bonus_locks,
		c.effective_date as ceffective_date, c.update_date as cupdate_date, c.purge_date as cpurge_date,
		c.pref_rec_num, c.card_number, c.crd_holdr_name,
		c.crd_holdr_pwd, c.crd_holdr_msg, c.param_grp_1, c.param_grp_2,
		c.acnt_restr, c.avlamnt_flag, c.stat_code_1, c.stat_code_2,
		c.expiry_date_1, c.expiry_date_2, c.cvc_stripe_1, c.cvc_stripe_2,
		c.cvc_print_1, c.cvc_print_2, c.pvv_code_1, c.pvv_code_2,
		c.pvv_count_1, c.pvv_count_2, c.track_1_1, c.track_1_2,
		c.track_2_1, c.track_2_2, c.comm_grp as ccomm_grp, c.pvv_code_1_chg,
		c.pvv_code_2_chg, c.pvv_code_1_date, c.pvv_code_2_date, c.pvv_code_1_prv,
		c.pvv_code_2_prv, c.add_info as cadd_info, c.card_seq_1, c.card_seq_2,
		c.pki_1, c.pki_2, c.dki_1, c.dki_2,
		c.app_id, c.offl_limit_1, c.offl_limit_2, c.offl_limit_ctrl,
		c.client_id, c.pvv_count_1_chg, c.pvv_count_2_chg,
		decode(c_atc.card_number, null, nvl(c.atc_1, 0), nvl(c_atc.atc_1, 0)) as atc_1,
		decode(c_atc.card_number, null, nvl(c.atc_2, 0), nvl(c_atc.atc_2, 0)) as atc_2,
		c.pvv_code_1_alg, c.pvv_code_2_alg
		FROM
			stip_cards c,
			stip_accounts a,
			stip_cards_atc c_atc
		WHERE
			c.centre_id = a.centre_id and
			c.crd_holdr_id = a.crd_holdr_id and
			(
				(c.acnt_restr = 'N') OR (
					(c.acnt_restr = 'E') AND (
						(SELECT COUNT(*)
							FROM stip_restracnt r
							where
								r.centre_id = a.centre_id AND
								r.account_id = a.account_id AND
								r.card_number = c.card_number
						) > 0
					)
				) or (
					(c.acnt_restr = 'I') AND (
						(SELECT COUNT(*)
							FROM stip_restracnt r
							WHERE
								r.centre_id = a.centre_id AND
								r.account_id = a.account_id AND
								r.card_number = c.card_number
						) = 0
					)
				)
			) and
			c.centre_id = c_atc.centre_id(+) and
			c.card_number = c_atc.card_number(+)
/

