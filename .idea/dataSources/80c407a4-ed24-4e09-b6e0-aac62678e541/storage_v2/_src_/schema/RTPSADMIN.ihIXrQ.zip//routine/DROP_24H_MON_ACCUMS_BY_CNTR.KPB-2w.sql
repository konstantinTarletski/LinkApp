create PROCEDURE DROP_24H_MON_ACCUMS_BY_CNTR /* $Header: drop_24h_mon_accums_by_cntr.sql, 29.01.2021 $ */
(hist_numb integer,l_centre varchar2)
is
    type t_accum_list is table of rowid index by binary_integer;
    l_accum_list t_accum_list;
    l_accum_i number(30):=0;
    l_accum_tot number(30):=0;
    l_i number(30):=0;

    -- Globaalie DEBUG mainiigie un funkcijas
    g_msg varchar2(2000);
    st_centre_descr varchar2(255);

    startDate date := sysdate;
    deleteDate date := null;
    tmpDate date := null;
    l_recalcAlgorithm number := 0;
    l_deleteUnusedEventAccum number := 1;
    l_card_number varchar2(29) := '';
    l_accum_id number(11,0) := -1;
    l_reg_path varchar2(400) := null;
    fatalException exception;
--    type paramGrpPeriod is record (
--        accum_id stip_paramlist.accum_id%type
--    );
    type t_dateList is table of stip_paramlist.accum_id%type index by binary_integer;
    dateList t_dateList;
    dateCount number := 0;
    monthlyflag boolean := false;

    procedure Logs(msg varchar2) is
    begin
        g_msg:=common.writeLog('drop_24h_mon_accums_by_cntr','LGLV_9',' '||msg);
    end;
begin
 Logs('Started $Header: drop_24h_mon_accums_by_cntr.sql, 29.01.2021 $');
 begin
   SELECT ABBREVIATURE into st_centre_descr FROM PROCESSING_ENTITIES
   where CENTRE_ID=l_centre and STIP_FLAG='T' and PARAMS_TYPE=1;
 exception
   when no_data_found then
       Logs('No centre <'||l_centre||'> found');
       Logs('----> SQL error: '||SQLERRM);
       raise;
 end;
  if to_char(startDate,'DD')='01' then
    monthlyflag := True;
    Logs('Drop Monthly accumulators: YES. Detected first day of the month. Current date is '||to_char(startDate,'DD-MM-YYYY'));
  else
    Logs('Drop Monthly accumulators: NO. Current date is not first day of the month. Current date is '||to_char(startDate,'DD-MM-YYYY'));
  end if;
 begin
    Logs('Loading centre '||l_centre||' ('||st_centre_descr||') accumulators');
    l_accum_list.delete;
    l_accum_i:=0;
    if monthlyflag then
      FOR AOP in (
        select rowid
        from stip_accum_n
          where centre_id=l_centre
              and ((nvl(count_day,0)<>0) or (nvl(amount_day,0)<>0) or (nvl(count_week,0)<>0) or (nvl(amount_week,0)<>0))
      ) LOOP
          l_accum_i:=l_accum_i+1;
          l_accum_list(l_accum_i):=AOP.rowid;
          if mod(l_accum_i,500)=0 then
              Logs(' ... '||l_accum_i||' 24H and Monthly accumulators for centre '||l_centre||' loaded so far ...');
          end if;
      END LOOP;
    else
      FOR AOP in (
        select rowid
        from stip_accum_n
          where centre_id=l_centre
              and ((nvl(count_day,0)<>0) or (nvl(amount_day,0)<>0))
      ) LOOP
          l_accum_i:=l_accum_i+1;
          l_accum_list(l_accum_i):=AOP.rowid;
          if mod(l_accum_i,500)=0 then
              Logs(' ... '||l_accum_i||' 24H accumulators for centre '||l_centre||' loaded so far ...');
          end if;
      END LOOP;
    end if;
    Logs('Loaded centre '||l_centre||' ('||st_centre_descr||') '||l_accum_i||' accumulators');
  exception when others then
    Logs('Loading accumulators for centre '||l_centre||' ('||st_centre_descr||') failed:');
    Logs('----> SQL error: '||SQLERRM);
    raise;
 end;
 begin
    if monthlyflag then
      Logs('Zeroing centre '||l_centre||' ('||st_centre_descr||') 24H and Monthly accumulators');
    else
      Logs('Zeroing centre '||l_centre||' ('||st_centre_descr||') 24H accumulators');
    end if;
    for l_i in 1..l_accum_i loop
        l_accum_tot:=l_accum_tot+1;
        if monthlyflag then
        update stip_accum_n
        set count_day=0, amount_day=0, count_week=0, amount_week=0
        where rowid=l_accum_list(l_i);
        if l_deleteUnusedEventAccum>0 then
          select card_number,accum_id into l_card_number,l_accum_id from stip_accum_n where rowid=l_accum_list(l_i);
          delete from stip_event_accum where centre_id=l_centre and card_number=l_card_number and accum_id=l_accum_id;
        end if;
        commit;
      else
        update stip_accum_n
        set count_day=0, amount_day=0
        where rowid=l_accum_list(l_i);
        commit;
      end if;
        if mod(l_i,500)=0 then
            if monthlyflag then
              Logs(' ... '||l_i||' 24H and Monthly accumulators for centre '||l_centre||' zeroed so far ...');
            else
              Logs(' ... '||l_i||' 24H accumulators for centre '||l_centre||' zeroed so far ...');
            end if;
        end if;
    end loop;
    Logs('Zeroed centre '||l_centre||' ('||st_centre_descr||') '||l_accum_i||' accumulators');
  exception when others then
    Logs('Zeroing accumulators for centre '||l_centre||' ('||st_centre_descr||') failed:');
    Logs('----> SQL error: '||SQLERRM);
    raise;
 end;

 Logs('Finished $Header: drop_24h_mon_accums_by_cntr.sql, 29.01.2021 $');
 return;
end;

/

