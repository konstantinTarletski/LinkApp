create Procedure
/* $HeadURL$ $Id$ */
dbms_output_get_line(line out varchar2, status out integer) IS
begin
  dbms_output.get_line(line,status);
END;
/

