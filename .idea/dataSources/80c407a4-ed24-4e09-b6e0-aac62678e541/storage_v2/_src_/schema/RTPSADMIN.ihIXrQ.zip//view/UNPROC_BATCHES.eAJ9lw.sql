create view UNPROC_BATCHES as
SELECT
    bl.BATCH_OWNER,
    bl.RECONCILE_DATE,
    bl.RECONCILE_CNTR,
    bl.BATCH_ID,
    bl.UPDATE_DATE,
    bl.COMPLETE_FLAG,
    bl.COMPLETE_ROW,
    bl.COMPLETE_TASK,
    bl.SUSPEND_FLAG,
    bl.PROCESS_FLAG,
    bl.PROCESS_TASK,
    bl.CENTRE_ID,
    bl.MERCHANT_ID,
    bl.TERMINAL_ID
 FROM BATCHES_LOG bl,processing_entities pe
 where bl.complete_flag='T' and bl.suspend_flag='F' and
	bl.process_flag='F' and
	pe.centre_id=bl.centre_id and pe.process_flag='T'
/

comment on table UNPROC_BATCHES is 'Unprocessed batches, waiting for delivery to back-office'
/

comment on column UNPROC_BATCHES.BATCH_OWNER is 'Batch owner entity (centre, merchant or terminal) identifier'
/

comment on column UNPROC_BATCHES.RECONCILE_DATE is 'Batch reconciliation date'
/

comment on column UNPROC_BATCHES.RECONCILE_CNTR is 'Batch reconciliation counter within single date'
/

comment on column UNPROC_BATCHES.BATCH_ID is 'Batch identifier'
/

comment on column UNPROC_BATCHES.UPDATE_DATE is 'Batch totals update date'
/

comment on column UNPROC_BATCHES.COMPLETE_FLAG is 'Batch completion flag'
/

comment on column UNPROC_BATCHES.COMPLETE_ROW is 'Batch completion message reference row number'
/

comment on column UNPROC_BATCHES.COMPLETE_TASK is 'Batch completion automated task history number'
/

comment on column UNPROC_BATCHES.SUSPEND_FLAG is 'Batch suspended status flag'
/

comment on column UNPROC_BATCHES.PROCESS_FLAG is 'Batch processing flag'
/

comment on column UNPROC_BATCHES.PROCESS_TASK is 'Batch processing automated task history number'
/

comment on column UNPROC_BATCHES.CENTRE_ID is 'Batch owner card processing centre identifier'
/

comment on column UNPROC_BATCHES.MERCHANT_ID is 'Batch owner merchant identifier'
/

comment on column UNPROC_BATCHES.TERMINAL_ID is 'Batch owner terminal identifier'
/

