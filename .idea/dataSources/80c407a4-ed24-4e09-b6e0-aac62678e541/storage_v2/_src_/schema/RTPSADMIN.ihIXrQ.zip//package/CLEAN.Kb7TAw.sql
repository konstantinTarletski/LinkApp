create Package
/* $HeadURL$ $Id$ */
CLEAN IS
   PROCEDURE clean_all ( hist_numb INTEGER);
END; -- Package Specification CLEAN
/*= History =============================================================
 * $Log: arch_scm-package.sql,v $
 * Revision 1.2  2002/10/31 15:24:12  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.1  2002/10/17 08:02:59  uldis
 * Modulis scm.mfsb.clean sadaliits daljaas un pievienots arhivaacijai.
 *
 * Revision 1.1.1.1  2001/04/20 06:57:12  uldis
 * Added
 *
 ========================================================================*/
/

