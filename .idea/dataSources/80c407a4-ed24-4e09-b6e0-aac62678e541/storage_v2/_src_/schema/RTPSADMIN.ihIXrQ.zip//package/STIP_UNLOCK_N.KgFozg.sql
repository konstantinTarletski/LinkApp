create PACKAGE

STIP_UNLOCK_N is
--#==============================================================================
--#		RTPS.IIA.UNLOCK
--#
--#		Autorizaaciju summu atblokkeessana
--#			Kodeja:	Janis Kovalevskis
--#         	   Vilis Sviklis
--#
--#
--#		(c) 2002-2004 TietoEnator Financial Solutions
--#==============================================================================
function unlockauthorization (p_auth_rowid rowid,
								p_process_child boolean,
								updatestipmessexp boolean,
								unlockingreason char,
								childunlockingreason char,
								p_tran_rowid rowid,
								p_adjust_init_amount boolean default false,
								unlock_type char,
								unl0_init_amnt_update_mode number default null,
								matching_mode_used in number default null) return boolean;
--------------------------------------------------------------------------------
-- HOLDU NONEMSANA PEC CMS LOCK_TIME
--------------------------------------------------------------------------------
function unlockauthorization_cms ( p_centre_id varchar2, p_account_id varchar2,  p_effective date, p_custom_lock_type varchar2 default null) return boolean;

function unlockauthorization_cms_seq (p_centre_id varchar2, bankc varchar2, groupc varchar2, p_account_id varchar2, new_timestamp varchar2, old_timestamp varchar2, p_lock_time date, p_custom_lock_type varchar2 default null, p_effective date) return boolean;

end;
--==============================================================================
-- $Log: stip_unlock_n-package.sql,v $
-- Revision 1.19  2004/04/26 14:05:43  karlis
-- K04-0861 - Nnemt vera tranzakcijas komisiju veicot INIT konta atlikuma korekciju
-- atblokkeessanas laikaa
--
-- Revision 1.18  2004/04/23 13:49:50  karlis
-- Turpinaas uzlabojumi
--
-- Revision 1.17  2004/04/21 11:36:55  karlis
-- Komentaari
--
-- Revision 1.16  2003/01/16 17:05:29  vilis
-- If record in stip_references with same row_numb exist
-- then update that record
--
-- Revision 1.15  2003/01/13 15:49:31  kovacs
-- - Atjaunoti header komentaari
--
-- Revision 1.14  2002/12/16 15:54:49  vilis
-- WP package calls to unlock fixed;
-- errorcodes fixed;
--
-- Revision 1.13  2002/12/13 11:41:47  vilis
-- New unlocking ... WIP
--
-- Revision 1.9  2002/10/31 15:26:10  uldis
-- Netiek lietots REVISIO N buferis
--
-- Revision 1.8  2002/03/18 12:22:24  kovacs
-- Safixeets, ka netiek reekinaats initial amount izmainjas destionation kontam, ja tranzakcija nav paarskaitiijums.
--
-- Revision 1.7  2002/03/11 12:47:33  kovacs
-- Pielikts, ka tiek apskatiits gadiijums, ka autorizaacija jau ir atblokeeta, bet to censhas atblokeet ar tranzakciju.
--==============================================================================
/

