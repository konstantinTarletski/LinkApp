create view STIP_FEE_R as
select
	f.effective_date,
	f.update_date,
	f.purge_date,
	f.bank,
	f.comm_grp,
	f.account_ccy,
	f.service_type,
	f.min_fee,
	f.const_fee,
	f.percent_fee,
	f.max_fee,
	f.debit_credit,
	f.cond_set,
	f.cond_set_source
from
	stip_fee f
/

