create view STIP_OFFLINE_LIMIT_TRACK_R as
select
		x.centre_id,
		x.card_number,
		x.card_seq,
		x.limit,
		x.limit_real,
		x.last_ctta,
		x.ctta_ctrl,
		x.send_atc,
		x.status,
		x.confirm_atc,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_OFFLINE_LIMIT_TRACK x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

