create procedure RemoteEventsSendB(
	p_remote_status in varchar2,
	p_sleep_time in number,
	p_new_events in number
	) as
	cursor cur_n is select
			row_numb,
			centre_id,
			to_char(nvl(request_date,''),'YYYYMMDDHH24MISS') as request_date,
			to_char(nvl(response_date,''),'YYYYMMDDHH24MISS') as response_date,
			to_char(nvl(update_date,''),'YYYYMMDDHH24MISS') as update_date,
			session_numb_in,
			stan_internal,
			card_type,
			dev_type,pref_rec_num,
			msg_type,
			fld_002,
			fld_003,fld_004,fld_005,fld_006,
			to_char(nvl(fld_007,''),'YYYYMMDDHH24MISS') as fld_007,
			fld_008,fld_009,fld_010,fld_011,
			to_char(nvl(fld_012,''),'YYYYMMDDHH24MISS') as fld_012,
			fld_013,fld_014,
			to_char(nvl(fld_015,''),'YYYYMMDDHH24MISS') as fld_015,
			to_char(nvl(fld_016,''),'YYYYMMDDHH24MISS') as fld_016,
			to_char(nvl(fld_017,''),'YYYYMMDDHH24MISS') as fld_017,
			fld_018,fld_019,fld_020,fld_021,fld_022,
			fld_023,fld_024,fld_025,fld_026,fld_027,
			to_char(nvl(fld_028,''),'YYYYMMDDHH24MISS') as fld_028,
			fld_029,fld_030a,fld_031,fld_032,
			fld_033,fld_034,fld_035,fld_036,fld_037,fld_038,fld_039,fld_040,fld_041,fld_042,
			fld_043,fld_044,fld_045,fld_046,fld_047,fld_048,fld_049,fld_050,fld_051,fld_052,
			fld_053,fld_054,fld_055,fld_056a,fld_056b,
			to_char(nvl(fld_056c,''),'YYYYMMDDHH24MISS') as fld_056c,
			fld_056d,fld_057,fld_058,
			fld_059,fld_060,fld_061,fld_062,fld_063,fld_064,fld_065,fld_066,fld_067,fld_068,
			fld_069,fld_070,fld_071,fld_072,
			to_char(nvl(fld_073,''),'YYMMDD') as fld_073,
			fld_074,fld_075,fld_076,fld_077,fld_078,
			fld_079,fld_080,fld_081,fld_082,fld_083,fld_084,fld_085,fld_086,fld_087,fld_088,
			fld_089,fld_090,fld_091,fld_092,fld_093,fld_094,fld_095,fld_096,fld_097,fld_098,
			fld_099,fld_100,fld_101,fld_102,fld_103,fld_104,fld_105,fld_106,fld_107,fld_108,
			fld_109,fld_110,fld_111,fld_112,fld_113,fld_114,fld_115,fld_116,fld_117,fld_118,
			fld_119,fld_120,fld_121,fld_122,fld_123,fld_124,fld_125,fld_126,fld_127,fld_128,
			orig_fld_003,
			orig_fld_006,
			orig_fld_010,
			orig_fld_038,
			orig_fld_039,
			orig_fld_051,
			param_grp,accum_ccy,
			accum_amount,child_row,
			reverse_flag,
			validity_flag,
			delivery_flag,
			to_char(nvl(delivery_date,''),'YYYYMMDDHH24MISS') as delivery_date,
			accum_sign,
			locking_sign,
			locking_flag,
			unlocking_reason,
			to_char(nvl(unlocking_date,''),'YYYYMMDDHH24MISS') as unlocking_date,
			comm_grp,comm_id,
			state_id,state_history,
			delivery_retries,
			parent_row,
			remote_status
		from srt_stip_events_n e where ((p_remote_status='N' and e.remote_status='N') or (p_remote_status='F' and (e.remote_status is null or not e.remote_status='D'))) order by e.row_numb desc;

	cursor cur_o is select
			row_numb,
			centre_id,
			to_char(nvl(request_date,''),'YYYYMMDDHH24MISS') as request_date,
			to_char(nvl(response_date,''),'YYYYMMDDHH24MISS') as response_date,
			to_char(nvl(update_date,''),'YYYYMMDDHH24MISS') as update_date,
			session_numb_in,
			stan_internal,
			card_type,
			dev_type,pref_rec_num,
			msg_type,
			fld_002,
			fld_003,fld_004,fld_005,fld_006,
			to_char(nvl(fld_007,''),'YYYYMMDDHH24MISS') as fld_007,
			fld_008,fld_009,fld_010,fld_011,
			to_char(nvl(fld_012,''),'YYYYMMDDHH24MISS') as fld_012,
			fld_013,fld_014,
			to_char(nvl(fld_015,''),'YYYYMMDDHH24MISS') as fld_015,
			to_char(nvl(fld_016,''),'YYYYMMDDHH24MISS') as fld_016,
			to_char(nvl(fld_017,''),'YYYYMMDDHH24MISS') as fld_017,
			fld_018,fld_019,fld_020,fld_021,fld_022,
			fld_023,fld_024,fld_025,fld_026,fld_027,
			to_char(nvl(fld_028,''),'YYYYMMDDHH24MISS') as fld_028,
			fld_029,fld_030a,fld_031,fld_032,
			fld_033,fld_034,fld_035,fld_036,fld_037,fld_038,fld_039,fld_040,fld_041,fld_042,
			fld_043,fld_044,fld_045,fld_046,fld_047,fld_048,fld_049,fld_050,fld_051,fld_052,
			fld_053,fld_054,fld_055,fld_056a,fld_056b,
			to_char(nvl(fld_056c,''),'YYYYMMDDHH24MISS') as fld_056c,
			fld_056d,fld_057,fld_058,
			fld_059,fld_060,fld_061,fld_062,fld_063,fld_064,fld_065,fld_066,fld_067,fld_068,
			fld_069,fld_070,fld_071,fld_072,
			to_char(nvl(fld_073,''),'YYMMDD') as fld_073,
			fld_074,fld_075,fld_076,fld_077,fld_078,
			fld_079,fld_080,fld_081,fld_082,fld_083,fld_084,fld_085,fld_086,fld_087,fld_088,
			fld_089,fld_090,fld_091,fld_092,fld_093,fld_094,fld_095,fld_096,fld_097,fld_098,
			fld_099,fld_100,fld_101,fld_102,fld_103,fld_104,fld_105,fld_106,fld_107,fld_108,
			fld_109,fld_110,fld_111,fld_112,fld_113,fld_114,fld_115,fld_116,fld_117,fld_118,
			fld_119,fld_120,fld_121,fld_122,fld_123,fld_124,fld_125,fld_126,fld_127,fld_128,
			orig_fld_003,
			orig_fld_006,
			orig_fld_010,
			orig_fld_038,
			orig_fld_039,
			orig_fld_051,
			param_grp,accum_ccy,
			accum_amount,child_row,
			reverse_flag,
			validity_flag,
			delivery_flag,
			to_char(nvl(delivery_date,''),'YYYYMMDDHH24MISS') as delivery_date,
			accum_sign,
			locking_sign,
			locking_flag,
			unlocking_reason,
			to_char(nvl(unlocking_date,''),'YYYYMMDDHH24MISS') as unlocking_date,
			comm_grp,comm_id,
			state_id,state_history,
			delivery_retries,
			parent_row,
			remote_status
		from srt_stip_events_o e where ((p_remote_status='N' and e.remote_status='N') or (p_remote_status='F' and (e.remote_status is null or not e.remote_status='D'))) order by e.row_numb desc;

	l_condition varchar2(200);
	l_should_update varchar2(2);
	l_event cur_n%rowtype;
	l_rep_cursor_open number;
	--
	l_logname varchar2(32):='rem_events_send_b';
begin
	common.writeLog(l_logname,'LGLV_2','Passed parameters:');
	common.writeLog(l_logname,'LGLV_2','	p_remote_status='||p_remote_status);
	common.writeLog(l_logname,'LGLV_2','	p_sleep_time='||to_char(p_sleep_time));
	common.writeLog(l_logname,'LGLV_2','	p_new_events='||to_char(p_new_events));

	l_should_update := '0';
	if(reg.getc('/RTPS.IIA.STIP/EVENT_STORE_OPTIMIZED', l_should_update) ) then
		common.writeLog(l_logname,'LGLV_2','Value /RTPS.IIA.STIP/EVENT_STORE_OPTIMIZED from registry: ' || l_should_update);
	else
		common.writeLog(l_logname,'LGLV_2','Value /RTPS.IIA.STIP/EVENT_STORE_OPTIMIZED not defined in registry, assuming 0');
		l_should_update := '0';
	end if;
	l_rep_cursor_open := 0;

	----------------------------------------
	-- came here in case of too old snapshot
	----------------------------------------
	<<Reopen_Events_Cursor>>

	if (p_new_events=1) then
		open cur_n;
	else
		open cur_o;
	end if;

	if (l_should_update='1') then
		if (p_remote_status='N') then
			l_condition:='e.remote_status=''N''';
		end if;
		if (p_remote_status='F') then
			l_condition:='e.remote_status is null or not (e.remote_status=''D'')';
		end if;

		if (p_new_events=1) then
			common.writeLog(l_logname,'LGLV_9','Working with stip_events_n where ' || l_condition);
		else
			common.writeLog(l_logname,'LGLV_9','Working with stip_events_o where ' || l_condition);
		end if;

		begin
			loop
				common.writeLog(l_logname,'LGLV_9','Fetching row');
				begin
					if (p_new_events=1) then
						fetch cur_n into l_event;
					else
						fetch cur_o into l_event;
					end if;
				exception when others then
					------------ snapshot too old -----------------
					if(abs(sqlcode)=1555)then
						common.writeLog(l_logname,'LGLV_1','abs(sqlcode)=1555');
						if(l_rep_cursor_open<5)then
							l_rep_cursor_open:=l_rep_cursor_open+1;
						else
							common.writeLog(l_logname,'LGLV_1','Failed 5 times!');
							raise;
						end if;

						if (p_new_events=1) then
							close cur_n;
						else
							close cur_o;
						end if;
						common.writeLog(l_logname,'LGLV_1','Trying to reopen cursor');
						goto Reopen_Events_Cursor;
					end if;
				end;

				if ((p_new_events=1 and cur_n%notfound) or (p_new_events=0 and cur_o%notfound)) then
					common.writeLog(l_logname,'LGLV_9','p_new_events='||to_char(p_new_events)||'. No rows selected, exit');
					exit;
				end if;
				--exit when ((p_new_events=1 and cur_n%notfound) or (p_new_events=0 and cur_o%notfound));

				begin
					EXECUTE IMMEDIATE 'delete from swh_stip_events_n where row_numb=' || l_event.row_numb;
				exception when others then
					--in case of exception do nothing
					common.writeLog(l_logname,'LGLV_1','Failed to delete from remote event table, where ' || l_condition || '; error ' || SUBSTR(SQLERRM, 1, 100));
				end;

				begin
					EXECUTE IMMEDIATE 'insert into swh_stip_events_n (' ||
						'row_numb,' ||
						'centre_id,' ||
						'request_date,' ||
						'response_date,' ||
						'update_date,' ||
						'session_numb_in,' ||
						'stan_internal,' ||
						'card_type,' ||
						'dev_type,pref_rec_num,' ||
						'msg_type,' ||
						'fld_002,' ||
						'fld_003,fld_004,fld_005,fld_006,' ||
						'fld_007,' ||
						'fld_008,fld_009,fld_010,fld_011,' ||
						'fld_012,' ||
						'fld_013,fld_014,' ||
						'fld_015,fld_016,fld_017,' ||
						'fld_018,fld_019,fld_020,fld_021,fld_022,' ||
						'fld_023,fld_024,fld_025,fld_026,fld_027,' ||
						'fld_028,' ||
						'fld_029,fld_030a,fld_031,fld_032,' ||
						'fld_033,fld_034,fld_035,fld_036,fld_037,fld_038,fld_039,fld_040,fld_041,fld_042,' ||
						'fld_043,fld_044,fld_045,fld_046,fld_047,fld_048,fld_049,fld_050,fld_051,fld_052,' ||
						'fld_053,fld_054,fld_055,fld_056a,fld_056b,' ||
						'fld_056c,' ||
						'fld_056d,fld_057,fld_058,' ||
						'fld_059,fld_060,fld_061,fld_062,fld_063,fld_064,fld_065,fld_066,fld_067,fld_068,' ||
						'fld_069,fld_070,fld_071,fld_072,' ||
						'fld_073,' ||
						'fld_074,fld_075,fld_076,fld_077,fld_078,' ||
						'fld_079,fld_080,fld_081,fld_082,fld_083,fld_084,fld_085,fld_086,fld_087,fld_088,' ||
						'fld_089,fld_090,fld_091,fld_092,fld_093,fld_094,fld_095,fld_096,fld_097,fld_098,' ||
						'fld_099,fld_100,fld_101,fld_102,fld_103,fld_104,fld_105,fld_106,fld_107,fld_108,' ||
						'fld_109,fld_110,fld_111,fld_112,fld_113,fld_114,fld_115,fld_116,fld_117,fld_118,' ||
						'fld_119,fld_120,fld_121,fld_122,fld_123,fld_124,fld_125,fld_126,fld_127,fld_128,' ||
						'orig_fld_003,' ||
						'orig_fld_006,' ||
						'orig_fld_010,' ||
						'orig_fld_038,' ||
						'orig_fld_039,' ||
						'orig_fld_051,' ||
						'param_grp,accum_ccy,' ||
						'accum_amount,child_row,' ||
						'reverse_flag,' ||
						'validity_flag,' ||
						'delivery_flag,' ||
						'delivery_date,' ||
						'accum_sign,' ||
						'locking_sign,' ||
						'locking_flag,' ||
						'unlocking_reason,' ||
						'unlocking_date,' ||
						'comm_grp,comm_id,' ||
						'state_id,state_history,' ||
						'delivery_retries,' ||
						'parent_row,' ||
						'remote_status) ' ||
						'values (' ||
							l_event.row_numb || ',''' ||
							l_event.centre_id || ''',' ||
							'to_date(''' || l_event.request_date || ''',''YYYYMMDDHH24MISS''),' ||
							'to_date(''' || l_event.response_date || ''',''YYYYMMDDHH24MISS''),' ||
							'to_date(''' || l_event.update_date || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.session_numb_in || ''',''' ||
							l_event.stan_internal || ''',''' ||
							l_event.card_type || ''',''' ||
							l_event.dev_type || ''',''' ||
							l_event.pref_rec_num || ''',''' ||
							l_event.msg_type || ''',''' ||
							l_event.fld_002 || ''',''' ||
							l_event.fld_003 || ''',''' || l_event.fld_004 || ''',''' || l_event.fld_005 || ''',''' || l_event.fld_006 || ''',' ||
							'to_date(''' || l_event.fld_007 || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.fld_008 || ''',''' || l_event.fld_009 || ''',''' || l_event.fld_010 || ''',''' || l_event.fld_011 || ''',' ||
							'to_date(''' || l_event.fld_012 || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.fld_013 || ''',''' || l_event.fld_014 || ''',' ||
							'to_date(''' || l_event.fld_015 || ''',''YYYYMMDDHH24MISS''),' ||
							'to_date(''' || l_event.fld_016 || ''',''YYYYMMDDHH24MISS''),' ||
							'to_date(''' || l_event.fld_017 || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.fld_018 || ''',''' || l_event.fld_019 || ''',''' || l_event.fld_020 || ''',''' || l_event.fld_021 || ''',''' || l_event.fld_022 || ''',''' ||
							l_event.fld_023 || ''',''' || l_event.fld_024 || ''',''' || l_event.fld_025 || ''',''' || l_event.fld_026 || ''',''' || l_event.fld_027 || ''',' ||
							'to_date(''' || l_event.fld_028 || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.fld_029 || ''',''' || l_event.fld_030a || ''',''' || l_event.fld_031 || ''',''' || l_event.fld_032 || ''',''' ||
							l_event.fld_033 || ''',''' || l_event.fld_034 || ''',''' || l_event.fld_035 || ''',''' || l_event.fld_036 || ''',''' || l_event.fld_037 || ''',''' ||
							l_event.fld_038 || ''',''' || l_event.fld_039 || ''',''' || l_event.fld_040 || ''',''' || l_event.fld_041 || ''',''' || l_event.fld_042 || ''',''' || l_event.fld_043 || ''',''' ||
							l_event.fld_044 || ''',''' || l_event.fld_045 || ''',''' || l_event.fld_046 || ''',''' || l_event.fld_047 || ''',''' || l_event.fld_048 || ''',''' ||
							l_event.fld_049 || ''',''' || l_event.fld_050 || ''',''' || l_event.fld_051 || ''',''' || l_event.fld_052 || ''',''' || l_event.fld_053 || ''',''' ||
							l_event.fld_054 || ''',''' || l_event.fld_055 || ''',''' || l_event.fld_056a || ''',''' || l_event.fld_056b || ''',' ||
							'to_date(''' || l_event.fld_056c || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.fld_056d || ''',''' || l_event.fld_057 || ''',''' || l_event.fld_058 || ''',''' || l_event.fld_059 || ''',''' || l_event.fld_060 || ''',''' ||
							l_event.fld_061 || ''',''' || l_event.fld_062 || ''',''' || l_event.fld_063 || ''',''' || l_event.fld_064 || ''',''' || l_event.fld_065 || ''',''' ||
							l_event.fld_066 || ''',''' || l_event.fld_067 || ''',''' || l_event.fld_068 || ''',''' || l_event.fld_069 || ''',''' || l_event.fld_070 || ''',''' ||
							l_event.fld_071 || ''',''' || l_event.fld_072 || ''',' ||
							'to_date(''' || l_event.fld_073 || ''',''YYMMDD''),''' ||
							l_event.fld_074 || ''',''' || l_event.fld_075 || ''',''' ||
							l_event.fld_076 || ''',''' || l_event.fld_077 || ''',''' || l_event.fld_078 || ''',''' || l_event.fld_079 || ''',''' || l_event.fld_080 || ''',''' ||
							l_event.fld_081 || ''',''' || l_event.fld_082 || ''',''' || l_event.fld_083 || ''',''' || l_event.fld_084 || ''',''' || l_event.fld_085 || ''',''' ||
							l_event.fld_086 || ''',''' || l_event.fld_087 || ''',''' || l_event.fld_088 || ''',''' || l_event.fld_089 || ''',''' || l_event.fld_090 || ''',''' ||
							l_event.fld_091 || ''',''' || l_event.fld_092 || ''',''' || l_event.fld_093 || ''',''' || l_event.fld_094 || ''',''' || l_event.fld_095 || ''',''' ||
							l_event.fld_096 || ''',''' || l_event.fld_097 || ''',''' || l_event.fld_098 || ''',''' || l_event.fld_099 || ''',''' || l_event.fld_100 || ''',''' ||
							l_event.fld_101 || ''',''' || l_event.fld_102 || ''',''' || l_event.fld_103 || ''',''' || l_event.fld_104 || ''',''' || l_event.fld_105 || ''',''' ||
							l_event.fld_106 || ''',''' || l_event.fld_107 || ''',''' || l_event.fld_108 || ''',''' || l_event.fld_109 || ''',''' || l_event.fld_110 || ''',''' ||
							l_event.fld_111 || ''',''' || l_event.fld_112 || ''',''' || l_event.fld_113 || ''',''' || l_event.fld_114 || ''',''' || l_event.fld_115 || ''',''' ||
							l_event.fld_116 || ''',''' || l_event.fld_117 || ''',''' || l_event.fld_118 || ''',''' || l_event.fld_119 || ''',''' || l_event.fld_120 || ''',''' ||
							l_event.fld_121 || ''',''' || l_event.fld_122 || ''',''' || l_event.fld_123 || ''',''' || l_event.fld_124 || ''',''' || l_event.fld_125 || ''',''' ||
							l_event.fld_126 || ''',''' || l_event.fld_127 || ''',''' || l_event.fld_128 || ''',''' ||
							l_event.orig_fld_003 || ''',''' ||
							l_event.orig_fld_006 || ''',''' ||
							l_event.orig_fld_010 || ''',''' ||
							l_event.orig_fld_038 || ''',''' ||
							l_event.orig_fld_039 || ''',''' ||
							l_event.orig_fld_051 || ''',''' ||
							l_event.param_grp || ''',''' || l_event.accum_ccy || ''',''' ||
							l_event.accum_amount || ''',''' || l_event.child_row || ''',''' ||
							l_event.reverse_flag || ''',''' ||
							l_event.validity_flag || ''',''' ||
							l_event.delivery_flag || ''',' ||
							'to_date(''' || l_event.delivery_date || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.accum_sign || ''',''' || l_event.locking_sign || ''',''' || l_event.locking_flag || ''',''' ||
							l_event.unlocking_reason || ''',' ||
							'to_date(''' || l_event.unlocking_date || ''',''YYYYMMDDHH24MISS''),''' ||
							l_event.comm_grp || ''',''' || l_event.comm_id || ''',''' ||
							l_event.state_id || ''',''' || l_event.state_history || ''',''' ||
							l_event.delivery_retries || ''',''' ||
							l_event.parent_row || ''',''' ||
							l_event.remote_status || ''')';

			if (p_new_events=1) then
				EXECUTE IMMEDIATE 'update srt_stip_events_n e ' ||
						'set e.remote_status=''D'' ' ||
						'where e.row_numb=' || l_event.row_numb;
			else
				EXECUTE IMMEDIATE 'update srt_stip_events_o e ' ||
						'set e.remote_status=''D'' ' ||
						'where e.row_numb=' || l_event.row_numb;
			end if;

				commit;
				common.writeLog(l_logname,'LGLV_9','- COMMIT -');
				--sleep for given period
				if (p_sleep_time > 0) then
					dbms_lock.sleep(p_sleep_time);
				end if;

				exception when others then
					--in case of exception do nothing
					common.writeLog(l_logname,'LGLV_1','Failed to insert into remote event table, where ' || l_condition || '; error ' || SUBSTR(SQLERRM, 1, 100));
				end;

			end loop;
		exception when others then
			--in case of exception do nothing
			common.writeLog(l_logname,'LGLV_1','Failed to update remote event table, where ' || l_condition || '; error ' || SUBSTR(SQLERRM, 1, 100));
		end;
		common.writeLog(l_logname,'LGLV_2','Finished');
	else
		common.writeLog(l_logname,'LGLV_2','Not sending events, exiting');
	end if;
end;
/*= History =============================================================
 * $Log: migrate_events_to_wh_b.sql,v $
 * Revision 1.4  2008/02/22 08:05:34  liukiagn
 * added nvl and to_char functions to handle null values in date fields
 *
 * Revision 1.3  2008/02/21 14:56:21  liukiagn
 * repaired date formats in select statement
 *
 * Revision 1.2  2008/02/21 08:01:35  liukiagn
 * updating events with null remote_status in case of F (full update)
 *
 * Revision 1.1  2008/02/12 15:26:30  liukiagn
 * added to sql - procedure for bulk event update, without specifying rowid
 *
 ========================================================================*/
/

