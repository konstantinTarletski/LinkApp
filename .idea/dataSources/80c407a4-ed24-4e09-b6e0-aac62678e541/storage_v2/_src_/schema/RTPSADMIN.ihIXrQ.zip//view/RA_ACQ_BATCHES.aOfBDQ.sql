create view RA_ACQ_BATCHES as
SELECT BATCH_OWNER,
	RECONCILE_DATE,
	RECONCILE_CNTR,
	BATCH_ID,
	UPDATE_DATE,
	COMPLETE_FLAG,
	COMPLETE_ROW,
	COMPLETE_TASK,
	SUSPEND_FLAG,
	PROCESS_FLAG,
	PROCESS_TASK,
	CENTRE_ID,
	MERCHANT_ID,
	TERMINAL_ID
FROM BATCHES_LOG
/

comment on column RA_ACQ_BATCHES.BATCH_OWNER is 'Batch owner entity (centre, merchant or terminal) identifier'
/

comment on column RA_ACQ_BATCHES.RECONCILE_DATE is 'Batch reconciliation date'
/

comment on column RA_ACQ_BATCHES.RECONCILE_CNTR is 'Batch reconciliation counter within single date'
/

comment on column RA_ACQ_BATCHES.BATCH_ID is 'Batch identifier'
/

comment on column RA_ACQ_BATCHES.UPDATE_DATE is 'Batch totals update date'
/

comment on column RA_ACQ_BATCHES.COMPLETE_FLAG is 'Batch completion flag'
/

comment on column RA_ACQ_BATCHES.COMPLETE_ROW is 'Batch completion message reference row number'
/

comment on column RA_ACQ_BATCHES.COMPLETE_TASK is 'Batch completion automated task history number'
/

comment on column RA_ACQ_BATCHES.SUSPEND_FLAG is 'Batch suspended status flag'
/

comment on column RA_ACQ_BATCHES.PROCESS_FLAG is 'Batch processing flag'
/

comment on column RA_ACQ_BATCHES.PROCESS_TASK is 'Batch processing automated task history number'
/

comment on column RA_ACQ_BATCHES.CENTRE_ID is 'Batch owner card processing centre identifier'
/

comment on column RA_ACQ_BATCHES.MERCHANT_ID is 'Batch owner merchant identifier'
/

comment on column RA_ACQ_BATCHES.TERMINAL_ID is 'Batch owner terminal identifier'
/

