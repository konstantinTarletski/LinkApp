create Package
/* $HeadURL$ $Id$ */
BATCHES_REPORT IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/

	type batch_pk is record (batch_owner	batches_log.batch_owner%type
						    ,reconcile_date	batches_log.reconcile_date%type
						    ,reconcile_cntr	batches_log.reconcile_cntr%type
						    ,hist_number	batches_log.process_task%type
							);
	type batch_tab_type is table of batch_pk index by binary_integer;
   	batch_tab	batch_tab_type;
	PROCEDURE batches_hist_from_filters (CentreTotals number default 1, BatchTotals number default 1,
    TransactionsList number default 1,
    DateFrom date default sysdate-1,
	DateTo date default sysdate, DateOf number default 1,
	TransactionSource_Centre number default 1, TransactionSource_Merchant number default 1,
	TransactionSource_Terminal number default 1,
	BatchStatus_InCapture number default 1, BatchStatus_ClosedNotProcessed number default 1,
	BatchStatus_Suspended number default 1, BatchStatus_Processed number default 1,
	ProcessingTask varchar2 default '%', CentreID varchar2 default '%',
	BatchOwner varchar2 default '%');
	PROCEDURE batches_hist (CentreTotals number default 1, BatchTotals number default 1,
    TransactionsList number default 1,
	DateFrom date default null,
	DateTo date default null, DateOf number default null,
	TransactionSource_Centre number default null, TransactionSource_Merchant number default null,
	TransactionSource_Terminal number default null,
	BatchStatus_InCapture number default null, BatchStatus_ClosedNotProcessed number default null,
	BatchStatus_Suspended number default null, BatchStatus_Processed number default null,
	ProcessingTask varchar2 default null, CentreID varchar2 default null,
	BatchOwner varchar2 default null,Real_date_min date default null,
	Real_date_max date default null, Select_Without_Filters number default 1);
	procedure batches_hist_txt_complex(OutputType number default 1);
	procedure batches_hist_array_preparer (hist_number number);
	procedure CreateDataArray(owners varchar2, rec_date varchar2, rec_cntrs varchar2, counts number);
    procedure AddBatch(owner varchar2, rec_date varchar2, rec_cntr varchar2);
END;
/

