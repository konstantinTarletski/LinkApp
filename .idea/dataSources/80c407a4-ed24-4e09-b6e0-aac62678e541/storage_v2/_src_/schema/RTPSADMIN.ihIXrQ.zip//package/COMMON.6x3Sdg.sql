create PACKAGE
/* @ITEM_ID_VERSION@ */
common
IS
/*=======================================================================
 * @ITEM_ID_VERSION@
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999,2000
 ========================================================================*/

  logLevel               INTEGER;
  lastOpen               DATE;
  lastFile               VARCHAR2(2048);
  the_time_stamp         INTEGER;
  handle                 UTL_FILE.file_type;
  LONG_ROLLBACK_SEGMENT  VARCHAR(30):= NULL;

--
PROCEDURE flushLog;
PROCEDURE closeLog;
--
PROCEDURE writeLog(p_Log_File IN VARCHAR2, p_Reason IN VARCHAR2, p_Info_To_Log IN VARCHAR2);
FUNCTION  writeLog(p_Log_File IN VARCHAR2, p_Reason IN VARCHAR2, p_Info_To_Log IN VARCHAR2)RETURN VARCHAR2;
--
PROCEDURE set_long_rollback(p_arg BOOLEAN:=FALSE);
--
FUNCTION  lock_on(p_szLockName IN VARCHAR2, p_iEXPIRATION IN INTEGER:=21600) RETURN VARCHAR2;
PROCEDURE lock_off(p_LockHandle IN VARCHAR2);
--
FUNCTION  Get_Timer RETURN VARCHAR2;
PROCEDURE Set_Timer;
--
PROCEDURE write_audit( p_action    IN VARCHAR2
                     , p_success   IN VARCHAR2
                     , p_app_style IN VARCHAR2
                     , p_app_data  IN VARCHAR2 -- app version etc.
                     , p_app_name  IN VARCHAR2
                     , p_details   IN VARCHAR2
                     , p_file_name IN VARCHAR2)
;

END;
/

