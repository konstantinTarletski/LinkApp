create view STIP_LOCKTIMES_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.pref_rec_num,
		x.mcc_class,
		x.dom_loctime,
		x.int_loctime
	from STIP_LOCKTIMES x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

