create view STIP_CARD_FAMILIES_R as
select
		x.card_family,
		x.card_family_description
	from STIP_CARD_FAMILIES x
/

