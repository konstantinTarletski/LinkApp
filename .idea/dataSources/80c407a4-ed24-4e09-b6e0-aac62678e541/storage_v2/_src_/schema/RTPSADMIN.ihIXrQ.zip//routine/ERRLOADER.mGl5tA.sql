create Procedure /* $HeadURL$ $Id$ */
ERRLOADER ( program_name IN VARCHAR2) IS
prog_kods INTEGER;
kludu_skaits1 INTEGER;
kludu_skaits2 INTEGER;
skaits	integer;
BEGIN
	BEGIN
		SELECT program_code INTO prog_kods FROM program_names
			WHERE program_name=errloader.program_name;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			dbms_output.put_line('errloader: Unknown program '||errloader.program_name||', not found in PROGRAM_NAMES');
			raise;
			RETURN;
	END;
SELECT COUNT(*) INTO kludu_skaits1 FROM err_load;
SELECT COUNT(*) INTO kludu_skaits2 FROM error_descriptions
	WHERE program_code=prog_kods;
	IF kludu_skaits2>0 AND kludu_skaits1=0 THEN
		dbms_output.put_line('errloader: There is something wrong. Deleting of all descriptions is suspicious');
		raise program_error;
		RETURN;
	END IF;
	DECLARE
	CURSOR rep_err_severity IS
		SELECT severity, error_code FROM err_load
		WHERE severity NOT IN ('E','M','W','D');
	rec rep_err_severity%rowtype;
	kludas_pazime INTEGER:=0;
	BEGIN
		FOR rec IN rep_err_severity LOOP
			dbms_output.put_line('errloader: Invalid error severity '||rec.severity||' (must be E,M,W or D). Number '||rec.error_code);
			kludas_pazime:=kludas_pazime+1;
		END LOOP;
		IF kludas_pazime>0 THEN
			raise program_error;
			RETURN;
		END IF;
	END;
	DECLARE
	cursor rep_err_code is
		select error_code,count(*) c from ERR_LOAD group by error_code having count(*)>1;
	rec	rep_err_code%rowtype;
	kludas_pazime INTEGER:=0;
	BEGIN
		for rec in rep_err_code loop
			dbms_output.put_line('errloader: '||to_char(rec.c)||' times repeated message '||to_char(rec.error_code));
			kludas_pazime:=kludas_pazime+1;
		end loop;
		IF kludas_pazime>0 THEN
			raise program_error;
			RETURN;
		END IF;
	END;
-- Pievieno jaunaas kljuudas
	INSERT INTO error_descriptions (program_code, error_code, error_class, error_severity, store_flag,
		description, error_arguments, action_code)
		select prog_kods, error_code, 0, DECODE(severity, 'E',1,'W',5,'M',8,'D',9,0),
		DECODE(severity, 'E','T','W','T','M','F','D','F','T'), msg_template, error_arguments, NULL
		from err_load
		where not exists
			(
			select 'Kluuda jau eksistee' from error_descriptions
				where program_code=prog_kods and error_code=err_load.error_code);
	skaits:=SQL%ROWCOUNT;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' new error descriptions inserted');
	end if;

-- Pievieno jaunos kljuudu pazinojumus
	skaits:=SQL%ROWCOUNT;
	INSERT INTO error_dictionary (program_code, error_code, msg_template_nr, msg_template)
		select prog_kods, error_code, 0, msg_template from err_load
		where not exists
			(
			select 'Kluudas apraksts jau eksistee' from error_dictionary
				where program_code=prog_kods and error_code=err_load.error_code and msg_template_nr=0);
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' new error templates inserted');
	end if;

-- Maina kljuudas
	skaits:=0;
	for i in
		(select
			E.ERROR_CODE,
			0 ERROR_CLASS,
			DECODE(E.severity, 'E',1,'W',5,'M',8,'D',9,0) ERROR_SEVERITY,
			DECODE(E.severity, 'E','T','W','T','M','F','D','F','T') STORE_FLAG,
			E.msg_template DESCRIPTION,
			E.error_arguments ERROR_ARGUMENTS,
			NULL ACTION_CODE
			from err_load E,error_descriptions D
			where D.PROGRAM_CODE=prog_kods and E.ERROR_CODE=D.ERROR_CODE
		minus
		select
		    ERROR_CODE,ERROR_CLASS,ERROR_SEVERITY,STORE_FLAG,DESCRIPTION,ERROR_ARGUMENTS,ACTION_CODE
		 FROM ERROR_DESCRIPTIONS where program_code=prog_kods) loop
		update error_descriptions set
		    ERROR_CLASS =i.ERROR_CLASS,
		    ERROR_SEVERITY=i.ERROR_SEVERITY,
		    STORE_FLAG=i.STORE_FLAG,
		    DESCRIPTION=i.DESCRIPTION,
		    ERROR_ARGUMENTS=i.ERROR_ARGUMENTS,
		    ACTION_CODE=i.ACTION_CODE
		where program_code=prog_kods and error_code=i.error_code;
		skaits:=skaits+1;
	end loop;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error descriptions changed');
	end if;
-- Maina kljuudas pazinojumu
	skaits:=0;
	for i in
		(select
			E.ERROR_CODE,
			E.msg_template
			from err_load E,error_dictionary D
			where D.PROGRAM_CODE=prog_kods and E.ERROR_CODE=D.ERROR_CODE and D.msg_template_nr=0
		minus
		select
		    ERROR_CODE,MSG_TEMPLATE
		 FROM ERROR_DICTIONARY where program_code=prog_kods) loop
		update error_dictionary set msg_template=i.msg_template
		where program_code=prog_kods and error_code=i.error_code;
		skaits:=skaits+1;
	end loop;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error templates changed');
	end if;
-- Dzeesh vairs neeksisteejoshaas kljuudas no ERROR_SECTION_KEYS
	DELETE FROM error_section_keys
	WHERE program_code=prog_kods and error_code in
		(select	ERROR_CODE	from error_descriptions where PROGRAM_CODE=prog_kods
		minus
		select    ERROR_CODE FROM ERR_LOAD);
	skaits:=SQL%ROWCOUNT;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error section references deleted');
	end if;
-- Dzeesh vairs neeksisteejoshaas kljuudas no ERROR_ACTION_KEYS un kuras nav debug meerkjiem
	DELETE FROM error_action_keys
	WHERE program_code=prog_kods and error_code in
		(select	ERROR_CODE	from error_descriptions where PROGRAM_CODE=prog_kods
		minus
		select    ERROR_CODE FROM ERR_LOAD) and error_code>0;
	skaits:=SQL%ROWCOUNT;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error action references deleted');
	end if;
-- Dzeesh vairs neeksisteejoshaas kljuudas no ERROR_DESCRIPTIONS, kuraam nav notikumu tabulaa ERROR_MESSAGES
	DELETE FROM error_DICTIONARY
	WHERE program_code=prog_kods and error_code in
		(select	ERROR_CODE	from error_dictionary where PROGRAM_CODE=prog_kods
		minus
		select    ERROR_CODE FROM ERR_LOAD) AND
		not exists
			(select 'notikums' from error_messages
			where program_code=prog_kods and error_code=error_dictionary.error_code);
	skaits:=SQL%ROWCOUNT;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error templates deleted');
	end if;
	DELETE FROM error_DESCRIPTIONS
	WHERE program_code=prog_kods and error_code in
		(select	ERROR_CODE	from error_descriptions where PROGRAM_CODE=prog_kods
		minus
		select    ERROR_CODE FROM ERR_LOAD) AND
		not exists
			(select 'notikums' from error_messages
			where program_code=prog_kods and error_code=error_DESCRIPTIONS.error_code);
	skaits:=SQL%ROWCOUNT;
	if(skaits<>0) then
		dbms_output.put_line('errloader: '||skaits||' error descriptions deleted');
	end if;
	dbms_output.put_line('errloader: Error descriptions successfully loaded');
	COMMIT;
EXCEPTION
WHEN OTHERS THEN
	raise;
END;
/

