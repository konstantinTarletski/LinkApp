create PACKAGE
/*$HeadURL$ $Id$*/
STIP_COMMON_UTILS IS

/******************************************************************************\
	RTPS.IIA.COMMON
	-------------
	$HeadURL$ $Id$
	-----------------------------------------------------------------------------
	Package contains utility functions and procedures for general use
	-----------------------------------------------------------------------------
	Copyright (C) 2011 Tieto, Financial Systems, Cards
\******************************************************************************/

	type t_registry_centre_cache is table of varchar2(1024) index by varchar2(32); -- index by centre_id
	TYPE TPairCentreCard IS RECORD
	(
		centre_id STIP_PINCNT.CENTRE_ID%TYPE,
		card_number STIP_PINCNT.CARD_NUMBER%TYPE
	);
	type CentreCardList IS TABLE OF TPairCentreCard;

	function logpan(p_pan in varchar2) return varchar2;

	function GetFromTLV(p_tlv varchar2, p_tag varchar2, p_taglen number default 3, p_lenlen number default 3) return varchar2;

	function AddToTLV(p_tlv in out varchar2, p_tag varchar2, p_val varchar2) return boolean;

	function ReadRegistryParamForCentre(p_reg_path in varchar2, p_reg_param_name in varchar2, p_cache in out nocopy t_registry_centre_cache) return boolean;

	PROCEDURE deletePinCounter( l_info in out varchar2, l_centreId in varchar2 default null,
														l_cardNumber in varchar2 default null );

	PROCEDURE deletePinCounterList( l_info in out varchar2, centre_card_list in CentreCardList default null );


END;
/

