create view RTPS_BANKS_R as
select
		b.bank,
		b.bank_name
	from
		rtps_banks b
	where
		exists (select null
					from
						centre_users cu,
						processing_entities pe
					where
						pe.iss_bank=b.bank and
						cu.centre_id = pe.centre_id and
						cu.username = user)
with check option
/

