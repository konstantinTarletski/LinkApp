create PACKAGE stip_spec_trans_notify IS
	function newTransaction(rowStipTranN stip_transactions_n%ROWTYPE, bank_c varchar2, groupc varchar2) return stip_speacial_transaction_base;
end;
/

