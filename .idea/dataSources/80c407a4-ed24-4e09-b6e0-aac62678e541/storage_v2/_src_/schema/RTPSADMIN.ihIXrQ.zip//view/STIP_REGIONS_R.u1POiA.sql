create view STIP_REGIONS_R as
select
		r.bank,
		r.acquirer_id,
		r.region,
		r.rule_expr,
		r.priority
	from
		stip_regions r
	where
		exists
			(select null
				from
					centre_users cu,
					processing_entities pe
				where
					pe.iss_bank=bank and
					cu.centre_id = pe.centre_id and
					cu.username = user)
	with check option
/

