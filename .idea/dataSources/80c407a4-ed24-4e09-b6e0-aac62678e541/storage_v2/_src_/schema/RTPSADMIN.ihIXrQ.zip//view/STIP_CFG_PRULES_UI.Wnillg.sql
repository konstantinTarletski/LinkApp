create view STIP_CFG_PRULES_UI as
select
	a.rule_id,
	a.profile_id,
	a.priority,
	a.rule_expression,
	a.name_db,
	a.name_user,
	a.processing_state
from
	stip_cfg_prules a
/

comment on column STIP_CFG_PRULES_UI.RULE_ID is 'Rule identification number'
/

comment on column STIP_CFG_PRULES_UI.PROFILE_ID is 'Profile identification number'
/

comment on column STIP_CFG_PRULES_UI.PRIORITY is 'Rule priority'
/

comment on column STIP_CFG_PRULES_UI.RULE_EXPRESSION is 'Rule expression'
/

comment on column STIP_CFG_PRULES_UI.NAME_DB is 'Unique name for DB'
/

comment on column STIP_CFG_PRULES_UI.NAME_USER is 'Name for user interface components'
/

comment on column STIP_CFG_PRULES_UI.PROCESSING_STATE is 'Rule processing state'
/

