create Package
/* $HeadURL$ $Id$ */
stip_xch_NORMALIZE IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
    function normalize return boolean;
END;
/*= History =============================================================
 * $Log: stip_xch_normalize-package.sql,v $
 * Revision 1.9  2002/12/16 17:25:25  vilis
 * Removed duplicated error codes from logs
 *
 * Revision 1.7  2002/10/31 15:26:11  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.6  2000/10/02 08:38:03  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.5  2000/01/11 12:37:30  uldis
 * Modu'la zars XCH_NEW pievienots pamatzaram
 *
 * Revision 1.4.2.2  1999/09/07 20:58:56  uldis
 * P'arrakst'ita progresa indik'acija. Katra centra pilnai apstr'adei tagat
 * tiek lietots tie'si viens progresa indikatora cikls.
 *
 * Revision 1.4  1999/07/15 20:50:08  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/02/24 12:52:28  karlis
 * Izmainnas UNLOCK algoritmaa, lai tiktu meegginaats atkaartoti kviteet
 * tranzakcijas, kas nav nokviteejussaas ar pirmo piegaajienu.
 *
 * Revision 1.2  1999/01/22 17:39:48  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:00  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

