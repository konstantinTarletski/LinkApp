create view STIP_ECOM_KEYS_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.key_index,
		x.crypto_key,
		x.crypto_key_info
	from STIP_ECOM_KEYS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

