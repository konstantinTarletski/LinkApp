create view STIP_GRPACCUM_R as
select
		x.centre_id,
		x.card_number,
		x.mcc_group,
		x.count_day,
		x.amount_day,
		x.count_week,
		x.amount_week
	from STIP_GRPACCUM x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

