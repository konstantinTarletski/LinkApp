create package
/* $HeadURL$ $Id$ */
stip_scour_n is
/*#=======================================================================
  #	RTPS.IIA.RECALC
  #		Autorizacijas informaacijas kontrole, atblokkeessana
  #		peec noilguma
  #
  #		Kodeja: Uldis Ansmits
  #		Kodeja: Karlis Ogsts
  #		STIP_SCOUR_N kodeja: Uldis Grinbergs
  #
  # $HeadURL$ $Id$
  # (C) Tieto Konts Financial Systems Ltd. 1998,1999,2000,2001
  #========================================================================*/
--==========================================================================================
--	24H akumulaatoru paarreekkins
--==========================================================================================
procedure Day_Limits(p_hist_numb number,p_centre_id varchar2 default null);
--==========================================================================================
-- Gara posma akumulaatoru paarreekkins
-- Akumulaatoru kontrole un dzeessana
--==========================================================================================
procedure Long_Limits(p_hist_numb number,p_centre_id varchar2 default null);
--==========================================================================================
-- Noskaidro kur (peec PROC_ENTIT.PARAMS_TYPE) dzeesh kartei akumulatorus
-- Tiek izsaukts no stip_call_api un stip_wp_api
--==========================================================================================
function reset_card_accums(p_centre_id in varchar2, p_card_numb in varchar2) return boolean;
end;
/*
 *= History =============================================================
 * $Log: stip_scour_n-package.sql,v $
 * Revision 1.17  2002/12/17 10:47:03  vilis
 * Fixed duplicated errorcodes
 *
 * Revision 1.13  2002/10/31 15:26:09  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.12  2002/01/23 10:11:39  karlis
 * Paarveidots TUXEDO baazeeto LONG limitu paarreekkins, lai lietotu PL/SQL tabulas.
 *
 * Revision 1.11  2001/11/16 12:35:41  kovacs
 * STIP_SCOUR_N gan 24h, gan long periodam pielikta subtractiivaa recalculaacija,
 * kaa arii stip_scour 24h recalcs taisa substractive tikai tad, ja ieprieksheejais
 * recalcs ir bijis pirms < 24h.
 *
 * Revision 1.10  2001/11/14 11:21:57  kovacs
 * Saakts likt klaat recalc optimizaaciju stip_scour_n
 *
 * Revision 1.9  2001/08/24 09:27:18  uldis
 * Izdz'estas tuk's'as rindi'nas programmas tekst'a.
 *
 * Revision 1.8  2001/05/17 09:46:33  isais
 * - Paarnesta ResetCardAccums algoritmiskaa dalja no stip_call_api uz shejieni kaa reset_card_accums,
 * lai to vareetu izsaukt netikai stip_call_api, bet arii stip_wp_api.
 *
 * Revision 1.7  2001/05/15 16:40:44  isais
 * (modifications)
 * - atkal jau ...
 *
 * Revision 1.6  2001/05/15 15:48:45  isais
 * (modifications)
 * - Meichaam jaunas idejas :-)) Labojam darbiibas principus peec Nataaliju jaunajaam idejaam :)
 *
 * Revision 1.5  2001/05/15 13:13:45  isais
 * (bugfixes)
 * ...
 *
 * Revision 1.4  2001/05/15 12:29:45  isais
 * (modifications)
 * ...
 *
 * Revision 1.3  2001/05/11 17:18:41  isais
 * (modifications)
 * - Modifikaacijas sakaraa ar jauno parametrisko paarbauzhu veida pievieshanu.
 *
 * Revision 1.2  2001/05/11 08:39:46  isais
 * (modifications)
 * - Patreiz STIP_SCOUR meegjina izsaukt gan savu veco dienas paarreekjinu, gan jauno no STIP_SCOUR_N
 *
 * Revision 1.1  2001/05/08 12:24:16  isais
 * (imported sources)
 * - Pievienoti pakas STIP_SCOUR_N izejnieki.
 *
 *=======================================================================
*/
/

