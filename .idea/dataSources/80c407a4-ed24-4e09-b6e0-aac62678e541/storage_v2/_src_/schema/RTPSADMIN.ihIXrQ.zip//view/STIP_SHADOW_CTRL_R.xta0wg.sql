create view STIP_SHADOW_CTRL_R as
select
	c.bank_c,
	c.groupc,
	c.ctime,
	c.proc_id,
	c.ctime_chip
from
    stip_shadow_ctrl c
where exists
	(select null
		from
			centre_users u,
			stip_entities e
		where
			u.centre_id=e.centre_id and
			e.bank_c=c.bank_c and
			e.groupc=c.groupc and
			u.username=user)
	with check option
/

comment on table STIP_SHADOW_CTRL_R is 'Control information for interface between TRM CMS and TRM RTPS'
/

