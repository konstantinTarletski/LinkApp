create view R_BATCH_TRN as
select
        batch_id, batch_owner, reconcile_date, reconcile_cntr,
		transact_row, fld_011, fld_012, request_date,
		fld_002, fld_014, msg_type_in, fld_003, fld_004, acq_orig_amt, c.curr_alpha, c.curr_exp_dot,
		fld_041, fld_042, suspect_cause, fld_038, fld_039, fld_031, fld_032, fld_033, fld_037,
		is_reversal, DC_IND
from ccy_codes c,(
select
		tl.batch_id, tl.batch_owner, tl.reconcile_date, tl.reconcile_cntr,
		tl.transact_row, tl.fld_011, tl.fld_012, tl.request_date,
		tl.fld_002, tl.fld_014, tl.msg_type_in, tl.fld_003, tl.fld_004, tl.acq_orig_amt, tl.fld_049,
		tl.fld_041, tl.fld_042, tl.suspect_cause, tl.fld_038, tl.fld_039, tl.fld_031, tl.fld_032, tl.fld_033, tl.fld_037,
		decode(tl.msg_type_in, '1420', 1, '1421', 1, 0) as is_reversal, 'D' as DC_IND
	from
		(
		select
			t.fld_101 as batch_id, t.batch_owner, t.reconcile_date, t.reconcile_cntr,
			t.transact_row, t.fld_011, t.fld_012, t.request_date,
			t.fld_002, t.fld_014, t.msg_type_in, t.fld_003, t.fld_004, t.acq_orig_amt, t.fld_049,
			t.fld_041, t.fld_042, t.suspect_cause, t.fld_038, t.fld_039, t.fld_031, t.fld_032, t.fld_033, t.fld_037
		from acq_transaction_log t
		union all
		select
			t.fld_101 as batch_id, t.batch_owner, t.reconcile_date, t.reconcile_cntr,
			t.transact_row, t.fld_011, t.fld_012, t.request_date,
			t.fld_002, t.fld_014, t.msg_type_in, t.fld_003, t.fld_004, t.acq_orig_amt, t.fld_049,
			t.fld_041, t.fld_042, t.suspect_cause, t.fld_038, t.fld_039, t.fld_031, t.fld_032, t.fld_033, t.fld_037
		from acq_transaction_log_old t
		) tl
		where
			(substr(tl.fld_003, 1, 1) = '0' or substr(tl.fld_003, 1, 1) = '1')
			and
				(
					(substr(tl.msg_type_in, 2, 1) = '2' and substr(tl.fld_039, 1, 1) = '0')
					or
					(tl.msg_type_in IN ('1420', '1421') and substr(tl.fld_039, 1, 1) = '4')
				)
union all
select
		tl.batch_id, tl.batch_owner, tl.reconcile_date, tl.reconcile_cntr,
		tl.transact_row, tl.fld_011, tl.fld_012, tl.request_date,
		tl.fld_002, tl.fld_014, tl.msg_type_in, tl.fld_003, tl.fld_004, tl.acq_orig_amt, tl.fld_049,
		tl.fld_041, tl.fld_042, tl.suspect_cause, tl.fld_038, tl.fld_039, tl.fld_031, tl.fld_032, tl.fld_033, tl.fld_037,
		decode(tl.msg_type_in, '1420', 1, '1421', 1, 0) as is_reversal, 'C' as DC_IND
	from
		(
		select
			t.fld_101 as batch_id, t.batch_owner, t.reconcile_date, t.reconcile_cntr,
			t.transact_row, t.fld_011, t.fld_012, t.request_date,
			t.fld_002, t.fld_014, t.msg_type_in, t.fld_003, t.fld_004, t.acq_orig_amt, t.fld_049,
			t.fld_041, t.fld_042, t.suspect_cause, t.fld_038, t.fld_039, t.fld_031, t.fld_032, t.fld_033, t.fld_037
		from acq_transaction_log t
		union all
		select
			t.fld_101 as batch_id, t.batch_owner, t.reconcile_date, t.reconcile_cntr,
			t.transact_row, t.fld_011, t.fld_012, t.request_date,
			t.fld_002, t.fld_014, t.msg_type_in, t.fld_003, t.fld_004, t.acq_orig_amt, t.fld_049,
			t.fld_041, t.fld_042, t.suspect_cause, t.fld_038, t.fld_039, t.fld_031, t.fld_032, t.fld_033, t.fld_037
		from acq_transaction_log_old t
		) tl
		where
			substr(tl.fld_003, 1, 1) = '2'
			and
				(
					(substr(tl.msg_type_in, 2, 1) = '2' and substr(tl.fld_039, 1, 1) = '0')
					or
					(tl.msg_type_in IN ('1420', '1421') and substr(tl.fld_039, 1, 1) = '4')
				)
)
where fld_049 = c.curr_num
order by dc_ind, c.curr_alpha, is_reversal, transact_row
/

