create function fld126_join_tlv (
      tlv_auth varchar2 default ''
    , tlv_tran varchar2 default ''
) return varchar2
is
    tlv_res varchar2(4000);
    tag_t char(4);
    len_a number;
    len_t number;
    pos_a number;
    pos_t number;
    has_found boolean;
begin
    tlv_res := tlv_auth;
    pos_t := 0;
    while pos_t + 7 < length(tlv_tran) loop
        tag_t := substr(tlv_tran, pos_t + 1, 4);
        len_t := to_number(substr(tlv_tran, pos_t + 5, 3));
        pos_a := 0;
        has_found := false;
        while pos_a + 7 < length(tlv_res) loop
            len_a := to_number(substr(tlv_res, pos_a + 5, 3));
            if tag_t = substr(tlv_res, pos_a + 1, 4) then
                if tag_t in ('DCCD', 'DCCE') then
                    tlv_res :=    substr(tlv_res, 1, pos_a)
                               || tag_t || lpad(to_char(len_t), 3, '0') || substr(tlv_tran, pos_t + 8, len_t)
                               || substr(tlv_res, pos_a + 8 + len_a);
                end if;
                has_found := true;
                exit;
            end if;
            pos_a := pos_a + 7 + len_a;
        end loop;
        if not has_found then
            tlv_res :=    tlv_res
                       || tag_t || lpad(to_char(len_t), 3, '0') || substr(tlv_tran, pos_t + 8, len_t);
        end if;
        pos_t := pos_t + 7 + len_t;
    end loop;
    return tlv_res;
end fld126_join_tlv;
/

