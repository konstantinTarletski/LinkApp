create FUNCTION MASK_PARAM_VAL (params IN varchar2, paramname IN varchar2, delim IN varchar2 DEFAULT '|', eqchar IN varchar2 DEFAULT '=')
/*
 * DESCRIPTION
 *
 * Masks the value of a parameter 'paramname' within string of parameter-value
 * pairs 'params'. Return paramters string with masked value.
 * Parameter-value pairs are delimited with string 'delim'.
 * Parameter and it's value are separated with string 'eqchar'.
 * There must be no whitespaces between parameter name and 'eqchar'.
 * The returned param value is stripped of leading and trailing spaces.
 *
 *
 * EXAMPLE USAGE
 *
 *   mask_param_val('fruit=  orange |vegetable=cabbage|pan=1234567890123456789', 'fruit', '|', '=')
 * will return string 'fruit=  orange |vegetable=cabbage|pan=123456*********6789'.
 */
RETURN varchar2 IS
    sval varchar2 (512);
    sval_len int;
BEGIN

    sval:= extract_param_val(params,paramname,delim,eqchar);
    if sval = NULL then
        return params;
    end if;

    sval_len := LENGTH(sval);

    return REPLACE(params,sval,SUBSTR(sval,1,6)||lpad('*',sval_len-10,'*')||SUBSTR(sval,sval_len-3));
END;
/

