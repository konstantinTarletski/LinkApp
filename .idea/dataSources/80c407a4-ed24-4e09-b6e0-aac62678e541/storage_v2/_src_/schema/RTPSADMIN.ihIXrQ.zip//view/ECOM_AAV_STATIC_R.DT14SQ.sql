create view ECOM_AAV_STATIC_R as
select
		x.reg_date,
		x.reg_row_numb,
		x.centre_id,
		x.static_aav,
		x.merchant_id_epi,
		x.merchant_id_msg,
		x.acq_id_msg,
		x.aav_mode,
		x.rec_id,
		x.step_count,
		x.deleted
	from ECOM_AAV_STATIC x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

