create view STIP_SERVICES_R as
select
		x.service_type,
		x.service_name,
		x.description
	from STIP_SERVICES x
/

