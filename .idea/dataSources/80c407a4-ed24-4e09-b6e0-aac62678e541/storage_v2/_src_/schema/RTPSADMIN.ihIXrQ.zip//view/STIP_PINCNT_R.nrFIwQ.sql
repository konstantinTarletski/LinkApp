create view STIP_PINCNT_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.card_number,
		x.update_date,
		x.pinfail_count,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_PINCNT x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

