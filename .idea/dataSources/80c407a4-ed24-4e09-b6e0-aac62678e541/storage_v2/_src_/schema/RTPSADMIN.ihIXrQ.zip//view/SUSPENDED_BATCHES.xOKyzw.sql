create view SUSPENDED_BATCHES as
SELECT
  b.batch_owner, b.reconcile_date, b.reconcile_cntr,
  b.batch_id, b.update_date, b.complete_row, b.complete_task,
  b.process_task, b.centre_id, b.merchant_id, b.terminal_id,
	'T' del_enable,comp.request_date closing_date,
  nvl(f_074,0) f_074, nvl(f_075,0) f_075, nvl(f_076,0) f_076, nvl(f_077,0) f_077,
  nvl(f_078,0) f_078, nvl(f_079,0) f_079, nvl(f_080,0) f_080, nvl(f_081,0) f_081,
  nvl(f_082,0) f_082, nvl(f_083,0) f_083, nvl(f_084,0) f_084,
  nvl(f_086,0.0) f_086, nvl(f_087,0.0) f_087, nvl(f_088,0.0) f_088, nvl(f_089,0.0) f_089, nvl(f_090,0.0) f_090,
  nvl(f_105,0.0) f_105, nvl(f_106,0.0) f_106, nvl(f_107,0.0) f_107, nvl(f_108,0.0) f_108,
  nvl(f_074+f_075+f_076+f_077+f_078+f_079+f_080+f_081+f_082+f_083+f_084+f_090+f_107+f_108,0) tot_count,
  nvl(f_086+f_087+f_105-f_088-f_089-f_106,0.0) tot_amount
FROM
acq_reconcilation_log comp, batches_log b, (
				SELECT batch_owner,reconcile_date,reconcile_cntr
					,sum(decode(MSG_CLASS+TRN,2002,1,0)) F_074
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4020,1,4021,1,0)) F_075
					,sum(decode(MSG_CLASS+TRN,2000,1,2001,1,0)) F_076
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4022,1,0)) F_077
					,sum(decode(MSG_CLASS+TRN,2004,1,0)) F_078
					,sum(decode(MSG_CLASS+TRN,4004,1,0)) F_079
					,sum(decode(MSG_CLASS+TRN,1003,1,0)) F_080
					,sum(decode(MSG_CLASS+TRN,1000,1,1001,1,0)) F_081
					,sum(decode(MSG_CLASS+TRN,4003,1,0)) F_082
					,sum(decode(MSG_CLASS+TRN,2005,1,0)) F_083
					,sum(decode(MSG_CLASS+TRN,4005,1,0)) F_084
					,sum(decode(MSG_CLASS,7000,1,0)) F_085
					,sum(decode(MSG_CLASS+TRN,2002,fld_004,0)) F_086
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4020,fld_004,4021,fld_004,4025,fld_004,0)) F_087
					,sum(decode(MSG_CLASS+TRN,2000,fld_004,2001,fld_004,2005,fld_004,0)) F_088
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4022,fld_004,0)) F_089
					,sum(decode(MSG_CLASS+TRN,4010,1,4011,1,0)) F_090
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+TRN,4200,fld_004,4201,fld_004,0)) F_105
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+TRN,4202,fld_004,0)) F_106
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4220,fld_004,4221,fld_004,0)) F_107
					,sum(decode(MSG_CLASS+TRN_ORIGINATOR+ORIG_MSG_CLASS+TRN,4222,fld_004,0)) F_108
				FROM
					(SELECT	/*+ RULE */
						b.batch_owner,b.reconcile_date,b.reconcile_cntr
						,to_number(substr(M.MSG_TYPE_IN,2,1))*1000 MSG_CLASS
						,to_number(decode(substr(M.MSG_TYPE_IN,4,1), 1, 0, substr(M.MSG_TYPE_IN,4,1)))*100 TRN_ORIGINATOR
						,nvl(to_number(substr(M.FLD_056A,2,1))*10,0) ORIG_MSG_CLASS
						,nvl(to_number(substr(M.FLD_003,1,1)),0) TRN
						,m.fld_004
					FROM ACQ_TRANSACTION_LOG M, batches_log B
					WHERE  M.BATCH_OWNER=b.batch_owner
						AND M.RECONCILE_DATE=b.reconcile_date
						AND M.RECONCILE_CNTR=b.reconcile_cntr
						AND (M.fld_039 like '0%' OR M.fld_039 like '4%')
						and  B.process_flag='F' and B.complete_flag='T' and B.suspend_flag='T'
					UNION ALL
					SELECT /*+ RULE */
						b.batch_owner,b.reconcile_date,b.reconcile_cntr
						,to_number(substr(M.MSG_TYPE_IN,2,1))*1000 MSG_CLASS
						,to_number(decode(substr(M.MSG_TYPE_IN,4,1), 1, 0, substr(M.MSG_TYPE_IN,4,1)))*100 TRN_ORIGINATOR
						,nvl(to_number(substr(M.FLD_056A,2,1))*10,0) ORIG_MSG_CLASS
						,nvl(to_number(substr(M.FLD_003,1,1)),0) TRN
						,m.fld_004
					FROM ACQ_AUTHORISATION_LOG M, batches_log B
					WHERE  M.BATCH_OWNER=b.batch_owner
						AND M.RECONCILE_DATE=b.reconcile_date
						AND M.RECONCILE_CNTR=b.reconcile_cntr
						AND (M.fld_039 like '0%' OR M.fld_039 like '4%')
						AND  B.process_flag='F' AND B.complete_flag='T' AND B.suspend_flag='T'
					) GROUP BY batch_owner,reconcile_date,reconcile_cntr
					) M
WHERE B.complete_row=comp.row_numb (+)
AND (B.batch_owner=M.batch_owner (+)
AND B.reconcile_date=M.reconcile_date (+)
AND B.reconcile_cntr=M.reconcile_cntr (+) )
AND B.process_flag='F' and B.complete_flag='T' AND B.suspend_flag='T'
/

