create view STIP_LOCKS_R as
select
		x.row_numb,
		x.centre_id,
		x.account_id,
		x.amount,
		x.ccy,
		x.request_date,
		x.lock_id,
		x.lock_type,
		x.rec_id,
		x.step_count,
		x.deleted,
		x.sync_tmst
	from STIP_LOCKS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

