create PROCEDURE           partorg_drop_keys(key VARCHAR2) IS
    key_list VARCHAR2(64);
    TABLE_DOES_NOT_EXIST EXCEPTION;
    PRAGMA EXCEPTION_INIT (TABLE_DOES_NOT_EXIST, -942);
BEGIN
    key_list := 'partorg_preserve_keys';

    EXECUTE IMMEDIATE 'DROP TABLE ' || key_list;
EXCEPTION
    WHEN TABLE_DOES_NOT_EXIST THEN NULL;
END;
/

