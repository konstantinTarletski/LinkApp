create view STIP_CONTRA_ACNT_GRP_R as
select
		x.acnt_grp,
		x.abbreviature,
		x.description
	from STIP_CONTRA_ACNT_GRP x
/

