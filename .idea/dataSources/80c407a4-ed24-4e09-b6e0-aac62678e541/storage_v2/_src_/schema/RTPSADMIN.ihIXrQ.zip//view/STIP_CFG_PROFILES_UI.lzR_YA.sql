create view STIP_CFG_PROFILES_UI as
select
	a.profile_id,
	a.profile_name,
	a.profile_description
from
	stip_cfg_profiles a
/

comment on column STIP_CFG_PROFILES_UI.PROFILE_ID is 'Profile identification number'
/

comment on column STIP_CFG_PROFILES_UI.PROFILE_NAME is 'Profile name'
/

comment on column STIP_CFG_PROFILES_UI.PROFILE_DESCRIPTION is 'Profile description'
/

