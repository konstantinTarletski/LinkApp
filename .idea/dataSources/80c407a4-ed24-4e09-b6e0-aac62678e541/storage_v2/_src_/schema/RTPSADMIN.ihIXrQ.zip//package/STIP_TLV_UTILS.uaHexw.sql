create Package
/* $HeadURL$ $Id$ */
stip_tlv_utils IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	FUNCTION GetFromTLV(
		p_tlv VARCHAR2,
		p_tag VARCHAR2
	)RETURN VARCHAR2;

	FUNCTION AddToTLV(
		p_tlv IN OUT VARCHAR2,
		p_tag VARCHAR2,
		p_val VARCHAR2
	)RETURN BOOLEAN;
END;
/*= History =============================================================
 * $Log: stip_tlv_utils-package.sql,v $
 * Revision 1.2  2007/11/30 11:33:25  liukiagn
 * changed data type in function declaration
 *
 * Revision 1.1  2007/10/01 07:47:39  liukiagn
 * added to cvs - functions for tlv
 *
 ========================================================================*/
/

