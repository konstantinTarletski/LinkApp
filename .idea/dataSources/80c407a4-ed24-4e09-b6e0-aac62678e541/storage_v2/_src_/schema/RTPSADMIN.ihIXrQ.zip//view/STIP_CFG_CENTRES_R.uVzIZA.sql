create view STIP_CFG_CENTRES_R as
select
		a.centre_id,
		a.prefix_id,
		b.profile_id,
		b.profile_name,
		b.profile_description,
		c.rule_id,
		c.priority,
		c.rule_expression,
		c.name_DB,
		c.name_user,
		c.processing_state
	from
		stip_cfg_centres a,
		stip_cfg_profiles b,
		stip_cfg_prules c
	where
		a.profile_id=b.profile_id and
		b.profile_id=c.profile_id and
		exists (select null
					from
						centre_users cu
					where
						cu.centre_id=a.centre_id and
						cu.username = user)
/

comment on column STIP_CFG_CENTRES_R.CENTRE_ID is 'Data owner processing entity identifier'
/

comment on column STIP_CFG_CENTRES_R.PREFIX_ID is 'Prefix record number'
/

comment on column STIP_CFG_CENTRES_R.PROFILE_ID is 'Profile identification number'
/

comment on column STIP_CFG_CENTRES_R.PROFILE_NAME is 'Profile name'
/

comment on column STIP_CFG_CENTRES_R.PROFILE_DESCRIPTION is 'Profile description'
/

comment on column STIP_CFG_CENTRES_R.RULE_ID is 'Rule identification number'
/

comment on column STIP_CFG_CENTRES_R.PRIORITY is 'Rule priority'
/

comment on column STIP_CFG_CENTRES_R.RULE_EXPRESSION is 'Rule expression'
/

comment on column STIP_CFG_CENTRES_R.NAME_DB is 'Unique name for DB'
/

comment on column STIP_CFG_CENTRES_R.NAME_USER is 'Name for user interface components'
/

comment on column STIP_CFG_CENTRES_R.PROCESSING_STATE is 'Rule processing state'
/

