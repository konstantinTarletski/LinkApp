create Function
/* $HeadURL$ $Id$ */
BATCH_TOT_SIGN (msg_type char, fld_056A char, fld_003_sub char,field char) RETURN  binary_integer is
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
BEGIN
	if substr(msg_type,2,1)='1' then
		if fld_003_sub between '00' and '29' then
			if field='081' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '30' and '39' then
			if field='080' then
				return 1;
			end if;
			return 0;
		end if;
		return null;
	elsif substr(msg_type,2,1)='2' then
		if fld_003_sub between '00' and '19' then
			if field='076' or field='088' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '20' and '29' then
			if field='074' or field='086' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '30' and '39' then
			if field='080' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '40' and '49' then
			if field='078' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '50' and '59' then
			if field='083' then
				return 1;
			end if;
			return 0;
		end if;
		return null;
	elsif substr(msg_type,2,1)='4' then
		if substr(msg_type,4,1)='0' and substr(fld_056a,2,1)='2' then
			if fld_003_sub between '00' and '19' then
				if field='075' or field='087' then
					return 1;
				end if;
				return 0;
			elsif  fld_003_sub between '20' and '29' then
				if field='077' or field='089' then
					return 1;
				end if;
				return 0;
			end if;
		elsif substr(msg_type,4,1)='2' and substr(fld_056a,2,1)='2' then
			if fld_003_sub between '00' and '19' then
				if field='107' or field='105' then
					return 1;
				end if;
				return 0;
			elsif  fld_003_sub between '20' and '29' then
				if field='108' or field='106' then
					return 1;
				end if;
				return 0;
			end if;
		end if;
		if fld_003_sub between '00' and '29' then
			if field='090' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '30' and '39' then
			if field='082' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '40' and '49' then
			if field='079' then
				return 1;
			end if;
			return 0;
		elsif  fld_003_sub between '50' and '59' then
			if field='084' then
				return 1;
			end if;
			return 0;
		end if;
		return null;
	end if;
    RETURN null;
END;
/*= History =============================================================
 * $Log: batch_tot_sign-function.sql,v $
 * Revision 1.6  2002/10/31 15:25:03  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.5  2000/10/02 08:38:13  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.4  1999/09/23 01:33:53  uldis
 * Dar'ijumu uzkr'a'san'a ori'gin'al'as autoriz'acijas mekl'e'sanas algoritms
 * implement'ets ar neirona pal'idz'ibu.
 *
 * Revision 1.3  1999/07/15 20:50:47  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.2  1999/01/22 17:40:29  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:11  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

