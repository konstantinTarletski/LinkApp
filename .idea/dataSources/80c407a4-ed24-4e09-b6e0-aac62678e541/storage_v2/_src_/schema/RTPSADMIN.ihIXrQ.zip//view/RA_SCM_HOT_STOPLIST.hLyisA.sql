create view RA_SCM_HOT_STOPLIST as
SELECT card_type,
	centre_id,
	effective_date,
	update_date,
	card_number,
	action_code,
	description
FROM cards_exceptions
/

comment on column RA_SCM_HOT_STOPLIST.CARD_TYPE is 'Card type code'
/

comment on column RA_SCM_HOT_STOPLIST.CENTRE_ID is 'Data source processing entity identifier'
/

comment on column RA_SCM_HOT_STOPLIST.EFFECTIVE_DATE is 'Record effective date and time'
/

comment on column RA_SCM_HOT_STOPLIST.UPDATE_DATE is 'Record update date and time'
/

comment on column RA_SCM_HOT_STOPLIST.CARD_NUMBER is 'Card number'
/

comment on column RA_SCM_HOT_STOPLIST.ACTION_CODE is 'Response action code'
/

comment on column RA_SCM_HOT_STOPLIST.DESCRIPTION is 'Record insertion reason description'
/

