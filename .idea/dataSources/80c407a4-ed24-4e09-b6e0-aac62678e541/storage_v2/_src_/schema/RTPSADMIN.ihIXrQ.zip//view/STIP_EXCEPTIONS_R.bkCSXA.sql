create view STIP_EXCEPTIONS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.param_grp,
		x.priority,
		x.rule_expr,
		x.action_code,
		x.description
	from STIP_EXCEPTIONS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

