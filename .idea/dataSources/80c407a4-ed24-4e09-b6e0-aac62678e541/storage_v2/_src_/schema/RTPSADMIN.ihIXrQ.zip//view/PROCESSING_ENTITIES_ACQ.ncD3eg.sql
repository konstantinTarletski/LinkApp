create view PROCESSING_ENTITIES_ACQ as
SELECT
     PROC_ENT.CENTRE_ID
    ,PROC_ENT.PROCESS_FLAG
FROM
    processing_entities  proc_ent
/

comment on column PROCESSING_ENTITIES_ACQ.CENTRE_ID is 'Processing entity identifier'
/

comment on column PROCESSING_ENTITIES_ACQ.PROCESS_FLAG is 'Transaction data processing enable flag'
/

