create PACKAGE
/* $HeadURL$ $Id$ */
TINP_OUT
IS
/* $HeadURL$ $Id$ */


---
PROCEDURE tinp_out
(p_hist_numb  INTEGER   DEFAULT NULL
,p_centre_id  VARCHAR2  DEFAULT NULL
);

---
FUNCTION tinp_delivery
(p_hist_numb  INTEGER   DEFAULT NULL
,p_centre_id  VARCHAR2  DEFAULT NULL
)
RETURN BOOLEAN
;
PROCEDURE tinp_delivery
(p_hist_numb  INTEGER   DEFAULT NULL
,p_centre_id  VARCHAR2  DEFAULT NULL
);

---
FUNCTION tinp_archiving
(p_hist_numb  INTEGER  DEFAULT NULL
)
RETURN BOOLEAN
;
PROCEDURE tinp_archiving
(p_hist_numb  INTEGER  DEFAULT NULL
);

---
PROCEDURE tinp_monitor
(hist_numb  INTEGER  DEFAULT NULL
);

PROCEDURE tinp_closeup_merchant
(p_mrch_numb VARCHAR2 DEFAULT NULL
,p_hist_numb  INTEGER  DEFAULT NULL
);

END;
/

