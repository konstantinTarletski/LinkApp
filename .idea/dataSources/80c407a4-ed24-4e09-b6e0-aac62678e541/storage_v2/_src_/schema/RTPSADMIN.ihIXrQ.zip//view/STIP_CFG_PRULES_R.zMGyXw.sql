create view STIP_CFG_PRULES_R as
select
		a.rule_id,
		a.profile_id,
		a.priority,
		a.rule_expression,
		a.name_DB,
		a.name_user,
		a.processing_state,
		b.cfg_parameter_name,
		b.cfg_parameter_value
	from
		stip_cfg_prules a,
		stip_cfg_pvalues b
	where
		a.rule_id=b.rule_id
/

comment on column STIP_CFG_PRULES_R.RULE_ID is 'Rule identification number'
/

comment on column STIP_CFG_PRULES_R.PROFILE_ID is 'Profile identification number'
/

comment on column STIP_CFG_PRULES_R.PRIORITY is 'Rule priority'
/

comment on column STIP_CFG_PRULES_R.RULE_EXPRESSION is 'Rule expression'
/

comment on column STIP_CFG_PRULES_R.NAME_DB is 'Unique name for DB'
/

comment on column STIP_CFG_PRULES_R.NAME_USER is 'Name for user interface components'
/

comment on column STIP_CFG_PRULES_R.PROCESSING_STATE is 'Rule processing state'
/

comment on column STIP_CFG_PRULES_R.CFG_PARAMETER_NAME is 'Configuration parameter name'
/

comment on column STIP_CFG_PRULES_R.CFG_PARAMETER_VALUE is 'Configuration parameter value'
/

