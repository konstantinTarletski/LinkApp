create view RA_ACQ_MERCHANTS as
SELECT MERCHANT_ID,
	MERCHANT_NAME,
	MERCHANT_CITY,
	MERCHANT_STREET,
	MERCHANT_PHONE,
	COUNTRY_ALPHA,
	MCC_CODE,
	MERCHANT_ADDR,
	CAPTURE_FLAG,
	POST_INDEX,
	TAX_ID,
	TAX_ID_TYPE
FROM CARD_MERCHANTS
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_ID is 'Merchant identifier'
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_NAME is 'Merchant name'
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_CITY is 'Merchant location city'
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_STREET is 'Merchant location street'
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_PHONE is 'Merchant phone'
/

comment on column RA_ACQ_MERCHANTS.COUNTRY_ALPHA is 'Merchant location alphabetic country code'
/

comment on column RA_ACQ_MERCHANTS.MCC_CODE is 'Merchant business cathegory code'
/

comment on column RA_ACQ_MERCHANTS.MERCHANT_ADDR is 'Merchant location address'
/

comment on column RA_ACQ_MERCHANTS.CAPTURE_FLAG is 'Transactions information capture activation flag'
/

comment on column RA_ACQ_MERCHANTS.POST_INDEX is 'Postal Index'
/

comment on column RA_ACQ_MERCHANTS.TAX_ID is 'Merchant Tax ID'
/

comment on column RA_ACQ_MERCHANTS.TAX_ID_TYPE is 'Merchant Tax ID Type'
/

