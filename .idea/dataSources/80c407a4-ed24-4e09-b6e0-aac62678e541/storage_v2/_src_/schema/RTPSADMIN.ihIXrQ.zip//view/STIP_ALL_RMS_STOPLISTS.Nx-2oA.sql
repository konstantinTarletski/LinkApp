create view STIP_ALL_RMS_STOPLISTS as
select	s.centre_id,
		s.card_number,
		s.priority,
		s.effective_date,
		s.update_date,
		s.purge_date,
		s.action_code,
		s.rule_expr,
		s.description
	from
		stip_rms_stoplist s
/*union all
select	z.centre_id,
		z.card_number,
		z.priority
		z.effective_date,
		z.update_date,
		z.purge_date,
		z.action_code,
		z.rule_expr,
		z.description
	from
		stip_rms_stoplist_snap1 z*/
/

comment on column STIP_ALL_RMS_STOPLISTS.CENTRE_ID is 'Data owner processing entity.'
/

comment on column STIP_ALL_RMS_STOPLISTS.CARD_NUMBER is 'Card number.'
/

comment on column STIP_ALL_RMS_STOPLISTS.PRIORITY is 'Card number.'
/

comment on column STIP_ALL_RMS_STOPLISTS.EFFECTIVE_DATE is 'Effective date'
/

comment on column STIP_ALL_RMS_STOPLISTS.UPDATE_DATE is 'Update date'
/

comment on column STIP_ALL_RMS_STOPLISTS.PURGE_DATE is 'Purge date'
/

comment on column STIP_ALL_RMS_STOPLISTS.ACTION_CODE is 'Response action code.'
/

comment on column STIP_ALL_RMS_STOPLISTS.RULE_EXPR is 'Rule expression. In true case of it response action will be returned.'
/

comment on column STIP_ALL_RMS_STOPLISTS.DESCRIPTION is 'Record insertion reason description.'
/

