create PROCEDURE           partorg_split_table_partition(p_table_name VARCHAR2, p_partition_name VARCHAR2, p_partition_name_new VARCHAR2, p_at VARCHAR2) IS
BEGIN
    BEGIN
        EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table_name
        || ' SPLIT PARTITION ' || p_partition_name
        || ' AT (' || p_at || ') INTO (PARTITION ' || p_partition_name_new
        || ', PARTITION ' || p_partition_name || ') UPDATE INDEXES';
    EXCEPTION WHEN OTHERS THEN
        -- ORA-25182: feature not currently available for index-organized tables
        IF SQLCODE NOT IN (-25182) THEN
            RAISE;
        END IF;
        EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table_name
        || ' SPLIT PARTITION ' || p_partition_name
        || ' AT (' || p_at || ') INTO (PARTITION ' || p_partition_name_new
        || ', PARTITION ' || p_partition_name || ') UPDATE GLOBAL INDEXES';
    END;
END;
/

