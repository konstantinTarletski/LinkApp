create view STIP_CARD_ACCOUNTS_V2 as
SELECT
		a.centre_id AS a_centre_id,
		a.effective_date AS a_effective_date,
		a.update_date AS a_update_date,
		a.crd_holdr_id AS a_crd_holdr_id,
		a.account_type AS a_account_type,
		a.account_id AS a_account_id,
		a.account_ccy AS a_account_ccy,
		a.initial_amount AS a_initial_amount,
		a.bonus_amount AS a_bonus_amount,
		a.account_id_bank AS a_account_id_bank,
		a.add_info AS a_add_info,
		a.credit_limit AS a_credit_limit,
		a.lock_time AS a_lock_time,
		a.lock_amount_cms AS a_lock_amount_cms,
		a.amount_set_time AS a_amount_set_time,
		a.comm_grp AS a_comm_grp,
		a.shadow_amount AS a_shadow_amount,
		a.time_stamp AS a_time_stamp,
		a.priority AS a_priority,
		a.status AS a_status,
		a.credit_limit_expiry AS a_credit_limit_expiry,
		a.bonus_amount_expiry AS a_bonus_amount_expiry,
		a.lock_amount_cms_ofl AS a_lock_amount_cms_ofl,
		a.offline_locked AS a_offline_locked,
		a.offline_cleared AS a_offline_cleared,
		c.centre_id AS c_centre_id,
		c.effective_date AS c_effective_date,
		c.update_date AS c_update_date,
		c.pref_rec_num AS c_pref_rec_num,
		c.card_number AS c_card_number,
		c.crd_holdr_id AS c_crd_holdr_id,
		c.crd_holdr_name AS c_crd_holdr_name,
		c.crd_holdr_pwd AS c_crd_holdr_pwd,
		c.crd_holdr_msg AS c_crd_holdr_msg,
		c.param_grp_1 AS c_param_grp_1,
		c.param_grp_2 AS c_param_grp_2,
		c.acnt_restr AS c_acnt_restr,
		c.avlamnt_flag AS c_avlamnt_flag,
		c.stat_code_1 AS c_stat_code_1,
		c.stat_code_2 AS c_stat_code_2,
		c.expiry_date_1 AS c_expiry_date_1,
		c.expiry_date_2 AS c_expiry_date_2,
		c.cvc_stripe_1 AS c_cvc_stripe_1,
		c.cvc_stripe_2 AS c_cvc_stripe_2,
		c.cvc_print_1 AS c_cvc_print_1,
		c.cvc_print_2 AS c_cvc_print_2,
		c.pvv_code_1 AS c_pvv_code_1,
		c.pvv_code_2 AS c_pvv_code_2,
		c.pvv_count_1 AS c_pvv_count_1,
		c.pvv_count_2 AS c_pvv_count_2,
		c.track_1_1 AS c_track_1_1,
		c.track_1_2 AS c_track_1_2,
		c.track_2_1 AS c_track_2_1,
		c.track_2_2 AS c_track_2_2,
		c.comm_grp  AS c_comm_grp ,
		c.pvv_code_1_chg AS c_pvv_code_1_chg,
		c.pvv_code_2_chg AS c_pvv_code_2_chg,
		c.pvv_code_1_date AS c_pvv_code_1_date,
		c.pvv_code_2_date AS c_pvv_code_2_date,
		c.pvv_code_1_prv AS c_pvv_code_1_prv,
		c.pvv_code_2_prv AS c_pvv_code_2_prv,
		c.add_info  AS c_add_info ,
		c.card_seq_1 AS c_card_seq_1,
		c.card_seq_2 AS c_card_seq_2,
		c.pki_1 AS c_pki_1,
		c.pki_2 AS c_pki_2,
		c.dki_1 AS c_dki_1,
		c.dki_2 AS c_dki_2,
		c.app_id AS c_app_id,
		c.offl_limit_1 AS c_offl_limit_1,
		c.offl_limit_2 AS c_offl_limit_2,
		c.offl_limit_ctrl AS c_offl_limit_ctrl,
		c.client_id AS c_client_id,
		c.pvv_count_1_chg AS c_pvv_count_1_chg,
		c.pvv_count_2_chg AS c_pvv_count_2_chg,
		c.pvv_code_1_alg AS c_pvv_code_1_alg,
		c.pvv_code_2_alg AS c_pvv_code_2_alg
	FROM
		stip_cards c INNER JOIN stip_accounts a
		ON c.centre_id = a.centre_id AND c.crd_holdr_id = a.crd_holdr_id
	WHERE
		(
			(c.acnt_restr = 'N') OR (
				(c.acnt_restr = 'E') AND EXISTS (
					SELECT 'X'
						FROM stip_restracnt r
						where
							r.centre_id = a.centre_id AND
							r.account_id = a.account_id AND
							r.card_number = c.card_number
				)
			) OR (
				(c.acnt_restr = 'I') AND NOT EXISTS (
					SELECT 'X'
						FROM stip_restracnt r
						WHERE
							r.centre_id = a.centre_id AND
							r.account_id = a.account_id AND
							r.card_number = c.card_number
				)
			)
		)
	with check option
/

