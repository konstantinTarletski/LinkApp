create PROCEDURE           partorg_create_keys(key VARCHAR2, stmt VARCHAR2) IS
    key_list VARCHAR2(64);
BEGIN
    partorg_drop_keys(key);
    key_list := 'partorg_preserve_keys';

    EXECUTE IMMEDIATE 'CREATE TABLE ' || key_list
    || ' (' || key || ', CONSTRAINT ' || key_list || '_pk PRIMARY KEY(' || key || '))'
    || ' ORGANIZATION INDEX AS '
    || stmt;

    IF UPPER('RTPSADMIN')<>UPPER('CSAPP') THEN
        EXECUTE IMMEDIATE 'GRANT SELECT ON ' || key_list || ' TO CSAPP';
    END IF;
END;
/

