create Package
/* $HeadURL$ $Id$ */
stip_xch_COMMON IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	hist_numb	integer;
	centre_id	varchar2(11);
	effective_date	date;
	LONG_ROLLBACK_SEGMENT	varchar(30):=null;
	the_errorlog_err_count	integer:=0;
	TYPE qfile IS RECORD (hist_numb stip_import.hist_numb%TYPE,
							centre_id stip_import.centre_id%TYPE,
							effective_date stip_import.effective_date%TYPE);
	procedure MSG(error_num integer,msg varchar2);
	procedure MSG_C(error_num integer,hist_numb in varchar2,centre_id in varchar2,effective_date in varchar2,msg varchar2);
	procedure set_long_rollback(arg boolean:=false);
	procedure add(table_name varchar2,are char,tobe char,
					delta binary_integer,full_flag boolean:=false);
	procedure set_tran_unlocking_state(
			p_centre_id in varchar2,
			p_tran_id in varchar2,
			p_unlocking_state in varchar2,
			p_commit in boolean default false);
	procedure set_tran_unlocking_state(
			p_tran_rowid in rowid,
			p_unlocking_state in varchar2,
			p_commit in boolean default false);
	function ExtractTid(centre_id in varchar2, fld_095 in varchar2) return varchar2;
END;
/*= History =============================================================
 * $Log: stip_xch_common-package.sql,v $
 * Revision 1.9  2002/12/16 17:25:25  vilis
 * Removed duplicated error codes from logs
 *
 * Revision 1.7  2002/10/31 15:26:11  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.6  2000/10/02 08:38:03  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.5  2000/01/11 12:37:29  uldis
 * Modu'la zars XCH_NEW pievienots pamatzaram
 *
 * Revision 1.4.2.2  1999/09/07 20:58:55  uldis
 * P'arrakst'ita progresa indik'acija. Katra centra pilnai apstr'adei tagat
 * tiek lietots tie'si viens progresa indikatora cikls.
 *
 * Revision 1.4  1999/07/15 20:50:08  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/02/24 12:52:28  karlis
 * Izmainnas UNLOCK algoritmaa, lai tiktu meegginaats atkaartoti kviteet
 * tranzakcijas, kas nav nokviteejussaas ar pirmo piegaajienu.
 *
 * Revision 1.2  1999/01/22 17:39:47  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:00  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

