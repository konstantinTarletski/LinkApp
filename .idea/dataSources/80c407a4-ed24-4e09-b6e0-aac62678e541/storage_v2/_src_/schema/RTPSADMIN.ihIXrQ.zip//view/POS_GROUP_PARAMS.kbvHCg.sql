create view POS_GROUP_PARAMS as
SELECT
     T.TEMPLATE_NAME
    ,T.FIELD_ID
    ,T.FIELD_DATA
FROM
    terminal_datatempl  t
/

