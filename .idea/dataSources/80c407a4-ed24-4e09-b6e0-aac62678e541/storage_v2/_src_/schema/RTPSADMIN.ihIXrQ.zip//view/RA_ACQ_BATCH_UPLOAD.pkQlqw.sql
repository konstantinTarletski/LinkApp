create view RA_ACQ_BATCH_UPLOAD as
SELECT batch_id,
	batch_owner,
	reconcile_date,
	reconcile_cntr,
	centre_id,
	merchant_id,
	terminal_id,
	reset_count,
	call_date,
	svc_result_code,
	svc_result_text
FROM BATCH_UPLOAD
/

comment on column RA_ACQ_BATCH_UPLOAD.BATCH_ID is 'Batch Identifier'
/

comment on column RA_ACQ_BATCH_UPLOAD.BATCH_OWNER is 'Batch owner entity (centre, merchant or terminal) identifier'
/

comment on column RA_ACQ_BATCH_UPLOAD.RECONCILE_DATE is 'Batch reconciliation date'
/

comment on column RA_ACQ_BATCH_UPLOAD.RECONCILE_CNTR is 'Batch reconciliation counter within single date'
/

comment on column RA_ACQ_BATCH_UPLOAD.CENTRE_ID is 'Batch owner card processing centre identifier'
/

comment on column RA_ACQ_BATCH_UPLOAD.MERCHANT_ID is 'Batch owner merchant identifier'
/

comment on column RA_ACQ_BATCH_UPLOAD.TERMINAL_ID is 'Batch owner terminal identifier'
/

comment on column RA_ACQ_BATCH_UPLOAD.RESET_COUNT is 'POS Batch upload counter'
/

comment on column RA_ACQ_BATCH_UPLOAD.CALL_DATE is 'POS Batch upload date'
/

comment on column RA_ACQ_BATCH_UPLOAD.SVC_RESULT_CODE is 'POS Batch upload call result code -1 error, 0 OK, 1 maximum'
/

comment on column RA_ACQ_BATCH_UPLOAD.SVC_RESULT_TEXT is 'POS Batch upload error text'
/

