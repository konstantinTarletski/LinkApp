create FUNCTION ecomm_status(result_ecomm VARCHAR2, status_ebpp NUMBER, action_code VARCHAR2) RETURN VARCHAR2
    IS
     BEGIN
       IF BITAND(status_ebpp,16384) > 0 THEN
           RETURN 'RETURNED';
       END IF;
       IF BITAND(status_ebpp,4096) > 0 THEN
           RETURN 'FINISHED';
       END IF;
       IF BITAND(status_ebpp,8192) > 0 THEN
           IF result_ecomm = 'TIMEOUT' THEN
               RETURN 'TIMEOUT';
           END IF;
           IF result_ecomm = 'DECLINED' THEN
               RETURN 'DECLINED';
           END IF;
           IF result_ecomm = 'REVERSED' THEN
               RETURN 'REVERSED';
           END IF;
           RETURN 'FAILED';
       END IF;
       IF result_ecomm = 'CREATED' THEN
           RETURN 'CREATED';
       END IF;
       IF action_code = '000' AND (result_ecomm = 'PENDING' OR result_ecomm = 'REVERSED') THEN
           RETURN 'OK_FROM_RTPS';
       END IF;
       IF result_ecomm = 'PENDING' THEN
           RETURN 'OK_CARD_DATA';
       END IF;
       IF result_ecomm = 'REVERSED' THEN
           RETURN 'OK_FROM_RTPS';
       END IF;
       RETURN 'UNKNOWN';
    END;
/

