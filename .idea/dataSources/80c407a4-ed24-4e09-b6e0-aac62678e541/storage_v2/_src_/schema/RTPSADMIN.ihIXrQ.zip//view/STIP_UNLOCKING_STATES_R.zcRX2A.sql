create view STIP_UNLOCKING_STATES_R as
select
		x.unlocking_state,
		x.abbreviature,
		x.description
	from STIP_UNLOCKING_STATES x
/

