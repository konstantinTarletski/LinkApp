create package
/* $HeadURL$ $Id$ */
stip_accum_ccy_convert is
/*#=======================================================================
  #	RTPS.IIA.RECALC
  #		Autorizacijas informaacijas kontrole, atblokkeessana
  #		peec noilguma
  #
  #		Kodeja: Uldis Ansmits
  #		Kodeja: Karlis Ogsts
  #		Kodeja: Janis Kovalevskis
  #
  # $HeadURL$ $Id$
  # (C) Tieto Konts Financial Systems Ltd. 1998-2002
  #========================================================================*/
-- Peedeejaas klluudas teksts
g_ErrorText varchar2(1000):=null;
-- MCC for all the authorizations... long one.
function AccumCcyConvert(p_centre_id varchar2) return boolean;
-- MCC Substractive interval for auth in between two execution times
function AccumCcyConvert_MCC_Subs(p_centre_id varchar2,p_start_date date,p_end_date date) return boolean;
-- MCC For authorizations in selected time perdiod.
function AccumCcyConvertForPeriod(p_centre_id varchar2,p_start_date date,p_end_date date) return boolean;
-- TUXEDO for all the authorizations... long one.
function AccumCcyConvert_N(p_centre_id varchar2) return boolean;
-- TUXEDO for authorizations in selected time perdiod.
function AccumCcyConvertForPeriod_N(p_centre_id varchar2,p_start_date date,p_end_date date) return boolean;
-- MCC Substractive interval for auth in between two execution times
function AccumCcyConvert_TUXEDO_Subs(p_centre_id varchar2,p_start_date date,p_end_date date) return boolean;
-- Atgriezh mainjas kursu starp divaam valuutaam.
function GetConvRate(p_ccy_num_from in out varchar2,
					p_ccy_num_to in out varchar2,
					p_bank in out varchar2,
					p_rate in out number) return boolean;
--#= History =============================================================
--# $Log: stip_accum_ccy_convert-package.sql,v $
--# Revision 1.9  2002/12/17 10:47:02  vilis
--# Fixed duplicated errorcodes
--#
--# Revision 1.5  2002/10/31 15:26:09  uldis
--# Netiek lietots REVISIO N buferis
--#
--# Revision 1.4  2002/01/31 09:40:36  karlis
--# Klluudu labojums akumulaacijas valuutas konvertaacijaa, kad funkcija
--# atgirezaas bez veertiibas. Tiek reggistreeti klludu zinnojumi errorlogaa,
--# ja nav valuutas kursa akumulaacijas valuutas konvaertaacijai.
--#
--# Revision 1.3  2002/01/30 16:26:45  karlis
--# Klluudu labojums, kas atrastas akumulaacijas valuutu konvertaacijas kodaa
--# izstraades testu laikaa.
--#
--# Revision 1.4  2002/01/23 14:26:42  karlis
--# Labojumi pazinnojumos.
--#
--# Revision 1.3  2002/01/23 12:51:55  karlis
--# Labojumi peec CODE REVIEW.
--#
--#=======================================================================
end;
/

