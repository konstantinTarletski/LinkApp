create PACKAGE
/* $HeadURL$ $Id$ */
err IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	TYPE error_msg_full_record IS RECORD (
	   message varchar2(1000),
	   err_rec_num number(11),
	   error_date date,
	   error_code number(3),
	   program_code number(3),
	   error_source varchar2(30),
	   msg_arguments varchar2(256),
	   program_type number(2),
	   program_name varchar2(256),
	   program_name_abbr varchar2(20),
	   program_type_abbr varchar2(20),
	   store_flag char(1),
	   error_class number(2),
	   error_class_abbr varchar2(20),
	   error_severity number(1),
	   error_severity_abbr varchar2(20),
	   error_arguments varchar2(256),
	   msg_template  varchar2(256),
	   action_code char(3),
	   msg_full varchar2(99));

	procedure	oraerr_init;
	PROCEDURE errorlog(error_num NUMBER,error_arg VARCHAR2,
				source VARCHAR2 default null,error_monitor VARCHAR2 default null);
	src				varchar(30):=null;
	errm			varchar(30):=null;
    FUNCTION error_store(err_msg in out error_msg_full_record) return varchar2;
    FUNCTION error_store(err_msg in out error_msg_full_record,action_flag in out char) return varchar2;
    FUNCTION get_error_msg(err_msg in out error_msg_full_record,action_flag in out char) return varchar2;
	type t_action_Item is record
		(
		action_code	number(3),
		argument	varchar2(256),
		argument_map	varchar2(256),
		argument_evaluator	varchar2(256),
		act_abbr	varchar2(20),
		performer	varchar2(30),
		configuration	varchar2(256),
		command	varchar2(1000),
		perf_abbr	varchar2(20)
		);
	type t_actionlist is table of t_action_Item index by binary_integer;
    FUNCTION error_action(err_msg in out error_msg_full_record,
						p_actionlist out t_actionlist
						) return varchar2;
     FUNCTION error_action(err_msg in out error_msg_full_record,
	 					cnt in out binary_integer
						) return varchar2;
	actionlist t_actionlist;
END;
/*= History =============================================================
 * $Log: err-package.sql,v $
 * Revision 1.2  2002/10/31 15:25:55  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.1  2002/05/10 13:06:44  uldis
 * Pakotne err un funkcija merge_error_msg p'arnesta no modu'la rtps.scm.evrb.error
 *
 * Revision 1.3  2001/09/11 18:05:04  uldis
 * Pievienots mas'ivs actionlist
 *
 * Revision 1.2  2001/08/29 17:10:55  gusts
 * Improved performance by using simple datatype insted of %rowtype.
 *
 * Revision 1.1  2001/03/12 07:26:14  uldis
 * P'arnests no modu'la rtps.scm.evrb.oraerr
 *
 * Revision 1.10  2000/10/02 08:38:07  uldis
 * K'l'udas gad'ijum'a skripts beidzas ar 1
 *
 * Revision 1.9  2000/09/24 15:20:44  uldis
 * Pievienota proced'ura oraerr_init.
 * Defin'eti k'l'udu pazi'nojumi un pievienota k'l'udu pazi'nojumu
 * re'gistr'acija datub'az'e.
 *
 * Revision 1.8  2000/06/16 10:12:24  uldis
 * errorlog im'uns pret store_error k'l'ud'am
 *
 * Revision 1.7  2000/06/15 13:57:23  uldis
 * P'artais'its k'l'udu re'gistr'acijas meh'anisms ar iesp'eju batch uzdevumiem
 * k'l'udu pazi'nojumus nedz'it caur errorlog.
 * Main'ijusies ar'i oraerr_pipe lieto'sana:
 * ./oraerr_pipe <connect string> [noaction|NOACTION]
 *
 * visi k'l'udu pazi'nojumi rakst'as logfail'a oraerr_pipe_YYMMDD.log
 * parametrs noaction nor'ad'a, ka nav j'aizsauc ERROR_ACTION serviss
 *
 * Revision 1.5  2000/03/01 09:50:53  uldis
 * K'l'udu v'estur'e tiek saglab'atas tikai t'as k'l'udas, kur'am ir store_flag.
 *
 * Revision 1.4  1999/07/15 20:50:23  uldis
 * Pielikti versiju ID main'igie REVISION
 *
 * Revision 1.3  1999/02/17 19:03:19  uldis
 * Izveidots oraerr_pipe <--> err.errorlog sazin'ashan'as protokols, kur'a
 * notiek konstat'ests, vai err.errorlog lietot PIPE vai raiksta pa tiesho
 * tabul'a
 *
 * Revision 1.2  1999/01/22 17:40:06  arita
 * Parcelti komentari
 *
 * Revision 1.1.1.1  1999/01/15 12:11:04  uldis
 * Created by Uldis Anshmits
 *
 ========================================================================*/
/

