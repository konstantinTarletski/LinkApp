create PACKAGE
/* $HeadURL$ $Id$ */
STIP_UNLOCK is
--==============================================================================
--	RTPS.IIA.UNLOCK
--
--	Autorizaaciju summu atblokkeessana
--		Kodeja:	Karlis Ogsts
--
--	$HeadURL$ $Id$
--	(C) 2002 TietoEnator Financial Solutions
--==============================================================================
	--============================================================================
	--                        ISSUER WORKPLACE UNLOCKING API
	--============================================================================
	g_ErrorText VARCHAR2(1000) := NULL;
	g_ErrorCode NUMBER(10) := 0;

	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	-- Atblokkee autorizaaciju bez kliringa tranzakcijas
	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	FUNCTION Manual_Auth_Unlock (
		p_hist_numb NUMBER,
		p_auth_rownumb NUMBER,
		p_process_child CHAR,
		p_adv_rownumb OUT NUMBER,
		p_centre_id IN VARCHAR2
	) RETURN BOOLEAN;

	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	-- Autorizaacijass atblokkeessana ar roku,
	-- kad autorizaacija tranzakcijai piemekleeta ar roku
	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	FUNCTION manual_match_unlock (
		p_hist_numb NUMBER,
		p_t_rowid ROWID,
		p_a_row_numb NUMBER,
		p_adv_row_numb OUT NUMBER,
		p_centre_id IN VARCHAR2
	) RETURN BOOLEAN;

	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	-- Kliiringa tranzakciju atziimee kaa apstraadaatu,
	-- kaut arii taa nav atblokkeejusi autorizaaciju
	--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	FUNCTION manual_match_delete(p_hist_numb NUMBER, p_t_rowid ROWID)
		RETURN BOOLEAN;

--==============================================================================
-- $Log: stip_unlock-package.sql,v $
-- Revision 1.33  2003/01/16 17:05:29  vilis
-- If record in stip_references with same row_numb exist
-- then update that record
--
-- Revision 1.32  2003/01/13 15:49:31  kovacs
-- - Atjaunoti header komentaari
--
-- Revision 1.31  2002/12/13 11:41:47  vilis
-- New unlocking ... WIP
--
-- Revision 1.27  2002/10/31 15:26:10  uldis
-- Netiek lietots REVISIO N buferis
--
-- Revision 1.26  2002/08/22 12:12:18  karlis
-- Labojuma datums: 22-AUG-2002
-- Labojumi: Kosmeetiski labojumi, izmestas funkcijas, kas kaadreiz bija taisiitas
-- prieks BSIF, bet tagad ir moraali novecojussas.
--
-- Revision 1.25  2002/03/11 12:23:54  kovacs
-- Safixeets insert.sql
--
-- Revision 1.24  2002/03/08 15:15:07  kovacs
-- Safixeets make fails lai laadee kljuudu pazinjojumus prieksh unlock_n atseviski no unlock
-- Register.sql pielikts, lai registree unlock_n program_names tabulaa.
-- Pielikts lai instalee unlock_n packaagi ieksh install_sh
--
-- Revision 1.23  2002/03/08 14:25:51  kovacs
-- Pielikti errorlog izsaukumi stip_unlock un stip_unlock_n
--
-- Revision 1.22  2002/03/06 15:02:06  kovacs
-- stip_unlock_n pielikts, ka atblokeejot var tikt updateets konta initial_amount
-- stip_import updateeshana paarnesta no unlock uz unlock_n
--
-- Revision 1.21  2002/03/04 12:56:52  kovacs
-- Pielikts, ka atblokeeshana notiek packaagee stip_unlock_n
--
-- Revision 1.19  2002/02/25 12:57:58  kovacs
-- Safixeets, ka ja stip_mess_exp updateeshanaa ir kljuuda, tad notiek atgrieshanaas no f-jas.
--
-- Revision 1.16  2001/08/24 14:35:13  uldis
-- Izmestas tuk'sas rindi'nas programmas tekst'a.
--
-- Revision 1.15  2000/12/14 10:38:20  karlis
-- Nevareeja atblokkeet ar roku paarskaitiijuma tranzakcijas.
--
-- Revision 1.14  2000/10/02 08:38:01  uldis
-- K'l'udas gad'ijum'a skripts beidzas ar 1
--
-- Revision 1.13  2000/09/21 15:50:26  karlis
-- Precizeejums pieprasiijuma K500 sakaraa.
--
-- Revision 1.12  2000/09/21 15:35:16  karlis
-- Atbilde uz MKS pieprasiijumu K500. Pielikta paarbaude vai reversaalis jau nav
-- atblokkeets briidi, kad atblokkee autorizaacijai piesaistiito rakstu.
--
-- Revision 1.11  2000/09/08 08:38:53  karlis
-- Pielikta DMS parskaitijumu apstrade.
--
-- Revision 1.10  2000/09/01 11:08:58  karlis
-- Valuutu konvertaacijaas tiek nnemta veeraa ekponenssu atsskkiriiba.
--
-- Revision 1.9  2000/07/04 13:43:30  karlis
-- Pievienota instalaacijas iespeeja Makefile.
--==============================================================================
END;
/

