create view STANDIN_TYPES_R as
select
		x.standin_type,
		x.abreviature,
		x.description
	from STANDIN_TYPES x
/

