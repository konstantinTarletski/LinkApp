create PACKAGE
/* $HeadURL$ $Id$ */
tinp_chk IS
/*=======================================================================
 * $HeadURL$ $Id$
 * (C) Tieto Konts Financial Systems Ltd. 1998,1999
 ========================================================================*/
	PROCEDURE tinp_chk(hist_numb INTEGER);
END;
/

