create view STIP_FARE_R as
select
		x.centre_id,
		x.min_score,
		x.max_score,
		x.action_code,
		x.offline_mode
	from STIP_FARE x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

