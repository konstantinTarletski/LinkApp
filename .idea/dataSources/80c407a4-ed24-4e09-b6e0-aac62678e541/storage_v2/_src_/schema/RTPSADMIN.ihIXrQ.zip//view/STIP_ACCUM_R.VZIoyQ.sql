create view STIP_ACCUM_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.card_number,
		x.param_grp,
		x.count_day,
		x.amount_day,
		x.count_week,
		x.amount_week
	from STIP_ACCUM x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

