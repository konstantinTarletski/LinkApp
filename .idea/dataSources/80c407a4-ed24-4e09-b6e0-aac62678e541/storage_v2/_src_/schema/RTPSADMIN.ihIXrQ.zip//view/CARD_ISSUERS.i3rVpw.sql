create view CARD_ISSUERS as
SELECT
     SETL_COND.CARD_TYPE
    ,SETL_COND.CENTRE_ID
    ,PROC_ENT.ONLINE_FLAG
    ,PROC_ENT.OFFLINE_FLAG
    ,PROC_ENT.CENTRE_SERVICE
    ,PROC_ENT.CENTRE_ADDRESS
    ,PROC_ENT.STIP_FLAG
    ,PROC_ENT.PREVALID_FLAG
    ,PROC_ENT.ADVICE_FLAG
    ,SETL_COND.CCY_CHECK
    ,SETL_COND.SETTL_CCY
    ,SETL_COND.CONV_FLAG
    ,SETL_COND.MULTICCY_FLAG
    ,PROC_ENT.ROUTING_KEY
FROM
    settlement_condit  setl_cond,
    processing_entities  proc_ent
 WHERE SETL_COND.ISS_ENABLE = 'T' AND PROC_ENT.ENABLE_FLAG = 'T' AND
 PROC_ENT.CENTRE_ID = SETL_COND.CENTRE_ID
/

comment on column CARD_ISSUERS.CARD_TYPE is 'Card type code'
/

comment on column CARD_ISSUERS.CENTRE_ID is 'Card issuer processing entity identifier'
/

comment on column CARD_ISSUERS.ONLINE_FLAG is 'On-Line processing mode availability flag'
/

comment on column CARD_ISSUERS.OFFLINE_FLAG is 'Off-Line processing mode availability flag'
/

comment on column CARD_ISSUERS.CENTRE_SERVICE is 'Communications module name'
/

comment on column CARD_ISSUERS.CENTRE_ADDRESS is 'Communications addressing argument'
/

comment on column CARD_ISSUERS.STIP_FLAG is 'Stand-In processing enable flag'
/

comment on column CARD_ISSUERS.PREVALID_FLAG is 'Request prevalidation enable flag'
/

comment on column CARD_ISSUERS.ADVICE_FLAG is 'Advice message generation necessity flag'
/

comment on column CARD_ISSUERS.CCY_CHECK is 'Currency verification flag'
/

comment on column CARD_ISSUERS.SETTL_CCY is 'Card settlement currency'
/

comment on column CARD_ISSUERS.CONV_FLAG is 'Currency conversion enable flag'
/

comment on column CARD_ISSUERS.MULTICCY_FLAG is 'Multicurrency mode enable flag'
/

comment on column CARD_ISSUERS.ROUTING_KEY is 'RTPS IF field used in data dependent routing'
/

