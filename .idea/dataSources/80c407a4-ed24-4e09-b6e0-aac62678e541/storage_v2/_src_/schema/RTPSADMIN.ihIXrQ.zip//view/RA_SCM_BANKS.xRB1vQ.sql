create view RA_SCM_BANKS as
SELECT BANK,
	BANK_NAME
FROM RTPS_BANKS
/

comment on column RA_SCM_BANKS.BANK is 'Bank code'
/

comment on column RA_SCM_BANKS.BANK_NAME is 'Bank name'
/

