create view R_CASH_TOTALS as
(SELECT a.term_group,
        a.term_id,
        a.term_city,
        a.term_str,
        a.curr_alpha,
        a.curr_exp,
        check_to_date(a.device_audit,'YYYYMMDDHH24MISS'),
        a.disp_amnt,
        a.hdisp_amnt,
        null,
        null,
        null,
        null
    FROM r_cashout_cash_totals a)
 UNION
 (SELECT a.term_group,
        a.term_id,
        a.term_city,
        a.term_str,
        a.curr_alpha,
        a.curr_exp,
        check_to_date(SUBSTR(a.device_audit,0,14),'YYYYMMDDHH24MISS'),
        null,
        null,
        a.batch_total,
        null,
        null,
        null
    FROM r_cashout_batches_totals a)
 UNION
 (SELECT a.term_group,
        a.term_id,
        a.term_city,
        a.term_str,
        a.curr_alpha,
        a.curr_exp,
        check_to_date(a.device_audit,'YYYYMMDDHH24MISS'),
        null,
        null,
        null,
        acc_amnt,
        timed_amnt,
        unc_amnt
    FROM r_cashin_totals a)
/

