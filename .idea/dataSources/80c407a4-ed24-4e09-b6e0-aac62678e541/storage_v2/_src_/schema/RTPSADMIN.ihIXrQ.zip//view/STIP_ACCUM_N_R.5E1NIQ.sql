create view STIP_ACCUM_N_R as
select
		x.centre_id,
		x.card_number,
		x.accum_id,
		x.count_day,
		x.amount_day,
		x.count_week,
		x.amount_week,
		x.rec_id,
		x.step_count,
		x.deleted,
		x.off_count_day,
		x.off_amount_day,
		x.off_count_week,
		x.off_amount_week
	from STIP_ACCUM_N x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

