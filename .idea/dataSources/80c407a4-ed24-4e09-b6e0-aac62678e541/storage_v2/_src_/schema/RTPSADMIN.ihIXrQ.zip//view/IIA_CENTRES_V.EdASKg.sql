create view IIA_CENTRES_V as
SELECT DISTINCT centre_id CENTRE_ID FROM processing_entities WHERE stip_flag='T' ORDER BY centre_id
/

