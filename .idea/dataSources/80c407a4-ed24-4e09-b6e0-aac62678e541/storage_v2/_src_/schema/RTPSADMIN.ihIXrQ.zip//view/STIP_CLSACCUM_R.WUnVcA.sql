create view STIP_CLSACCUM_R as
select
		x.centre_id,
		x.card_number,
		x.mcc_class,
		x.count_day,
		x.amount_day,
		x.count_week,
		x.amount_week
	from STIP_CLSACCUM x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

