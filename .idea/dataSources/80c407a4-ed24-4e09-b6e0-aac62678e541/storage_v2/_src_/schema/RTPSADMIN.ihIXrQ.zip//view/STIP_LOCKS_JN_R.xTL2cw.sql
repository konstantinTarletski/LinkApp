create view STIP_LOCKS_JN_R as
select
		x.jn_operation,
		x.jn_oracle_user,
		x.jn_datetime,
		x.jn_notes,
		x.jn_appln,
		x.jn_session,
		x.row_numb,
		x.centre_id,
		x.account_id,
		x.amount,
		x.ccy,
		x.request_date,
		x.lock_id,
		x.lock_type,
		x.rec_id,
		x.step_count,
		x.deleted,
		x.sync_tmst
	from STIP_LOCKS_JN x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

