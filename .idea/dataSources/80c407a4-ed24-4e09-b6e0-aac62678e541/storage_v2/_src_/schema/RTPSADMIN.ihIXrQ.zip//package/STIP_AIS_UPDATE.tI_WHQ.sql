create PACKAGE
STIP_AIS_UPDATE
IS

C_DO_NOT_COMMIT NUMBER := 1;

--=============================================================================
-- Pielieto izmainnas no SHADOW tabulam reaalajiem klasifikaatoriem
--		p_hist_numb > Apstraades identifikaators
--		p_center_id > Centra identifikaators
--		p_effective > Izmainnu EFFECTIVE_DATE (AIS-faila gadiijumaa = faila effective date, SNAPSHOT/DB-LINK gadiijumaa = sysdate)
--		p_full		> Pilnais vai izmainnu rezziims
--=============================================================================
function update_tables(p_hist_numb number,p_center_id varchar2,p_effective date,p_full boolean) return boolean;

--=============================================================================
-- Pielieto izmainnas no SHADOW tabulam reaalajiem klasifikaatoriem
--		p_hist_numb  > Apstraades identifikaators
--		p_center_id  > Centra identifikaators
--		p_effective  > Izmainnu EFFECTIVE_DATE (AIS-faila gadiijumaa = faila effective date, SNAPSHOT/DB-LINK gadiijumaa = sysdate)
--		p_cardnumber > KartinÄs numurs ko atjaunot/izveidot
--		lasterror    < information about last error
--=============================================================================
function update_single_card(p_hist_numb number,p_center_id varchar2,p_effective date,p_card_number varchar2, lasterror out varchar2) return boolean;

-- Ar brutaalu TRUNCATE attiira SHADOW tabulas
function truncate_shadows(p_hist_numb number,p_center_id varchar2,p_effective date) return boolean;

-- Veido indeksus SHADOW tabulaam
function create_objects(p_hist_numb number,p_center_id varchar2,p_effective date) return boolean;

-- Dzeess indeksus SHADOW tabulaam
function drop_objects(p_hist_numb number,p_center_id varchar2,p_effective date) return boolean;

-- Logoshana stip_ais_update log failaa (paredzeeta prieksh stip_ais_utils packages
procedure Logs(p_level number,p_msg varchar2);

-- Parsledz uz centra specifisku log failu, vai otradi, ja ir tukss p_centre_id
procedure SwitchLog(p_centre_id varchar2);

function UpdateClients(p_from date, p_to date, p_crd_holdr_id varchar2 default null, p_commit_off integer default 0) return boolean;
function UpdateAccounts(p_from date,p_to date,p_account_id varchar2 default null,p_commit_off integer default 0) return boolean;
function UpdateCards(p_from date, p_to date, p_card_number varchar2 default null, p_commit_off integer default 0) return boolean;

function UpdateRestrictedAccounts(p_from date, p_to date, p_card_number varchar2 default null, p_account_id varchar2 default null
								, p_crd_holdr_id varchar2 default null, p_card_seq varchar2 default null, p_commit_off integer default 0)
return boolean;


end;
/

