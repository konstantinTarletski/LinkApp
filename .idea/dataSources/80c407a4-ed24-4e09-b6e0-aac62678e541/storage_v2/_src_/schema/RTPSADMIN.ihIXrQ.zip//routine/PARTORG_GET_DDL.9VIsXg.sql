create FUNCTION           partorg_get_ddl(table_name VARCHAR2) RETURN CLOB IS
    dmsf      PLS_INTEGER;
    table_ddl VARCHAR2(32000);
begin
    dmsf := dbms_metadata.session_transform;
    dbms_metadata.set_transform_param(dmsf, 'TABLESPACE', FALSE);
    dbms_metadata.set_transform_param(dmsf, 'STORAGE', FALSE);
    dbms_metadata.set_transform_param(dmsf, 'SEGMENT_ATTRIBUTES', FALSE);
    dbms_metadata.set_transform_param(dmsf, 'PARTITIONING', FALSE);
    dbms_metadata.set_transform_param(dmsf, 'CONSTRAINTS', FALSE);
    dbms_metadata.set_transform_param(dmsf, 'REF_CONSTRAINTS', FALSE);

    select dbms_metadata.get_ddl('TABLE', table_name) into table_ddl from dual;
    return table_ddl;
end;
/

