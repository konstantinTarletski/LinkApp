create Function /* $HeadURL$ $Id$ */
STRDEC2STR ( str IN varchar2) RETURN varchar IS
	tmp	varchar2(6000):=null; -- darba buferis, kura sintiz?sies konversijas rezultats
	i	binary_integer:=1; -- rindas pozicijas indikators rada uz rindas sakumu
	l	binary_integer; -- konstantem, kas satur?s parametros sa?emtas rindas garumu
	a	binary_integer; -- mainigais, kas satur?s simbola ascii v?rtibu
BEGIN
	l:=length(str); -- atrod rindas garumu
	while i<=l loop  -- cikla kam?r indikators nav sasniedzis rindas beigas
		if substr(str,i,1)<>'\' then -- ja simbols nav backslash
			tmp:=tmp||substr(str,i,1); -- tad tas paliek nemainigs
			i:=i+1; -- palielina ridas pozicijas indikatoru
		else -- pret?ja gadijuma aiz backslash var sekot simbola decimala ascii v?rtiba
			begin --bloks, kura notiks m??inajums kovert?t decimalo v?rtibu par simbolu
				if substr(str,i+1,1)='-' then -- NPC charset bug
					if length(rtrim(ltrim(substr(str,i+1,4))))<>4 then -- decimalajam pierakstam jasastav no 3 simboliem
						raise VALUE_ERROR; --ja nav 4 simboli, tad v?rtiba netika lietotoa simbola gener??ana
					end if;
					a:=256-to_number(substr(str,i+2,3));--pav?r? decimalo pierakstu par skaitli
					i:=i+5; -- un pabida indikatoru par 5 pozicijam : '\-000'
				else
					if length(rtrim(ltrim(substr(str,i+1,3))))<>3 then -- decimalajam pierakstam jasastav no 3 simboliem
						raise VALUE_ERROR; --ja nav 3 simboli, tad v?rtiba netika lietotoa simbola gener??ana
					end if;
					a:=to_number(substr(str,i+1,3));--pav?r? decimalo pierakstu par skaitli
					i:=i+4; -- un pabida indikatoru par 4 pozicijam : '\000'
				end if;
--				if not ((a>0 and a<32) or (a>126 and a<255) or a=34 or a=38 or a=39 or a=92) or a is null then
--					raise VALUE_ERROR; --decimala pieraksta tiek kod?ti tikai simboli [1,31] un [127,255], ' " & \
--				end if;
				tmp:=tmp||chr(a); -- ja tik talu veiksmigi, tad pievieno sir?iinato simbolu
			exception
				when others then -- aiz backslash neseko korekts decimalais pieraksts
					tmp:=tmp||substr(str,i,1); -- simbols paliek nemainigs
					i:=i+1; -- palielina ridas pozicijas indikatoru
			end;
		end if;
	end loop;
    RETURN tmp;
END;
/

