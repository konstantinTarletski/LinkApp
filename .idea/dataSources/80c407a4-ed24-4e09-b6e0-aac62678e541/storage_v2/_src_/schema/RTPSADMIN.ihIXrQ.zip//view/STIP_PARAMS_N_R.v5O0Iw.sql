create view STIP_PARAMS_N_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.param_grp,
		x.mcc_restr,
		x.limits_flag,
		x.accum_flag,
		x.accum_ccy,
		x.abbreviature,
		x.description,
		x.common_grp_flag
	from STIP_PARAMS_N x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

