create view STIP_EVENT_ACCUM_R as
select
		x.request_date,
		x.row_numb,
		x.accum_id,
		x.centre_id,
		x.card_number,
		x.param_grp,
		x.accum_sign,
		x.off_accum_sign,
		x.accum_amount,
		x.off_accum_amount,
		x.accum_ccy,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_EVENT_ACCUM x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

