create view R_UNCERTAIN_TRANSACTIONS
            (ROW_NUMB, PAN, AMOUNT, CCY, CCY_ALPHA, CCY_EXP_DOT, TRN_TIME, MSG_TYPE, PROC_CODE, APPR_CODE, ACTION_CODE,
             BATCH_ID, BATCH_OWNER, RECONC_DATE, RECONC_CNTR, REFERENCE, REVERSED, EVENT_PARAMS, DEVICE_NAME, DEVICE_ID,
             DEVICE_AUDIT, EVENT_ID, EVENT_TIME_FROM, EVENT_TIME_TO, EVENT_TYPE, EVENT_TYPE_NAME)
as
SELECT   extract_param_val (a.EVENT_PARAMS, 'row_numb'),
            extract_param_val (a.EVENT_PARAMS, 'pan'),
            extract_param_val (a.EVENT_PARAMS, 'amount'),
            extract_param_val (a.EVENT_PARAMS, 'ccy'),
            extract_param_val (a.EVENT_PARAMS, 'ccy_alpha'),
            extract_param_val (a.EVENT_PARAMS, 'ccy_exp_dot'),
            extract_param_val (a.EVENT_PARAMS, 'trn_time'),
            extract_param_val (a.EVENT_PARAMS, 'msg_type'),
            extract_param_val (a.EVENT_PARAMS, 'proc_code'),
            extract_param_val (a.EVENT_PARAMS, 'appr_code'),
            extract_param_val (a.EVENT_PARAMS, 'action_code'),
            extract_param_val (a.EVENT_PARAMS, 'batch_id'),
            extract_param_val (a.EVENT_PARAMS, 'batch_owner'),
            extract_param_val (a.EVENT_PARAMS, 'reconc_date'),
            extract_param_val (a.EVENT_PARAMS, 'reconc_cntr'),
            extract_param_val (a.EVENT_PARAMS, 'reference'),
            extract_param_val (a.EVENT_PARAMS, 'reverse'),
            a.EVENT_PARAMS,
            b.device_name,
            a.device_id,
            a.device_audit,
            a.event_id,
            a.event_time,
            a.event_time,
            a.event_type,
            c.event_type_name
     FROM   atm_events a, atm_devices b, atm_event_types c
    WHERE       a.event_type = c.event_type_id
            AND a.device_id = b.device_id
            AND c.event_type_group = 2
/

