create PACKAGE
/*
$HeadURL: http://cvs.konts.lv/repos/TE_trm/bc/rout_mgmt/trunk/stpimp/stop_imp_rep-package.sql$
$Id: stop_imp_rep-package.sql 64040 2009-03-26 07:22:09Z uldisa$
*/
stop_imp_rep IS
/*
$HeadURL: http://cvs.konts.lv/repos/TE_trm/bc/rout_mgmt/trunk/stpimp/stop_imp_rep-package.sql$
$Id: stop_imp_rep-package.sql 64040 2009-03-26 07:22:09Z uldisa$
*/
   PROCEDURE file( hist_numb         INTEGER DEFAULT stop_imp.hist_numb,
                   centre_id         VARCHAR2 DEFAULT stop_imp.centre_id,
                   effective_date    DATE DEFAULT stop_imp.effective_date );

   PROCEDURE centre( hist_numb    INTEGER DEFAULT stop_imp.hist_numb,
                     centre_id    VARCHAR2 DEFAULT stop_imp.centre_id );

   PROCEDURE task( hist_numb INTEGER DEFAULT stop_imp.hist_numb );

   --report_type: 0 - text 1 - html
   PROCEDURE rep( report_type       INTEGER,
                  hist_numb         INTEGER DEFAULT NULL,
                  centre_id         VARCHAR2 DEFAULT NULL,
                  effective_date    DATE DEFAULT NULL );

   PROCEDURE simple_rep( hist_numb INTEGER );

END;
/

