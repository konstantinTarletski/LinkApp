create view STIP_CHIP_KEYS_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.update_date,
		x.key_index,
		x.crp_key,
		x.mac_key,
		x.enc_key,
		x.dac_key,
		x.idn_key,
		x.crp_key_info,
		x.mac_key_info,
		x.enc_key_info,
		x.dac_key_info,
		x.idn_key_info
	from STIP_CHIP_KEYS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

