create view R_CASH_STATUS_CURRENT as
SELECT
    d.terminal_device_id,
    d.terminal_device_name,
    a.device_id,
    b.device_name,
    a.device_audit,
    CASE WHEN b.device_name IN ('CASETTE1','CASETTE2','CASETTE3','CASETTE4') THEN 'CASHOUT' ELSE 'CASHIN' END cash_type,
    a.accum_name,
    a.accum_value accum_count,
    a.accum_property curr_num,
    c.curr_alpha curr_alpha,
    c.curr_exp_dot curr_exp_dot,
    a.accum_units accum_denom,
    a.accum_units*a.accum_value accum_amount
FROM
    atm_devices_accum a,
    atm_devices b,
    ccy_codes c,
    r_terminal_devices d
WHERE
    a.device_id=b.device_id
    AND a.device_audit=b.device_audit
    AND a.accum_property=c.curr_num
    AND a.device_id=d.device_id
ORDER BY
    device_audit,curr_num,device_id,accum_name
/

