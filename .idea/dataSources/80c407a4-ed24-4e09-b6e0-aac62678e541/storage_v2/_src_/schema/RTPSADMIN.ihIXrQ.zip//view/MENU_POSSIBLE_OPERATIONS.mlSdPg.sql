create view MENU_POSSIBLE_OPERATIONS as
select /*+ rule */
	m.menu_id MENU_ID,
	m.menu_name MENU_NAME,
	msel.op SEL,
	mupd.op UPD,
	minz.op INS,
	mdel.op DEL,
	mexe.op EXE
from
  menus m,
  (select menu_id, 'X' op from menu_operations
    where operation = 'E') mexe,
  (select menu_id, 'X' op from menu_operations
    where operation = 'S') msel,
  (select menu_id, 'X' op from menu_operations
    where operation = 'I') minz,
  (select menu_id, 'X' op from menu_operations
    where operation = 'U') mupd,
  (select menu_id, 'X' op from menu_operations
    where operation = 'D') mdel
where
  m.menu_id = mexe.menu_id (+) and
  m.menu_id = mdel.menu_id (+) and
  m.menu_id = minz.menu_id (+) and
  m.menu_id = mupd.menu_id (+) and
  m.menu_id = msel.menu_id (+)
/

