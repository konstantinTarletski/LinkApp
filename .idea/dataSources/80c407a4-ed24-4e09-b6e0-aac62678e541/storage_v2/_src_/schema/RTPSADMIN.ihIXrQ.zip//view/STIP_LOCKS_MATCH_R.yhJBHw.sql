create view STIP_LOCKS_MATCH_R as
select
		x.row_numb,
		x.centre_id,
		x.pref_rec_num,
		x.request_date,
		x.unlock_date,
		x.msg_type,
		x.fld_002,
		x.fld_003,
		x.fld_004,
		x.fld_006,
		x.fld_011,
		x.fld_012,
		x.fld_022,
		x.fld_024,
		x.fld_026,
		x.fld_032,
		x.fld_037,
		x.fld_038,
		x.fld_041,
		x.fld_042,
		x.fld_043,
		x.fld_046,
		x.fld_049,
		x.fld_051,
		x.amount_diff,
		x.child_row,
		x.reverse_flag,
		x.unlock_keep,
		x.tid,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_LOCKS_MATCH x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

