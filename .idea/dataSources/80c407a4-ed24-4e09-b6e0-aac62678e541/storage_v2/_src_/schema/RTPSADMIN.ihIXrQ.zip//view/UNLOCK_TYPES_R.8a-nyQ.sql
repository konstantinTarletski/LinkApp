create view UNLOCK_TYPES_R as
select
		x.unlock_type,
		x.abbreviature,
		x.description
	from UNLOCK_TYPES x
/

