create FUNCTION GET_FEE_AMNT (
   Fld46     IN VARCHAR2,
   feetype   IN VARCHAR2 DEFAULT '70',
   signed    IN NUMBER DEFAULT 0)
   RETURN NUMBER
IS
   feeamnt     NUMBER;
   tmpFld46    VARCHAR2 (204);
   extracted   VARCHAR2 (34);
   done        BOOLEAN;
BEGIN
   feeamnt := 0;

   IF fld46 IS NULL OR LENGTH (Fld46) = 0
   THEN
      RETURN 0;
   END IF;

   tmpFld46 := Fld46;
   done := FALSE;

   WHILE NOT done AND LENGTH (tmpFld46) > 0
   LOOP
      extracted := SUBSTR (tmpFld46, 1, 34);
      tmpFld46 := SUBSTR (tmpFld46, 35);

      IF SUBSTR (extracted, 1, 2) = feetype
      THEN
         feeamnt := TO_NUMBER (SUBSTR (extracted, 7, 8));
         done := TRUE;
         IF signed > 0 THEN
            IF substr(extracted,6,1)='D' THEN
                feeamnt := -feeamnt;
            END IF;
         END IF;
      END IF;
   END LOOP;

   RETURN feeamnt;
END GET_FEE_AMNT;
/

