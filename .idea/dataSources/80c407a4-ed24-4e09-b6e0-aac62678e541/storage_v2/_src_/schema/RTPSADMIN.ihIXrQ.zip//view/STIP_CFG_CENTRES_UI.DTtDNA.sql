create view STIP_CFG_CENTRES_UI as
select
	a.centre_id,
	a.prefix_id,
	a.profile_id
from
	stip_cfg_centres a
where
	exists (select null
				from
					centre_users cu
				where
					cu.centre_id=a.centre_id and
					cu.username = user)
/

comment on column STIP_CFG_CENTRES_UI.CENTRE_ID is 'Data owner processing entity identifier'
/

comment on column STIP_CFG_CENTRES_UI.PREFIX_ID is 'Prefix record number'
/

comment on column STIP_CFG_CENTRES_UI.PROFILE_ID is 'Profile identification number'
/

