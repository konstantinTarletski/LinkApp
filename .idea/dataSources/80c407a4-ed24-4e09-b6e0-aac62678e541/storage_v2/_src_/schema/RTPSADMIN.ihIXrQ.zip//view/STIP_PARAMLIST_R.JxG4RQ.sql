create view STIP_PARAMLIST_R as
select
		x.week_length,
		x.param_grp,
		x.answer_code,
		x.abbreviature,
		x.accum_id,
		x.description,
		x.rule_expr,
		x.centre_id,
		x.limit_trans,
		x.count_day,
		x.amount_day,
		x.count_week,
		x.amount_week,
		x.limit_trans_gray,
		x.count_day_gray,
		x.amount_day_gray,
		x.count_week_gray,
		x.amount_week_gray,
		x.group_flag,
		x.off_limit_trans,
		x.off_count_day,
		x.off_amount_day,
		x.off_count_week,
		x.off_amount_week,
		x.restr_type
	from STIP_PARAMLIST x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

