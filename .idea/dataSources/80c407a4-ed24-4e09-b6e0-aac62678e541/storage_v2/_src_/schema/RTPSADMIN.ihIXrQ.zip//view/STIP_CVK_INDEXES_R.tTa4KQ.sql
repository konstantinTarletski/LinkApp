create view STIP_CVK_INDEXES_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.key_type,
		x.expiry_from,
		x.expiry_to,
		x.key_index
	from STIP_CVK_INDEXES x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

