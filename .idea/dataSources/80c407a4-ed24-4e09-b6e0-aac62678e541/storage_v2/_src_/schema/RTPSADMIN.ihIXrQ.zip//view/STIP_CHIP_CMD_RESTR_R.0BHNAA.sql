create view STIP_CHIP_CMD_RESTR_R as
select
		x.centre_id,
		x.pref_rec_num,
		x.rule_expr,
		x.description,
		x.rec_id,
		x.step_count,
		x.deleted
	from STIP_CHIP_CMD_RESTR x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

