create view STIP_PARAMS_R as
select
		x.centre_id,
		x.effective_date,
		x.update_date,
		x.purge_date,
		x.param_grp,
		x.mcc_restr,
		x.limits_flag,
		x.accum_flag,
		x.accum_ccy,
		x.limit_trans,
		x.count_day,
		x.amount_day,
		x.week_length,
		x.week_multipl,
		x.abbreviature,
		x.description,
		x.visa_flag,
		x.count_week,
		x.amount_week,
		x.limit_trans_gray,
		x.count_day_gray,
		x.amount_day_gray,
		x.count_week_gray,
		x.amount_week_gray
	from STIP_PARAMS x
	where exists (
				select null
					from centre_users u
					where u.centre_id=x.centre_id and upper(u.username)=user)
	with check option
/

