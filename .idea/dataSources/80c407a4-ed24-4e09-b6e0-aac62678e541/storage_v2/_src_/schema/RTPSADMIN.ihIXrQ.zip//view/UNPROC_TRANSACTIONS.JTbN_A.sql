create view UNPROC_TRANSACTIONS as
select
      m.BATCH_OWNER
      ,m.RECONCILE_DATE
      ,m.RECONCILE_CNTR
      ,m.UPDATE_DATE
      ,m.AUTHORIZ_ROW
      ,m.RECONCILE_FLAG
      ,m.PROCESS_FLAG
      ,m.PROCESS_TASK
      ,m.transact_row row_numb
      ,m.request_date
      ,m.stan_internal
      ,m.card_type
      ,decode(substr(nvl(nvl(m.epi_48_42,a.epi_48_42),'000'),3,1),'0',m.dev_type,'P') dev_type
      ,m.msg_type_in
      ,nvl(a.msg_type_out,m.msg_type_out) msg_type_out
      ,m.msg_orig_in
      ,m.msg_orig_out
      ,m.fld_002
      ,nvl(a.fld_003,m.fld_003) fld_003
      ,m.fld_004
      ,m.FLD_005
      ,m.FLD_006
      ,m.FLD_009
      ,m.FLD_010
      ,nvl(a.fld_011,m.fld_011) fld_011
      ,nvl(m.fld_012,a.fld_012) fld_012
      ,nvl(m.fld_014,a.fld_014) fld_014
      ,nvl(a.fld_015,m.fld_015) fld_015
      ,nvl(a.fld_016,m.fld_016) fld_016
      ,m.FLD_017
      ,m.FLD_019
      ,m.FLD_020
      ,m.FLD_021
      ,nvl(a.fld_022,m.fld_022) fld_022
      ,nvl(a.fld_023,m.fld_023) fld_023
      ,m.fld_024
      ,m.fld_025
      ,m.FLD_026
      ,m.FLD_030A
      ,m.FLD_030B
      ,m.FLD_031
      ,m.FLD_032
      ,m.FLD_033
      ,m.FLD_034
      ,nvl(a.fld_035,m.fld_035) fld_035
      ,m.FLD_036
      ,nvl(a.fld_037,m.fld_037) fld_037
      ,nvl(a.fld_038,m.fld_038) fld_038
      ,m.FLD_039
      ,nvl(a.fld_040,m.fld_040) fld_040
      ,nvl(m.fld_041,a.fld_041) fld_041
      ,m.FLD_042
      ,nvl(a.fld_043,m.fld_043) fld_043
      ,nvl(a.fld_045,m.fld_045) fld_045
      ,m.FLD_046
      ,m.fld_049
      ,m.FLD_050
      ,m.FLD_051
      ,nvl(m.fld_055,a.fld_055) fld_055
      ,nvl(m.fld_056a,a.fld_056a) fld_056a
      ,m.FLD_056B
      ,m.FLD_056C
      ,m.FLD_056D
      ,m.FLD_057
      ,m.FLD_058
      ,m.FLD_093
      ,m.FLD_094
      ,nvl(a.fld_095,m.fld_095) fld_095
      ,nvl(m.fld_098,a.fld_098) fld_098
      ,m.FLD_100
      ,m.FLD_101
      ,nvl(m.fld_102,a.fld_102) fld_102
      ,nvl(m.fld_103,a.fld_103) fld_103
      ,nvl(m.fld_104,a.fld_104) fld_104
      ,nvl(a.fld_122,m.fld_122) fld_122
      ,nvl(a.fld_123,m.fld_123) fld_123
      ,nvl(a.fld_126,m.fld_126) fld_126
	  ,m.fld_126
      ,nvl(m.fld_127,a.fld_127) fld_127
      ,nvl(a.epi_48_42,m.epi_48_42) epi_48_42
      ,m.suspect_cause
 from
     acq_transaction_log m
    ,acq_authorisation_log a
 where
    m.process_flag='F' and
    a.row_numb (+)=m.authoriz_row
/

