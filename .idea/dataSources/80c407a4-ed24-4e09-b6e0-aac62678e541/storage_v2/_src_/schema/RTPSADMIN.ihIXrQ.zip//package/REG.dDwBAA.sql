create package
/* $HeadURL$ $Id$ */
reg is
/*#===================================================================================================
--#		RTPS.COMMON.REG
--#			Operaacijas ar reggistriju
--#
--#		Kodeja: Karlis Ogsts
--#
--#		$HeadURL$ $Id$
--#		(C) Tieto Konts Financial Systems Ltd. 1998-2001
--#===================================================================================================*/
function open(name in varchar2,key_out in out number) return boolean;
function open(key_in in number,sub_name varchar2,key_out in out number) return boolean;
function create_key(name in varchar2,key_out in out number) return boolean;
function create_key(key_in in number,sub_name varchar2,key_out in out number) return boolean;
function getc(name in varchar2,key_value in out varchar2) return boolean;
function getc(key_in in number,sub_name in varchar2,key_value in out varchar2) return boolean;
function getn(name in varchar2,key_value in out number) return boolean;
function getn(key_in in number,sub_name in varchar2,key_value in out number) return boolean;
function setn(name in varchar2,key_value in number) return boolean;
function setn(key_in in number,sub_name in varchar2,key_value in number) return boolean;
function setc(name in varchar2,key_value in varchar2) return boolean;
function setc(key_in in number,sub_name in varchar2,key_value in varchar2) return boolean;
function enum(name in varchar2,types in char,sub_name in out varchar2,prev_key in out number) return boolean;
function enum(key_in in number,types in char,sub_name in out varchar2,prev_key in out number) return boolean;
function delkey(name in varchar2) return boolean;
function create_symlink(name in varchar2,link_path in varchar2) return boolean;
/*= History =============================================================
 * $Log: reg-package.sql,v $
 * Revision 1.5  2002/10/31 15:25:55  uldis
 * Netiek lietots REVISIO N buferis
 *
 * Revision 1.4  2001/11/27 14:37:59  tuxedo
 * Izv'aktas tuk's'as rindi'nas, jo Oracle t'as neglab'a.
 *
 * Revision 1.3  2000/10/10 09:52:03  karlis
 * Pielikti Header un Footer.
 *
 ========================================================================*/
end;
/

