create PROCEDURE           partorg_drop_table_partition(p_table_name VARCHAR2, partition_name VARCHAR2, key VARCHAR2) IS
    partition_name_new VARCHAR2(64);
    key_list VARCHAR2(64);
    i NUMBER := 1;
    TABLE_DOES_NOT_EXIST EXCEPTION;
    PRAGMA EXCEPTION_INIT (TABLE_DOES_NOT_EXIST, -942);
    ORA_INVALID_CREATE_INDEX EXCEPTION;
    PRAGMA EXCEPTION_INIT (ORA_INVALID_CREATE_INDEX, -2158);
BEGIN
    IF LENGTH(key) != 0 THEN
        partition_name_new := upper('po_' || partition_name);
        key_list := 'partorg_preserve_keys';

        BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE ' || partition_name_new;
        EXCEPTION
            WHEN TABLE_DOES_NOT_EXIST THEN NULL;
        END;

        EXECUTE IMMEDIATE 'CREATE TABLE ' || partition_name_new
        || ' AS SELECT * FROM ' || p_table_name || ' PARTITION (' || partition_name || ')'
        || ' WHERE ' || key || ' IN (SELECT ' || key || ' FROM ' || key_list || ')';

        dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'TABLESPACE', FALSE);
        dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'STORAGE', FALSE);
        dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'SEGMENT_ATTRIBUTES', FALSE);

        FOR c IN (select CASE WHEN INSTR(UPPER(ddl), 'LOCAL', 1, 1)=0 THEN ddl
                else SUBSTR(ddl,1,INSTR(UPPER(ddl), 'LOCAL', 1, 1)-1) END as ddl
                 from (SELECT REPLACE(REPLACE(dbms_metadata.get_ddl('CONSTRAINT', constraint_name, owner),
                            p_table_name, partition_name_new),
                                constraint_name, 'pk_' || partition_name_new) AS ddl
                    FROM user_constraints
                   WHERE table_name = UPPER(p_table_name) AND constraint_type = 'P'))
        LOOP
            EXECUTE IMMEDIATE to_char(c.ddl);
        END LOOP;

        BEGIN
            FOR c IN (
                select ddl,
                decode(instr(ddl, chr(10)), 0, ddl, substr(ddl, instr(ddl, 'CREATE'), instr(ddl, chr(10), instr(ddl, 'CREATE'))-1)) as ddl1 FROM
               (
                select CASE WHEN INSTR(UPPER(ddl), 'LOCAL', 1, 1)=0 THEN ddl
                else SUBSTR(ddl,1,INSTR(UPPER(ddl), 'LOCAL', 1, 1)-1) END as ddl
                        from(SELECT REPLACE(REPLACE(dbms_metadata.get_ddl('INDEX', INDEX_NAME),
                        p_table_name, partition_name_new),
                                index_name, partition_name_new || '_' || TO_CHAR(i)) AS ddl
                        FROM user_indexes
                       WHERE table_name = UPPER(p_table_name) AND partitioned='YES'  AND index_name NOT IN (SELECT index_name from user_constraints  WHERE table_name = UPPER(p_table_name) and index_name is not null))))
            LOOP
                BEGIN
                    EXECUTE IMMEDIATE TO_CHAR(c.ddl);
                EXCEPTION
                    WHEN ORA_INVALID_CREATE_INDEX THEN
                        BEGIN
                            EXECUTE IMMEDIATE c.ddl1;
                        EXCEPTION
                            WHEN OTHERS THEN
                                RAISE_APPLICATION_ERROR(-20001, 'ORA-2158 while executing: [' || TO_CHAR(c.ddl) || ']');
                        END;
                END;
            END LOOP;
        END;


        EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table_name
        || ' EXCHANGE PARTITION ' || partition_name
        || ' WITH TABLE ' || partition_name_new
        || ' INCLUDING INDEXES'
        || ' WITHOUT VALIDATION'
        || ' UPDATE INDEXES';

        EXECUTE IMMEDIATE 'DROP TABLE ' || partition_name_new;
    ELSE
        EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table_name || ' DROP PARTITION ' || partition_name || ' UPDATE INDEXES';
    END IF;
END;
/

